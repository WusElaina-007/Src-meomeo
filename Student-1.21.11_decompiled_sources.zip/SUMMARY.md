# Decompile Summary

**JAR:** Student-1.21.11.jar  
**Size:** 492760 bytes  
**SHA-256:** c82621383f036bc7128d472064fa99e4c1dc06b0ad570cef5ef88ed63cb971c5  
**Processing time:** 108 ms  

## Statistics

| | Count |
|---|---|
| Total classes | 90 |
| Decompiled (clean) | 90 |
| Decompiled (with warnings) | 0 |
| Failed to parse | 0 |
| Resource files | 5 |

## Resource Files

- `META-INF/MANIFEST.MF`
- `LICENSE_Student`
- `addon-template.mixins.json`
- `assets/Student/icon.png`
- `fabric.mod.json`

