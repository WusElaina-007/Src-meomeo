/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.modules.ChatColorPicker;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.class_2583;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public class ChatHudInteractableMixin {
    @Inject(method={"method_75815(Lnet/minecraft/class_2583;)V"}, at={@At(value="HEAD")})
    private void onAccept(class_2583 style, CallbackInfo ci) {
        if (style == null) {
            return;
        }
        ChatColorPicker module = (ChatColorPicker)Modules.get().get(ChatColorPicker.class);
        if (module != null) {
            if (module.isActive()) {
                module.captureStyle(style);
            }
        }
    }
}
