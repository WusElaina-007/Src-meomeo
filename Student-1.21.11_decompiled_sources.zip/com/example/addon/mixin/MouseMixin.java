/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.modules.ChatColorPicker;
import com.example.addon.modules.StudentFreeCam;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.class_11910;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public abstract class MouseMixin {
    private double field_1789;
    private double field_1787;

    @Inject(method={"method_1606"}, at={@At(value="HEAD")}, cancellable=true)
    private void onUpdateMouse(CallbackInfo ci) {
        StudentFreeCam freecam = (StudentFreeCam)Modules.get().get(StudentFreeCam.class);
        freecam.changeLookDirection(this.field_1789, this.field_1787);
        if (freecam != null && freecam.isActive()) {
            this.field_1789 = 0;
            this.field_1787 = 0;
            ci.cancel();
        }
    }

    @Inject(method={"method_1601"}, at={@At(value="HEAD")})
    private void onMouseButton(long window, class_11910 input, int action, CallbackInfo ci) {
        if (action != 1 || input.comp_4801() != 0) {
            return;
        }
        ChatColorPicker module = (ChatColorPicker)Modules.get().get(ChatColorPicker.class);
        if (module != null) {
            if (module.isActive()) {
                module.onMouseClick();
            }
        }
    }
}
