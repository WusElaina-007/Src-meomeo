/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.modules.FreezePlayer;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public class PlayerMixin {
    @Inject(method={"method_3136"}, at={@At(value="HEAD")}, cancellable=true)
    private void onSendMovementPackets(CallbackInfo ci) {
        if (Modules.get().isActive(FreezePlayer.class)) {
            ci.cancel();
        }
    }
}
