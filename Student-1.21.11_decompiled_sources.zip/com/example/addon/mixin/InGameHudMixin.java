/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.modules.CustomCrosshair;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public class InGameHudMixin {
    @Inject(method={"method_1736"}, at={@At(value="HEAD")}, cancellable=true)
    private void onRenderCrosshair(class_332 context, class_9779 counter, CallbackInfo ci) {
        CustomCrosshair mod = (CustomCrosshair)Modules.get().get(CustomCrosshair.class);
        mod.renderMixin(context);
        if (mod != null && mod.isActive()) {
            ci.cancel();
        }
    }
}
