/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.modules.SwingHand;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.class_10444;
import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_742;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public class HandScaleMixin {
    @Inject(method={"method_3228"}, at={@At(value="HEAD")}, cancellable=true)
    private void onRenderFirstPersonItem(class_742 player, float tickProgress, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_11659 orderedRenderCommandQueue, int light, CallbackInfo ci) {
        SwingHand mod = (SwingHand)Modules.get().get(SwingHand.class);
        if (mod == null || !mod.isActive()) {
            return;
        }
        if (item.method_7960()) {
            return;
        }
        boolean isMainHand = hand == class_1268.field_5808;
        class_1306 arm = isMainHand ? player.method_6068() : player.method_6068().method_5928();
        float dir = arm == class_1306.field_6183 ? 1f : -1f;
        matrices.method_22903();
        float speed = ((Double)mod.speed.get()).floatValue() / 100f;
        float swingAmount = class_3532.method_15374((double)(class_3532.method_15355(Math.min(swingProgress / speed, 1f)) * 3.1415927f));
        matrices.method_46416(((Double)mod.xPos.get()).floatValue() * dir, ((Double)mod.yPos.get()).floatValue(), ((Double)mod.zPos.get()).floatValue());
        float swingRotX = class_3532.method_16439(swingAmount, 0f, ((Double)mod.xSwingRot.get()).floatValue());
        float swingRotY = class_3532.method_16439(swingAmount, 0f, ((Double)mod.ySwingRot.get()).floatValue() * dir);
        float swingRotZ = class_3532.method_16439(swingAmount, 0f, ((Double)mod.zSwingRot.get()).floatValue());
        matrices.method_22907(class_7833.field_40714.rotationDegrees(((Double)mod.rotX.get()).floatValue() + swingRotX));
        matrices.method_22907(class_7833.field_40716.rotationDegrees(((Double)mod.rotY.get()).floatValue() + swingRotY));
        matrices.method_22907(class_7833.field_40718.rotationDegrees(((Double)mod.rotZ.get()).floatValue() + swingRotZ));
        float s = ((Double)mod.scale.get()).floatValue();
        matrices.method_22905(s, s, s);
        class_310 client = class_310.method_1551();
        class_811 ctx = arm == class_1306.field_6183 ? class_811.field_4322 : class_811.field_4321;
        class_10444 itemRenderState = new class_10444();
        client.method_65386().method_65598(itemRenderState, item, ctx, client.field_1687, player, player.method_5628() + ctx.ordinal());
        itemRenderState.method_65604(matrices, orderedRenderCommandQueue, light, class_4608.field_21444, 0);
        matrices.method_22909();
        ci.cancel();
    }
}
