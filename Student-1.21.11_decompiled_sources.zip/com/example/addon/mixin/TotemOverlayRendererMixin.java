/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.modules.TotemSize;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.class_10444;
import net.minecraft.class_11659;
import net.minecraft.class_1799;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public class TotemOverlayRendererMixin {
    private class_1799 field_59972;
    private int field_59973;
    private float field_59974;
    private float field_59975;

    @Inject(method={"method_70939"}, at={@At(value="HEAD")}, cancellable=true)
    private void onRenderFloatingItem(class_4587 matrices, float tickProgress, class_11659 queue, CallbackInfo ci) {
        TotemSize mod = (TotemSize)Modules.get().get(TotemSize.class);
        if (mod == null || !mod.isActive()) {
            return;
        }
        if (this.field_59972 == null || this.field_59973 <= 0) {
            return;
        }
        ci.cancel();
        int i = 40 - this.field_59973;
        float f = ((float)i + tickProgress) / 40f;
        float g = f * f;
        float h = f * g;
        float j = 10.25f * h * g - 24.95f * g * g + 25.5f * h - 13.8f * g + 4f * f;
        float k = j * 3.1415927f;
        class_310 client = class_310.method_1551();
        float l = (float)client.method_22683().method_4489() / (float)client.method_22683().method_4506();
        float m = this.field_59974 * 0.3f * l;
        float n = this.field_59975 * 0.3f;
        float userScale = ((Double)mod.scale.get()).floatValue();
        matrices.method_22903();
        matrices.method_46416(m * class_3532.method_15379(class_3532.method_15374((double)(k * 2f))), n * class_3532.method_15379(class_3532.method_15374((double)(k * 2f))), -10f + 9f * class_3532.method_15374((double)k));
        float o = 0.8f * userScale;
        matrices.method_22905(o, o, o);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(900f * class_3532.method_15379(class_3532.method_15374((double)k))));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(6f * class_3532.method_15362((double)(f * 8f))));
        matrices.method_22907(class_7833.field_40718.rotationDegrees(6f * class_3532.method_15362((double)(f * 8f))));
        client.field_1773.method_71114().method_71034(class_308.class_11274.field_60027);
        class_10444 itemRenderState = new class_10444();
        client.method_65386().method_65598(itemRenderState, this.field_59972, class_811.field_4319, client.field_1687, null, 0);
        itemRenderState.method_65604(matrices, queue, 15728880, class_4608.field_21444, 0);
        matrices.method_22909();
    }
}
