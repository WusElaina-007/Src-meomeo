/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import com.example.addon.mixin.HandledScreenAccessor;
import com.example.addon.modules.CrafterSetup;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.class_8881;
import net.minecraft.class_8898;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public class CrafterScreenMixin {
    @Inject(method={"method_25426"}, at={@At(value="TAIL")})
    private void onInit(CallbackInfo ci) {
        CrafterSetup module = (CrafterSetup)Modules.get().get(CrafterSetup.class);
        if (module == null || !module.shouldAutoApply()) {
            return;
        }
        class_8898 screen = (class_8898)this;
        class_8881 handler = (class_8881)screen.method_17577();
        HandledScreenAccessor accessor = (HandledScreenAccessor)this;
        for (int i = 0; i < 9; i++) {
            boolean ticked = module.isSlotEnabled(i);
            handler.method_54458(i, !ticked);
            accessor.invokeOnSlotChangedState(i, handler.field_7763, !ticked);
        }
    }
}
