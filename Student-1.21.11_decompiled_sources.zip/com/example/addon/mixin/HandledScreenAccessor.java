/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.mixin;

import org.spongepowered.asm.mixin.gen.Invoker;

public interface HandledScreenAccessor {
    @Invoker(value="method_54590")
    public void invokeOnSlotChangedState(int var1, int var2, boolean var3);
}
