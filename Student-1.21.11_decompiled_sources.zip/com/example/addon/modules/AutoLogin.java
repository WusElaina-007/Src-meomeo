/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_310;

public class AutoLogin
extends Module {
    private final SettingGroup sg = this.settings.getDefaultGroup();
    private final Setting<String> fileName = this.sg.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("file-name")).description("Tên file txt trong thư mục .minecraft (ví dụ: accounts.txt). Để trống nếu không dùng file.")).defaultValue("accounts.txt")).build());
    private final Setting<String> manualAccounts = this.sg.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("accounts")).description("Tài khoản thủ công, định dạng: name:pass,name2:pass2")).defaultValue("")).build());
    private List<String[]> accounts = new ArrayList();
    private boolean logged = false;

    public AutoLogin() {
        super(AddonTemplate.Student, "Auto Login", "Auto login when join server.");
    }

    public void onActivate() {
        this.logged = false;
        this.accounts = new ArrayList();
        String fn = ((String)this.fileName.get()).trim();
        if (!fn.isEmpty()) {
            Path filePath = class_310.method_1551().field_1697.toPath().resolve(fn);
        }
        try {
            List<String> lines = Files.readAllLines(filePath);
            var var4 = lines.iterator();
            while (var4.hasNext()) {
                String line = (String)var4.next();
                String trimmed = line.trim();
                while (trimmed.isEmpty()) {
                }
                String[] split = trimmed.split(":", 2);
                if (split.length == 2) {
                    String[] tmp0 = new String[2];
                    tmp0[0] = split[0].trim();
                    tmp0[1] = split[1].trim();
                    this.accounts.add(tmp0);
                }
            }
        }
        catch (IOException lines) {
            manual = ((String)this.manualAccounts.get()).trim();
            if (manual.isEmpty()) { /* goto @283; */ }
            lines = manual.split(",");
            var4 = lines.length;
            for (line = 0; line < var4; line++) {
                entry = lines[line];
                split = entry.trim().split(":", 2);
                if (split.length == 2) {
                    String[] tmp1 = new String[2];
                    tmp1[0] = split[0].trim();
                    tmp1[1] = split[1].trim();
                    this.accounts.add(tmp1);
                }
            }
        }
        manual = ((String)this.manualAccounts.get()).trim();
        if (manual.isEmpty()) { /* goto L283; */ }
        lines = manual.split(",");
        var4 = lines.length;
        for (line = 0; line < var4; line++) {
            entry = lines[line];
            split = entry.trim().split(":", 2);
            if (split.length == 2) {
                String[] tmp2 = new String[2];
                tmp2[0] = split[0].trim();
                tmp2[1] = split[1].trim();
                this.accounts.add(tmp2);
            }
        }
        if (this.accounts.isEmpty()) {
            this.toggle();
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (this.logged) {
            return;
        }
        this.logged = true;
        String playerName = this.mc.field_1724.method_5477().getString();
        String password = this.findPassword(playerName);
        if (password != null) {
            this.mc.field_1724.field_3944.method_45730("l " + password);
        }
    }

    private String findPassword(String name) {
        var var2 = this.accounts.iterator();
        while (var2.hasNext()) {
            String[] entry = (String[])var2.next();
            if (!entry[0].equalsIgnoreCase(name)) continue;
            return entry[1];
        }
        return null;
    }
}
