/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2338;

public class SafeWalk
extends Module {
    public SafeWalk() {
        super(AddonTemplate.Student, "Safe Walk", "Sneaks when near edge of block.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (!this.mc.field_1724.method_24828()) {
            return;
        }
        this.mc.field_1724.method_5660(this.isNearEdge());
        this.mc.field_1690.field_1832.method_23481(this.isNearEdge());
    }

    public void onDeactivate() {
        if (this.mc.field_1724 == null) {
            return;
        }
        this.mc.field_1724.method_5660(false);
        this.mc.field_1690.field_1832.method_23481(false);
    }

    private boolean isNearEdge() {
        double x = this.mc.field_1724.method_23317();
        double y = this.mc.field_1724.method_23318();
        double z = this.mc.field_1724.method_23321();
        double[] tmp0 = new double[2];
        tmp0[0] = 0.0000001;
        tmp0[1] = -0.0000001;
        double[] offsets = tmp0;
        var var8 = offsets;
        var var9 = var8.length;
        for (int var10 = 0; var10 < var9; var10++) {
            double ox = var8[var10];
            var var13 = offsets;
            var var14 = var13.length;
            for (int var15 = 0; var15 < var14; var15++) {
                double oz = var13[var15];
                class_2338 below = class_2338.method_49637(x + ox, y - 0.5, z + oz);
                if (!this.mc.field_1687.method_8320(below).method_26215()) continue;
                return true;
            }
        }
        return false;
    }
}
