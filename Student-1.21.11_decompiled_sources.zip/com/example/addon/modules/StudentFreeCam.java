/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.events.world.ChunkOcclusionEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.input.Input;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import org.joml.Vector3d;

public class StudentFreeCam
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<Double> speed = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("speed")).description("Tốc độ di chuyển camera")).defaultValue(1).min(0.1).sliderMax(5).build());
    public final Vector3d pos = new Vector3d();
    public final Vector3d prevPos = new Vector3d();
    public float yaw;
    public float pitch;
    public float prevYaw;
    public float prevPitch;
    private boolean forward;
    private boolean backward;
    private boolean left;
    private boolean right;
    private boolean up;
    private boolean down;

    public StudentFreeCam() {
        super(AddonTemplate.Student_esp, "Student-Free-Cam", "Smooth freecam.");
    }

    public void onActivate() {
        if (this.mc.field_1724 == null) {
            return;
        }
        class_243 eyePos = this.mc.field_1724.method_33571();
        this.pos.set(eyePos.field_1352, eyePos.field_1351, eyePos.field_1350);
        this.prevPos.set(this.pos);
        this.yaw = this.mc.field_1724.method_36454();
        this.pitch = this.mc.field_1724.method_36455();
        this.prevYaw = this.yaw;
        this.prevPitch = this.pitch;
        this.down = false;
        this.up = false;
        this.right = false;
        this.left = false;
        this.backward = false;
        this.forward = false;
    }

    public void onDeactivate() {
        this.down = false;
        this.up = false;
        this.right = false;
        this.left = false;
        this.backward = false;
        this.forward = false;
        this.mc.field_1690.field_1894.method_23481(false);
        this.mc.field_1690.field_1881.method_23481(false);
        this.mc.field_1690.field_1913.method_23481(false);
        this.mc.field_1690.field_1849.method_23481(false);
        this.mc.field_1690.field_1903.method_23481(false);
        this.mc.field_1690.field_1832.method_23481(false);
    }

    public void changeLookDirection(double dx, double dy) {
        double s = ((Double)this.mc.field_1690.method_42495().method_41753()).doubleValue() * 0.6 + 0.2;
        double multiplier = s * s * s * 8;
        this.yaw = this.yaw + (float)(dx * multiplier * 0.15);
        this.pitch = this.pitch + (float)(dy * multiplier * 0.15);
        this.pitch = class_3532.method_15363(this.pitch, -90f, 90f);
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1724 == null) {
            return;
        }
        this.prevPos.set(this.pos);
        this.prevYaw = this.yaw;
        this.prevPitch = this.pitch;
        this.forward = Input.isPressed(this.mc.field_1690.field_1894);
        this.backward = Input.isPressed(this.mc.field_1690.field_1881);
        this.left = Input.isPressed(this.mc.field_1690.field_1913);
        this.right = Input.isPressed(this.mc.field_1690.field_1849);
        this.up = Input.isPressed(this.mc.field_1690.field_1903);
        this.down = Input.isPressed(this.mc.field_1690.field_1832);
        this.mc.field_1690.field_1894.method_23481(false);
        this.mc.field_1690.field_1881.method_23481(false);
        this.mc.field_1690.field_1913.method_23481(false);
        this.mc.field_1690.field_1849.method_23481(false);
        this.mc.field_1690.field_1903.method_23481(false);
        this.mc.field_1690.field_1832.method_23481(false);
        class_243 fwd = class_243.method_1030(0f, this.yaw);
        class_243 side = class_243.method_1030(0f, this.yaw + 90f);
        double s = ((Double)this.speed.get()).doubleValue() * (Input.isPressed(this.mc.field_1690.field_1867) ? 2 : 1) * 0.2;
        double x = 0;
        double y = 0;
        double z = 0;
        if (this.forward) {
            x = x + fwd.field_1352 * s;
            z = z + fwd.field_1350 * s;
        }
        if (this.backward) {
            x = x - fwd.field_1352 * s;
            z = z - fwd.field_1350 * s;
        }
        if (this.right) {
            x = x + side.field_1352 * s;
            z = z + side.field_1350 * s;
        }
        if (this.left) {
            x = x - side.field_1352 * s;
            z = z - side.field_1350 * s;
        }
        if (this.up) {
            y = y + s;
        }
        if (this.down) {
            y = y - s;
        }
        this.pos.add(x, y, z);
    }

    @EventHandler
    private void onChunkOcclusion(ChunkOcclusionEvent event) {
        event.cancel();
    }

    public double getX(float t) {
        return class_3532.method_16436((double)t, this.prevPos.x, this.pos.x);
    }

    public double getY(float t) {
        return class_3532.method_16436((double)t, this.prevPos.y, this.pos.y);
    }

    public double getZ(float t) {
        return class_3532.method_16436((double)t, this.prevPos.z, this.pos.z);
    }

    public float getYaw(float t) {
        return class_3532.method_17821(t, this.prevYaw, this.yaw);
    }

    public float getPitch(float t) {
        return class_3532.method_16439(t, this.prevPitch, this.pitch);
    }
}
