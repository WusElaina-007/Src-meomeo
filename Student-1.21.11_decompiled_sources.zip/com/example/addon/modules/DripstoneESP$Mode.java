/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

public static enum DripstoneESP.Mode {
    public static final DripstoneESP.Mode Chat = new DripstoneESP.Mode("Chat", 0);
    public static final DripstoneESP.Mode Toast = new DripstoneESP.Mode("Toast", 1);
    public static final DripstoneESP.Mode Both = new DripstoneESP.Mode("Both", 2);
    private static final /* synthetic */ DripstoneESP.Mode[] $VALUES;

    public static DripstoneESP.Mode[] values() {
        return (DripstoneESP.Mode[])$VALUES.clone();
    }

    public static DripstoneESP.Mode valueOf(String name) {
        return (DripstoneESP.Mode)Enum.valueOf(DripstoneESP.Mode.class, name);
    }

    private DripstoneESP.Mode() {
        super(var1, var2);
    }

    static {
        $VALUES = DripstoneESP.Mode.$values();
    }
}
