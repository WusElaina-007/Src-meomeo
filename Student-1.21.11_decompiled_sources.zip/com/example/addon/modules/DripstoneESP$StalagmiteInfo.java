/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import net.minecraft.class_2338;

private static class DripstoneESP.StalagmiteInfo {
    final int length;
    final class_2338 topPos;

    DripstoneESP.StalagmiteInfo(int length, class_2338 topPos) {
        this.length = length;
        this.topPos = topPos;
    }
}
