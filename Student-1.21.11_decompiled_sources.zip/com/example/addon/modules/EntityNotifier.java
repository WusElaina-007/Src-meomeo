/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.util.List;
import java.util.Set;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringListSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_2561;

public class EntityNotifier
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<Set<class_1299<?>>> entities;
    private final Setting<List<String>> whitelist;
    private final Setting<EntityNotifier.AlertSound> sound;
    private long lastSoundTime;
    private static final long COOLDOWN_MS = 500L;

    public EntityNotifier() {
        super(AddonTemplate.Student, "entity-notifier", "Alert when entity appears.");
        class_1299[] tmp0 = new class_1299[1];
        tmp0[0] = class_1299.field_6097;
        this.entities = this.sgGeneral.add(((EntityTypeListSetting.Builder)((EntityTypeListSetting.Builder)new EntityTypeListSetting.Builder().name("entities")).description("Entity Notifier")).defaultValue(tmp0).build());
        this.whitelist = this.sgGeneral.add(((StringListSetting.Builder)((StringListSetting.Builder)new StringListSetting.Builder().name("whitelist")).description("White List")).build());
        this.sound = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("sound")).description("Sound Notifier")).defaultValue(EntityNotifier.AlertSound.ANVIL)).build());
        this.lastSoundTime = 0L;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (this.mc.field_1687 == null || this.mc.field_1724 == null) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now - this.lastSoundTime < 500L) {
            return;
        }
        var var4 = this.mc.field_1687.method_18112().iterator();
        L56: ;
        if (!var4.hasNext()) { /* goto L242; */ }
        class_1297 e = (class_1297)var4.next();
        while (e == this.mc.field_1724) {
        }
        while (!((Set)this.entities.get()).contains(e.method_5864())) {
        }
        if (e instanceof class_1657) {
            class_1657 player = (class_1657)e;
            String name = player.method_5477().getString();
            while (((List)this.whitelist.get()).contains(name)) {
            }
            this.sendChat("Player found: " + name);
        } else {
            String mobName = e.method_5864().method_5897().getString();
            this.sendChat("Mob found: " + mobName);
        }
        this.mc.field_1724.method_5783(((EntityNotifier.AlertSound)this.sound.get()).sound, 1f, 1f);
        this.lastSoundTime = now;
        /* goto L242; */
        L242: ;
    }

    private void sendChat(String message) {
        this.mc.field_1724.method_7353(class_2561.method_43470(message), false);
    }
}
