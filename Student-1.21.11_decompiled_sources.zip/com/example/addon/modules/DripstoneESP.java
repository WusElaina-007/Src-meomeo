/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.MeteorToast;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2791;
import net.minecraft.class_2818;

public class DripstoneESP
extends Module {
    private final SettingGroup sgStalactite = this.settings.createGroup("Stalactite ESP");
    private final SettingGroup sgStalagmite = this.settings.createGroup("Stalagmite ESP");
    private final SettingGroup sgThreading = this.settings.createGroup("Threading");
    private final SettingGroup sgNotifications = this.settings.createGroup("Notifications");
    private final Setting<SettingColor> stalactiteColor = this.sgStalactite.add(((ColorSetting.Builder)new ColorSetting.Builder().name("esp-color")).defaultValue(new SettingColor(128, 128, 128, 100)).build());
    private final Setting<ShapeMode> stalactiteShapeMode = this.sgStalactite.add(((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("shape-mode")).defaultValue(ShapeMode.Both)).build());
    private final Setting<Boolean> stalactiteTracers = this.sgStalactite.add(((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("tracers")).defaultValue(true)).build());
    private final Setting<SettingColor> stalactiteTracerColor;
    private final Setting<Integer> stalactiteMinLength;
    private final Setting<SettingColor> stalagmiteColor;
    private final Setting<ShapeMode> stalagmiteShapeMode;
    private final Setting<Boolean> stalagmiteTracers;
    private final Setting<SettingColor> stalagmiteTracerColor;
    private final Setting<Integer> stalagmiteMinLength;
    private final Setting<Boolean> showNotifications;
    private final Setting<DripstoneESP.Mode> notificationMode;
    private final Setting<Integer> notificationLengthThreshold;
    private final Setting<Boolean> useThreading;
    private final Setting<Integer> threadPoolSize;
    private final Set<class_2338> longStalactiteBottoms;
    private final Set<class_2338> longStalagmiteTops;
    private ExecutorService threadPool;

    public DripstoneESP() {
        super(AddonTemplate.Student_esp, "DripstoneESP", "ESP for long dripstones with tracers and threading.");
        Objects.requireNonNull(this.stalactiteTracers);
        this.stalactiteTracerColor = this.sgStalactite.add(((ColorSetting.Builder)((ColorSetting.Builder)new ColorSetting.Builder().name("tracer-color")).defaultValue(new SettingColor(128, 128, 128, 200)).visible(this.stalactiteTracers::get)).build());
        this.stalactiteMinLength = this.sgStalactite.add(((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("min-length")).defaultValue(4)).min(4).max(16).build());
        this.stalagmiteColor = this.sgStalagmite.add(((ColorSetting.Builder)new ColorSetting.Builder().name("esp-color")).defaultValue(new SettingColor(160, 160, 160, 100)).build());
        this.stalagmiteShapeMode = this.sgStalagmite.add(((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("shape-mode")).defaultValue(ShapeMode.Both)).build());
        this.stalagmiteTracers = this.sgStalagmite.add(((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("tracers")).defaultValue(true)).build());
        Objects.requireNonNull(this.stalagmiteTracers);
        this.stalagmiteTracerColor = this.sgStalagmite.add(((ColorSetting.Builder)((ColorSetting.Builder)new ColorSetting.Builder().name("tracer-color")).defaultValue(new SettingColor(160, 160, 160, 200)).visible(this.stalagmiteTracers::get)).build());
        this.stalagmiteMinLength = this.sgStalagmite.add(((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("min-length")).defaultValue(8)).min(4).max(16).build());
        this.showNotifications = this.sgNotifications.add(((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("notifications")).defaultValue(true)).build());
        Objects.requireNonNull(this.showNotifications);
        this.notificationMode = this.sgNotifications.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("notification-mode")).defaultValue(DripstoneESP.Mode.Both)).visible(this.showNotifications::get)).build());
        Objects.requireNonNull(this.showNotifications);
        this.notificationLengthThreshold = this.sgNotifications.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("notification-length")).defaultValue(8)).min(4).max(20).visible(this.showNotifications::get)).build());
        this.useThreading = this.sgThreading.add(((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("enable-threading")).defaultValue(true)).build());
        Objects.requireNonNull(this.useThreading);
        this.threadPoolSize = this.sgThreading.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("thread-pool-size")).defaultValue(2)).min(1).max(8).visible(this.useThreading::get)).build());
        this.longStalactiteBottoms = ConcurrentHashMap.newKeySet();
        this.longStalagmiteTops = ConcurrentHashMap.newKeySet();
    }

    public void onActivate() {
        if (((Boolean)this.useThreading.get()).booleanValue()) {
            this.threadPool = Executors.newFixedThreadPool(((Integer)this.threadPoolSize.get()).intValue());
        }
        this.longStalactiteBottoms.clear();
        this.longStalagmiteTops.clear();
        var var1 = Utils.chunks().iterator();
        while (var1.hasNext()) {
            class_2791 chunk = (class_2791)var1.next();
            if (!chunk instanceof class_2818) { /* goto @135; */ }
            class_2818 wc = (class_2818)chunk;
            if (((Boolean)this.useThreading.get()).booleanValue()) {
                this.threadPool.submit(this::lambda$onActivate$0 /* captured: wc */);
            } else {
                this.scanChunk(wc);
            }
        }
    }

    public void onDeactivate() {
        if (this.threadPool != null) {
            this.threadPool.shutdown();
            this.threadPool = null;
        }
        this.longStalactiteBottoms.clear();
        this.longStalagmiteTops.clear();
    }

    @EventHandler
    private void onChunkLoad(ChunkDataEvent event) {
        this.threadPool.submit(this::lambda$onChunkLoad$1 /* captured: event */);
        if (((Boolean)this.useThreading.get()).booleanValue() && this.threadPool != null) {
        } else {
            this.scanChunk(event.chunk());
        }
    }

    @EventHandler
    private void onBlockUpdate(BlockUpdateEvent event) {
        Runnable scanTask = this::lambda$onBlockUpdate$2 /* captured: event */;
        this.threadPool.submit(scanTask);
        if (((Boolean)this.useThreading.get()).booleanValue() && this.threadPool != null) {
        } else {
            scanTask.run();
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        var var2 = this.longStalactiteBottoms.iterator();
        while (var2.hasNext()) {
            class_2338 pos = (class_2338)var2.next();
            double distSq = this.mc.field_1724.method_33571().method_1028((double)pos.method_10263() + 0.5, (double)pos.method_10264() + 0.5, (double)pos.method_10260() + 0.5);
            while (distSq > 10000) {
            }
            Color color = new Color((Color)this.stalactiteColor.get());
            event.renderer.box(pos, color, color, (ShapeMode)this.stalactiteShapeMode.get(), 0);
            if (!((Boolean)this.stalactiteTracers.get()).booleanValue()) continue;
            event.renderer.line(RenderUtils.center.field_1352, RenderUtils.center.field_1351, RenderUtils.center.field_1350, (double)pos.method_10263() + 0.5, (double)pos.method_10264() + 0.5, (double)pos.method_10260() + 0.5, (Color)this.stalactiteTracerColor.get());
        }
        var2 = this.longStalagmiteTops.iterator();
        while (var2.hasNext()) {
            pos = (class_2338)var2.next();
            distSq = this.mc.field_1724.method_33571().method_1028((double)pos.method_10263() + 0.5, (double)pos.method_10264() + 0.5, (double)pos.method_10260() + 0.5);
            while (distSq > 10000) {
            }
            color = new Color((Color)this.stalagmiteColor.get());
            event.renderer.box(pos, color, color, (ShapeMode)this.stalagmiteShapeMode.get(), 0);
            if (!((Boolean)this.stalagmiteTracers.get()).booleanValue()) continue;
            event.renderer.line(RenderUtils.center.field_1352, RenderUtils.center.field_1351, RenderUtils.center.field_1350, (double)pos.method_10263() + 0.5, (double)pos.method_10264() + 0.5, (double)pos.method_10260() + 0.5, (Color)this.stalagmiteTracerColor.get());
        }
    }

    private void scanChunk(class_2818 chunk) {
        int startX = chunk.method_12004().method_8326();
        int startZ = chunk.method_12004().method_8328();
        int minY = chunk.method_31607();
        int maxY = minY + chunk.method_31605();
        for (int x = startX; x < startX + 16; x++) {
            for (int z = startZ; z < startZ + 16; z++) {
                for (int y = minY; y < maxY; y++) {
                    class_2338 pos = new class_2338(x, y, z);
                    class_2680 state = chunk.method_8320(pos);
                    if (this.isDripstoneTipDown(state)) {
                        StalactiteInfo info = this.getStalactiteInfo(pos);
                        if (info != null) {
                            if (!info.length >= ((Integer)this.stalactiteMinLength.get()).intValue()) continue;
                            this.longStalactiteBottoms.add(info.bottomPos);
                        }
                    } else {
                        if (this.isDripstoneTipUp(state)) {
                            StalagmiteInfo info = this.getStalagmiteInfo(pos);
                            if (info != null) {
                                if (!info.length >= ((Integer)this.stalagmiteMinLength.get()).intValue()) continue;
                                this.longStalagmiteTops.add(info.topPos);
                            }
                        }
                    }
                }
            }
        }
    }

    private boolean isDripstoneTipDown(class_2680 state) {
        return state.method_27852(class_2246.field_28048) && state.method_28498(class_2741.field_28062) && state.method_11654(class_2741.field_28062) == class_2350.field_11033;
    }

    private boolean isDripstoneTipUp(class_2680 state) {
        return state.method_27852(class_2246.field_28048) && state.method_28498(class_2741.field_28062) && state.method_11654(class_2741.field_28062) == class_2350.field_11036;
    }

    private DripstoneESP.StalactiteInfo getStalactiteInfo(class_2338 tipPos) {
        if (this.mc.field_1687 == null) {
            return null;
        }
        int length = 0;
        class_2338 current = tipPos;
        class_2338 bottom = tipPos;
        while (current.method_10264() >= this.mc.field_1687.method_31607()) {
            if (!this.isDripstoneTipDown(this.mc.field_1687.method_8320(current))) break;
            length++;
            bottom = current;
            current = current.method_10074();
        }
        return length > 0 ? new DripstoneESP.StalactiteInfo(length, bottom) : null;
    }

    private DripstoneESP.StalagmiteInfo getStalagmiteInfo(class_2338 tipPos) {
        if (this.mc.field_1687 == null) {
            return null;
        }
        int length = 0;
        class_2338 current = tipPos;
        class_2338 top = tipPos;
        while (current.method_10264() < 320) {
            if (!this.isDripstoneTipUp(this.mc.field_1687.method_8320(current))) break;
            length++;
            top = current;
            current = current.method_10084();
        }
        return length > 0 ? new DripstoneESP.StalagmiteInfo(length, top) : null;
    }

    private void notifyDripstoneFound(String type, class_2338 pos, int length) {
        if (!((Boolean)this.showNotifications.get()).booleanValue() || length < ((Integer)this.notificationLengthThreshold.get()).intValue()) {
            return;
        }
        String msg = String.format("%s found at [%d, %d, %d] (len: %d)", type, pos.method_10263(), pos.method_10264(), pos.method_10260(), length);
        String subText = type + " (" + length + ")";
        if (this.notificationMode.get() == DripstoneESP.Mode.Chat || this.notificationMode.get() == DripstoneESP.Mode.Both) {
            this.info("(highlight)%s", msg);
        }
        if (this.notificationMode.get() == DripstoneESP.Mode.Toast || this.notificationMode.get() == DripstoneESP.Mode.Both) {
            this.mc.method_1566().method_1999(new MeteorToast.Builder("DripstoneESP").text(subText).icon(class_1802.field_28042).build());
        }
    }
}
