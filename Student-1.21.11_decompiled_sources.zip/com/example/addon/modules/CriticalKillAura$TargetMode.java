/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

public static enum CriticalKillAura.TargetMode {
    public static final CriticalKillAura.TargetMode Closest = new CriticalKillAura.TargetMode("Closest", 0);
    public static final CriticalKillAura.TargetMode Farthest = new CriticalKillAura.TargetMode("Farthest", 1);
    public static final CriticalKillAura.TargetMode LowestHealth = new CriticalKillAura.TargetMode("LowestHealth", 2);
    public static final CriticalKillAura.TargetMode HighestHealth = new CriticalKillAura.TargetMode("HighestHealth", 3);
    private static final /* synthetic */ CriticalKillAura.TargetMode[] $VALUES;

    public static CriticalKillAura.TargetMode[] values() {
        return (CriticalKillAura.TargetMode[])$VALUES.clone();
    }

    public static CriticalKillAura.TargetMode valueOf(String name) {
        return (CriticalKillAura.TargetMode)Enum.valueOf(CriticalKillAura.TargetMode.class, name);
    }

    private CriticalKillAura.TargetMode() {
        super(var1, var2);
    }

    static {
        $VALUES = CriticalKillAura.TargetMode.$values();
    }
}
