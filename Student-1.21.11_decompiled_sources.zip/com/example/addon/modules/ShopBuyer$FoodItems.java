/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

public static enum ShopBuyer.FoodItems {
    public static final ShopBuyer.FoodItems POTATO = new ShopBuyer.FoodItems("POTATO", 0);
    public static final ShopBuyer.FoodItems SWEET_BERRIES = new ShopBuyer.FoodItems("SWEET_BERRIES", 1);
    public static final ShopBuyer.FoodItems MELON_SLICE = new ShopBuyer.FoodItems("MELON_SLICE", 2);
    public static final ShopBuyer.FoodItems CARROT = new ShopBuyer.FoodItems("CARROT", 3);
    public static final ShopBuyer.FoodItems APPLE = new ShopBuyer.FoodItems("APPLE", 4);
    public static final ShopBuyer.FoodItems COOKED_CHICKEN = new ShopBuyer.FoodItems("COOKED_CHICKEN", 5);
    public static final ShopBuyer.FoodItems COOKED_BEEF = new ShopBuyer.FoodItems("COOKED_BEEF", 6);
    public static final ShopBuyer.FoodItems GOLDEN_CARROT = new ShopBuyer.FoodItems("GOLDEN_CARROT", 7);
    public static final ShopBuyer.FoodItems GOLDEN_APPLE = new ShopBuyer.FoodItems("GOLDEN_APPLE", 8);
    private static final /* synthetic */ ShopBuyer.FoodItems[] $VALUES;

    public static ShopBuyer.FoodItems[] values() {
        return (ShopBuyer.FoodItems[])$VALUES.clone();
    }

    public static ShopBuyer.FoodItems valueOf(String name) {
        return (ShopBuyer.FoodItems)Enum.valueOf(ShopBuyer.FoodItems.class, name);
    }

    private ShopBuyer.FoodItems() {
        super(var1, var2);
    }

    static {
        $VALUES = ShopBuyer.FoodItems.$values();
    }
}
