/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_368;
import net.minecraft.class_374;

private static class ClusterFinder.ClusterToast
implements class_368 {
    private final class_1799 icon;
    private final class_2561 title;
    private final class_2561 description;
    private long startTime = -1L;
    private class_368.class_369 visibility;

    public ClusterFinder.ClusterToast(class_1799 icon, class_2561 title, class_2561 description) {
        this.visibility = class_368.class_369.field_2210;
        this.icon = icon;
        this.title = title;
        this.description = description;
    }

    public class_368.class_369 method_61988() {
        return this.visibility;
    }

    public void method_61989(class_374 manager, long time) {
        if (this.startTime == -1L) {
            this.startTime = time;
        }
        if (time - this.startTime >= 5000L) {
            this.visibility = class_368.class_369.field_2209;
        }
    }

    public void method_1986(class_332 context, class_327 textRenderer, long currentTime) {
        context.method_25294(0, 0, 160, 32, -1442840576);
        int purple = -6736897;
        context.method_25294(0, 0, 160, 1, purple);
        context.method_25294(0, 31, 160, 32, purple);
        context.method_25294(0, 1, 1, 31, purple);
        context.method_25294(159, 1, 160, 31, purple);
        if (this.icon != null) {
            if (!this.icon.method_7960()) {
                context.method_51427(this.icon, 8, 8);
            }
        }
        if (this.title != null) {
            context.method_51439(textRenderer, this.title, 32, 7, 16776960, false);
        }
        if (this.description != null) {
            context.method_51439(textRenderer, this.description, 32, 18, 16777215, false);
        }
    }
}
