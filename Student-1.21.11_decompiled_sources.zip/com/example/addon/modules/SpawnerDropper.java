/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2496;
import net.minecraft.class_2828;
import net.minecraft.class_3965;
import net.minecraft.class_476;

public class SpawnerDropper
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<Boolean> clickChest = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("click-chest")).description("Click chest in spawner GUI then drop items inside")).defaultValue(false)).build());
    private final Setting<List<class_1792>> itemsToDrop;
    private final Setting<Integer> actionDelaySetting;
    private final Setting<Integer> dropDelayTicks;
    private SpawnerDropper.State currentState;
    private int tickCounter;
    private int waitCounter;
    private int cycleTickCounter;
    private class_2338 targetSpawner;
    private final List<class_2338> spawners;
    private int spawnerIndex;
    private float savedYaw;
    private float savedPitch;

    public SpawnerDropper() {
        super(AddonTemplate.Student, "Spawner-Dropper", "Auto drop spawner loot");
        class_1792[] tmp0 = new class_1792[2];
        tmp0[0] = class_1802.field_8606;
        tmp0[1] = class_1802.field_8107;
        this.itemsToDrop = this.sgGeneral.add(((ItemListSetting.Builder)((ItemListSetting.Builder)new ItemListSetting.Builder().name("items-to-drop")).description("Items to drop from spawner/chest GUI")).defaultValue(tmp0).build());
        this.actionDelaySetting = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("action-delay-ticks")).description("Delay between each action.")).defaultValue(20)).min(1).max(200).build());
        this.dropDelayTicks = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("drop-delay-ticks")).description("Ticks between cycles.")).defaultValue(6000)).min(1).max(72000).build());
        this.currentState = SpawnerDropper.State.SCANNING;
        this.tickCounter = 0;
        this.waitCounter = 0;
        this.cycleTickCounter = 0;
        this.targetSpawner = null;
        this.spawners = new ArrayList();
        this.spawnerIndex = 0;
        this.savedYaw = 0f;
        this.savedPitch = 0f;
    }

    public void onActivate() {
        this.currentState = SpawnerDropper.State.SCANNING;
        this.tickCounter = 0;
        this.waitCounter = 0;
        this.cycleTickCounter = 0;
        this.spawners.clear();
        this.spawnerIndex = 0;
        this.targetSpawner = null;
    }

    public void onDeactivate() {
        if (this.mc.field_1755 != null) {
            this.mc.field_1724.method_7346();
        }
    }

    private float calcYawTo(class_2338 pos) {
        double dx = class_243.method_24953(pos).field_1352 - this.mc.field_1724.method_23317();
        double dz = class_243.method_24953(pos).field_1350 - this.mc.field_1724.method_23321();
        return (float)Math.toDegrees(Math.atan2(dz, dx)) - 90f;
    }

    private float calcPitchTo(class_2338 pos) {
        double dx = class_243.method_24953(pos).field_1352 - this.mc.field_1724.method_23317();
        double dy = class_243.method_24953(pos).field_1351 - this.mc.field_1724.method_23320();
        double dz = class_243.method_24953(pos).field_1350 - this.mc.field_1724.method_23321();
        double hDist = Math.sqrt(dx * dx + dz * dz);
        return (float)-Math.toDegrees(Math.atan2(dy, hDist));
    }

    private void sendSilentRotation(float yaw, float pitch) {
        this.mc.field_1724.field_3944.method_52787(new class_2828.class_2831(yaw, pitch, this.mc.field_1724.method_24828(), false));
    }

    private void interactWithBlock(class_2338 pos) {
        class_243 playerPos = this.mc.field_1724.method_73189();
        class_243 center = class_243.method_24953(pos);
        double dx = playerPos.field_1352 - center.field_1352;
        double dy = playerPos.field_1351 - center.field_1351;
        double dz = playerPos.field_1350 - center.field_1350;
        double ax = Math.abs(dx);
        double ay = Math.abs(dy);
        double az = Math.abs(dz);
        if (ay >= ax) {
            if (ay < az) { /* goto @107; */ }
            class_2350 face = dy > 0 ? class_2350.field_11036 : class_2350.field_11033;
        } else {
            if (ax >= az) {
                class_2350 face = dx > 0 ? class_2350.field_11034 : class_2350.field_11039;
            } else {
                class_2350 face = dz > 0 ? class_2350.field_11035 : class_2350.field_11043;
            }
        }
        class_3965 hit = new class_3965(center, face, pos, false);
        this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, hit);
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        this.tickCounter = this.tickCounter + 1;
        this.waitCounter = this.waitCounter + 1;
        if (this.currentState == SpawnerDropper.State.WAITING_CYCLE) {
            this.cycleTickCounter = this.cycleTickCounter + 1;
            if (this.cycleTickCounter >= ((Integer)this.dropDelayTicks.get()).intValue()) {
                this.currentState = SpawnerDropper.State.SCANNING;
                this.tickCounter = 0;
                this.waitCounter = 0;
                this.cycleTickCounter = 0;
                this.spawners.clear();
                this.spawnerIndex = 0;
                this.targetSpawner = null;
            }
            return;
        }
        if (this.tickCounter >= ((Integer)this.actionDelaySetting.get()).intValue()) {
            this.executeCurrentState();
            this.tickCounter = 0;
        }
    }

    private void executeCurrentState() {
        switch (this.currentState.ordinal()) {
            case 0::
                this.spawners.clear();
                class_2338 playerPos = this.mc.field_1724.method_24515();
                int radius = 5;
                for (int x = -radius; x <= radius; x++) {
                    for (int y = -radius; y <= radius; y++) {
                        for (int z = -radius; z <= radius; z++) {
                            class_2338 pos = playerPos.method_10069(x, y, z);
                            class_2248 block = this.mc.field_1687.method_8320(pos).method_26204();
                            if (!block instanceof class_2496) continue;
                            this.spawners.add(pos);
                        }
                    }
                }
                if (this.spawners.isEmpty()) {
                    this.currentState = SpawnerDropper.State.WAITING_CYCLE;
                    this.cycleTickCounter = 0;
                    return;
                }
                this.spawnerIndex = 0;
                this.targetSpawner = (class_2338)this.spawners.get(0);
                this.currentState = SpawnerDropper.State.MOVING;
                /* goto @1101; */
            case 1::
                if (this.targetSpawner == null) {
                    this.currentState = SpawnerDropper.State.SCANNING;
                    return;
                }
                dist = this.mc.field_1724.method_73189().method_1022(class_243.method_24953(this.targetSpawner));
                if (dist <= 4.5) {
                    this.savedYaw = this.mc.field_1724.method_36454();
                    this.savedPitch = this.mc.field_1724.method_36455();
                    this.currentState = SpawnerDropper.State.SILENT_ROTATE;
                }
                /* goto @1101; */
            case 2::
                if (this.targetSpawner == null) {
                    this.currentState = SpawnerDropper.State.SCANNING;
                    return;
                }
                this.sendSilentRotation(this.calcYawTo(this.targetSpawner), this.calcPitchTo(this.targetSpawner));
                this.currentState = SpawnerDropper.State.OPENING;
                /* goto @1101; */
            case 3::
                if (this.mc.field_1755 instanceof class_476) {
                    this.sendSilentRotation(this.savedYaw, this.savedPitch);
                    this.currentState = SpawnerDropper.State.DROPPING;
                    return;
                }
                if (this.targetSpawner == null) { /* goto @1101; */ }
                this.interactWithBlock(this.targetSpawner);
                /* goto @1101; */
            case 4::
                handler = this.mc.field_1755;
                if (handler instanceof class_476) {
                    screen = (class_476)handler;
                } else {
                    this.currentState = SpawnerDropper.State.OPENING;
                    return;
                }
                handler = screen.method_17577();
                title = screen.method_25440().getString();
                isSpawner = title.contains("spawner") || title.contains("Spawner") || title.contains("SPAWNER") || title.contains("lồng triệu hồi") || title.contains("Lồng triệu hồi") || title.contains("LỒNG TRIỆU HỒI");
                if (!isSpawner) {
                    this.currentState = SpawnerDropper.State.CLOSING_GUI;
                    return;
                }
                if (((Boolean)this.clickChest.get()).booleanValue()) {
                    z = handler.field_7761.iterator();
                    while (z.hasNext()) {
                        slot = (class_1735)z.next();
                        while (slot.field_7871 == this.mc.field_1724.method_31548()) {
                        }
                        item = slot.method_7677().method_7909();
                        if (item == class_1802.field_8106 || item == class_1802.field_8247 || item == class_1802.field_16307) {
                            this.mc.field_1761.method_2906(handler.field_7763, slot.field_7874, 0, class_1713.field_7790, this.mc.field_1724);
                            this.currentState = SpawnerDropper.State.CHEST_GUI;
                            return;
                        }
                    }
                    this.currentState = SpawnerDropper.State.CLOSING_GUI;
                } else {
                    z = handler.field_7761.iterator();
                    while (z.hasNext()) {
                        slot = (class_1735)z.next();
                        while (slot.field_7871 == this.mc.field_1724.method_31548()) {
                        }
                        while (slot.method_7677().method_7960()) {
                        }
                        while (!((List)this.itemsToDrop.get()).contains(slot.method_7677().method_7909())) {
                        }
                        this.mc.field_1761.method_2906(handler.field_7763, slot.field_7874, 1, class_1713.field_7795, this.mc.field_1724);
                    }
                    this.currentState = SpawnerDropper.State.WAITING_CLOSE;
                    this.waitCounter = 0;
                }
                /* goto @1101; */
            case 5::
                handler = this.mc.field_1755;
                if (handler instanceof class_476) {
                    screen = (class_476)handler;
                } else {
                    return;
                }
                handler = screen.method_17577();
                title = handler.field_7761.iterator();
                while (title.hasNext()) {
                    slot = (class_1735)title.next();
                    while (slot.field_7871 == this.mc.field_1724.method_31548()) {
                    }
                    while (slot.method_7677().method_7960()) {
                    }
                    while (!((List)this.itemsToDrop.get()).contains(slot.method_7677().method_7909())) {
                    }
                    this.mc.field_1761.method_2906(handler.field_7763, slot.field_7874, 1, class_1713.field_7795, this.mc.field_1724);
                }
                this.currentState = SpawnerDropper.State.CLOSING_GUI;
                /* goto @1101; */
            case 6::
                if (this.waitCounter < 10) { /* goto @1101; */ }
                this.currentState = SpawnerDropper.State.CLOSING_GUI;
                /* goto @1101; */
            case 7::
                if (this.mc.field_1755 != null) {
                    this.mc.field_1724.method_7346();
                }
                this.spawnerIndex = this.spawnerIndex + 1;
                if (this.spawnerIndex < this.spawners.size()) {
                    this.targetSpawner = (class_2338)this.spawners.get(this.spawnerIndex);
                    this.currentState = SpawnerDropper.State.MOVING;
                    this.waitCounter = 0;
                } else {
                    this.currentState = SpawnerDropper.State.WAITING_CYCLE;
                    this.cycleTickCounter = 0;
                }
            default:
                return;
        }
    }

    public String getInfoString() {
        if (!this.isActive()) {
            return null;
        }
        if (this.currentState == SpawnerDropper.State.WAITING_CYCLE) {
            int remaining = ((Integer)this.dropDelayTicks.get()).intValue() - this.cycleTickCounter;
            return "WAITING | " + remaining + "t";
        }
        return this.currentState.name().replace("_", " ");
    }
}
