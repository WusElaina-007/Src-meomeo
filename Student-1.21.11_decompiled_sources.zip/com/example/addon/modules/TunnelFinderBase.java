/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2818;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class TunnelFinderBase
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final SettingGroup sgWebhook = this.settings.createGroup("Webhook");
    private final SettingGroup sgSound = this.settings.createGroup("Sound");
    private final Setting<Integer> targetY = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("target-y")).description("Y level gửi #goto")).defaultValue(-60)).min(-64).sliderMin(-64).sliderMax(320).build());
    private final Setting<Integer> containerLimit = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("container-limit")).description("Số container tối thiểu để coi là base")).defaultValue(10)).min(1).sliderMax(100).build());
    private final Setting<List<class_2248>> targetBlocks;
    private final Setting<Integer> scanRadius;
    private final Setting<Boolean> webhookEnabled;
    private final Setting<String> webhookUrl;
    private final Setting<Boolean> disconnectOnFound;
    private final Setting<Double> volume;
    private TunnelFinderBase.State state;
    private boolean baseFound;
    private int waitTimer;

    public TunnelFinderBase() {
        super(AddonTemplate.Student_esp, "TunnelFinderBase", "Goto Y level, tunnel, and find base.");
        class_2248[] tmp0 = new class_2248[3];
        tmp0[0] = class_2246.field_10034;
        tmp0[1] = class_2246.field_16328;
        tmp0[2] = class_2246.field_10603;
        this.targetBlocks = this.sgGeneral.add(((BlockListSetting.Builder)new BlockListSetting.Builder().name("target-blocks")).defaultValue(tmp0).build());
        this.scanRadius = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("scan-radius")).description("Bán kính chunk scan tìm base")).defaultValue(6)).min(1).sliderMax(20).build());
        this.webhookEnabled = this.sgWebhook.add(((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("enable-webhook")).defaultValue(true)).build());
        this.webhookUrl = this.sgWebhook.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("webhook-url")).description("Discord Webhook URL")).defaultValue("")).build());
        this.disconnectOnFound = this.sgWebhook.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("disconnect-on-found")).description("Tự out game khi phát hiện base")).defaultValue(true)).build());
        this.volume = this.sgSound.add(((DoubleSetting.Builder)new DoubleSetting.Builder().name("volume")).defaultValue(1).min(0).max(5).build());
        this.state = TunnelFinderBase.State.GOTO;
        this.baseFound = false;
        this.waitTimer = 0;
    }

    public void onActivate() {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        this.baseFound = false;
        this.waitTimer = 0;
        this.state = TunnelFinderBase.State.GOTO;
        this.mc.method_1562().method_45729("#goto " + String.valueOf(this.targetY.get()));
        this.state = TunnelFinderBase.State.WAIT_Y;
    }

    public void onDeactivate() {
        this.mc.method_1562().method_45729("#stop");
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (this.baseFound) {
            return;
        }
        switch (this.state.ordinal()) {
            case 1::
                int currentY = this.mc.field_1724.method_24515().method_10264();
                if (currentY <= ((Integer)this.targetY.get()).intValue() + 2) {
                    this.mc.method_1562().method_45729("#tunnel");
                    this.waitTimer = 0;
                    this.state = TunnelFinderBase.State.TUNNEL;
                }
                this.waitTimer = this.waitTimer + 1;
                if (this.waitTimer >= 600) {
                    this.waitTimer = 0;
                    this.mc.method_1562().method_45729("#goto " + String.valueOf(this.targetY.get()));
                }
                /* goto @213; */
            case 2::
                this.waitTimer = this.waitTimer + 1;
                if (this.waitTimer < 20) { /* goto @213; */ }
                this.waitTimer = 0;
                this.state = TunnelFinderBase.State.SCANNING;
                /* goto @213; */
            case 3::
                this.scanForBase();
            default:
                return;
        }
    }

    private void scanForBase() {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        int px = this.mc.field_1724.method_24515().method_10263() >> 4;
        int pz = this.mc.field_1724.method_24515().method_10260() >> 4;
        int radius = ((Integer)this.scanRadius.get()).intValue();
        for (int x = px - radius; x <= px + radius; x++) {
            for (int z = pz - radius; z <= pz + radius; z++) {
                if (!this.mc.field_1687.method_8393(x, z)) {
                } else {
                    class_2818 chunk = this.mc.field_1687.method_8497(x, z);
                    int containerCount = 0;
                    var var8 = chunk.method_12214().values().iterator();
                    while (var8.hasNext()) {
                        class_2586 be = (class_2586)var8.next();
                        class_2338 pos = be.method_11016();
                        class_2248 block = this.mc.field_1687.method_8320(pos).method_26204();
                        if (!((List)this.targetBlocks.get()).contains(block)) continue;
                        containerCount++;
                    }
                    if (containerCount >= ((Integer)this.containerLimit.get()).intValue()) {
                        this.foundBase();
                        return;
                    }
                }
            }
        }
    }

    private void foundBase() {
        if (this.baseFound) {
            return;
        }
        this.baseFound = true;
        int x = this.mc.field_1724.method_24515().method_10263();
        int y = this.mc.field_1724.method_24515().method_10264();
        int z = this.mc.field_1724.method_24515().method_10260();
        String server = this.mc.method_1558() != null ? this.mc.method_1558().field_3761 : "Unknown";
        String playerName = this.mc.field_1724.method_5477().getString();
        this.info("§a§lBase Found! X: %d Y: %d Z: %d", x, y, z);
        this.mc.method_1562().method_45729("#stop");
        this.mc.field_1687.method_8396(this.mc.field_1724, this.mc.field_1724.method_24515(), class_3417.field_14627, class_3419.field_15250, ((Double)this.volume.get()).floatValue(), 1f);
        if (((Boolean)this.webhookEnabled.get()).booleanValue()) {
            if (!((String)this.webhookUrl.get()).isEmpty()) {
                this.sendWebhook(playerName, server, x, y, z);
            }
        }
        if (((Boolean)this.disconnectOnFound.get()).booleanValue()) {
            this.mc.execute(this::lambda$foundBase$0);
        }
        this.toggle();
    }

    private void sendWebhook(String player, String server, int x, int y, int z) {
        String json = String.format("{\n  \"embeds\": [{\n    \"title\": \"🏠 Base Found!\",\n    \"color\": 65280,\n    \"fields\": [\n      {\"name\": \"Player\", \"value\": \"%s\", \"inline\": true},\n      {\"name\": \"Server\", \"value\": \"%s\", \"inline\": true},\n      {\"name\": \"Coordinates\", \"value\": \"X: %d Y: %d Z: %d\", \"inline\": false}\n    ]\n  }]\n}\n", player, server, x, y, z);
        Thread.ofVirtual().start(this::lambda$sendWebhook$1 /* captured: json */);
    }
}
