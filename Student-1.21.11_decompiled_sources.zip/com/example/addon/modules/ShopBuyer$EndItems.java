/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

public static enum ShopBuyer.EndItems {
    public static final ShopBuyer.EndItems ENDER_CHEST = new ShopBuyer.EndItems("ENDER_CHEST", 0);
    public static final ShopBuyer.EndItems ENDER_PEARL = new ShopBuyer.EndItems("ENDER_PEARL", 1);
    public static final ShopBuyer.EndItems END_STONE = new ShopBuyer.EndItems("END_STONE", 2);
    public static final ShopBuyer.EndItems DRAGON_BREATH = new ShopBuyer.EndItems("DRAGON_BREATH", 3);
    public static final ShopBuyer.EndItems END_ROD = new ShopBuyer.EndItems("END_ROD", 4);
    public static final ShopBuyer.EndItems CHORUS_FRUIT = new ShopBuyer.EndItems("CHORUS_FRUIT", 5);
    public static final ShopBuyer.EndItems POPPED_CHORUS_FRUIT = new ShopBuyer.EndItems("POPPED_CHORUS_FRUIT", 6);
    public static final ShopBuyer.EndItems SHULKER_SHELL = new ShopBuyer.EndItems("SHULKER_SHELL", 7);
    public static final ShopBuyer.EndItems SHULKER_BOX = new ShopBuyer.EndItems("SHULKER_BOX", 8);
    private static final /* synthetic */ ShopBuyer.EndItems[] $VALUES;

    public static ShopBuyer.EndItems[] values() {
        return (ShopBuyer.EndItems[])$VALUES.clone();
    }

    public static ShopBuyer.EndItems valueOf(String name) {
        return (ShopBuyer.EndItems)Enum.valueOf(ShopBuyer.EndItems.class, name);
    }

    private ShopBuyer.EndItems() {
        super(var1, var2);
    }

    static {
        $VALUES = ShopBuyer.EndItems.$values();
    }
}
