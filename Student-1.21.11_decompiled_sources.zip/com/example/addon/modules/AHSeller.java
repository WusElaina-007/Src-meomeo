/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class AHSeller
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<class_1792> item;
    private final Setting<Integer> price;
    private final Setting<Integer> amount;
    private final Setting<Integer> delay;
    private int tickDelay;
    private int stage;

    public AHSeller() {
        super(AddonTemplate.Student, "AH Sell", "Auto sell item on ah");
        this.item = this.sgGeneral.add(((ItemSetting.Builder)((ItemSetting.Builder)new ItemSetting.Builder().name("item")).defaultValue(class_1802.field_8477)).build());
        this.price = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("price")).defaultValue(1000)).min(1).sliderMax(10000000).build());
        this.amount = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("amount")).defaultValue(64)).min(1).sliderMax(64).build());
        this.delay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("delay")).defaultValue(40)).min(0).sliderMax(200).build());
        this.tickDelay = 0;
        this.stage = 0;
    }

    public void onActivate() {
        this.tickDelay = 0;
        this.stage = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (this.mc.field_1724 == null) {
            return;
        }
        if (this.tickDelay > 0) {
            this.tickDelay = this.tickDelay - 1;
            return;
        }
        if (this.stage == 0) {
            class_1792[] tmp0 = new class_1792[1];
            tmp0[0] = (class_1792)this.item.get();
            FindItemResult result = InvUtils.find(tmp0);
            if (!result.found()) {
                this.toggle();
                return;
            }
            InvUtils.move().from(result.slot()).toHotbar(0);
            this.mc.field_1724.method_31548().method_61496(0);
            this.stage = 1;
            this.tickDelay = 5;
            return;
        }
        if (this.stage == 1) {
            this.mc.field_1724.field_3944.method_45730("ah sell " + String.valueOf(this.price.get()) + " " + String.valueOf(this.amount.get()));
            this.stage = 2;
            this.tickDelay = 10;
            return;
        }
        if (this.stage != 2) { /* goto L296; */ }
        if (this.mc.field_1724.field_7512 == null) {
            return;
        }
        handler = this.mc.field_1724.field_7512;
        for (int i = 0; i < handler.field_7761.size(); i++) {
            class_1799 stack = handler.method_7611(i).method_7677();
            this.mc.field_1761.method_2906(handler.field_7763, i, 0, class_1713.field_7794, this.mc.field_1724);
            if (!stack.method_7960() && stack.method_7909() == class_1802.field_8581) {
                this.stage = 0;
                this.tickDelay = ((Integer)this.delay.get()).intValue();
                return;
            }
        }
    }
}
