/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

public static enum ShopBuyer.CategoryType {
    public static final ShopBuyer.CategoryType END = new ShopBuyer.CategoryType("END", 0);
    public static final ShopBuyer.CategoryType NETHER = new ShopBuyer.CategoryType("NETHER", 1);
    public static final ShopBuyer.CategoryType GEAR = new ShopBuyer.CategoryType("GEAR", 2);
    public static final ShopBuyer.CategoryType END_FOOD = new ShopBuyer.CategoryType("END_FOOD", 3);
    private static final /* synthetic */ ShopBuyer.CategoryType[] $VALUES;

    public static ShopBuyer.CategoryType[] values() {
        return (ShopBuyer.CategoryType[])$VALUES.clone();
    }

    public static ShopBuyer.CategoryType valueOf(String name) {
        return (ShopBuyer.CategoryType)Enum.valueOf(ShopBuyer.CategoryType.class, name);
    }

    private ShopBuyer.CategoryType() {
        super(var1, var2);
    }

    static {
        $VALUES = ShopBuyer.CategoryType.$values();
    }
}
