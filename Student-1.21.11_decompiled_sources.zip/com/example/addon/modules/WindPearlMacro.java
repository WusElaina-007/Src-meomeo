/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

public class WindPearlMacro
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<Integer> delayTicks = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("delay")).description("Delay in ticks between pearl throw and wind charge.")).defaultValue(8)).min(1).sliderMax(20).build());
    private int tickCounter = 0;
    private boolean active = false;

    public WindPearlMacro() {
        super(AddonTemplate.Student_pvp, "Wind-Pearl-Macro", "Throws an ender pearl then uses a wind charge after a delay.");
    }

    public void onActivate() {
        if (this.mc.field_1724 == null) {
            this.toggle();
            return;
        }
        int pearlSlot = this.findSlot(class_1802.field_8634);
        if (pearlSlot == -1) {
            this.toggle();
            return;
        }
        InvUtils.swap(pearlSlot, true);
        this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
        this.mc.field_1724.method_6104(class_1268.field_5808);
        InvUtils.swapBack();
        this.active = true;
        this.tickCounter = 0;
    }

    public void onDeactivate() {
        this.active = false;
        this.tickCounter = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (!this.active || this.mc.field_1724 == null) {
            return;
        }
        this.tickCounter = this.tickCounter + 1;
        if (this.tickCounter < ((Integer)this.delayTicks.get()).intValue()) {
            return;
        }
        int windSlot = this.findSlot(class_1802.field_49098);
        if (windSlot == -1) {
            this.toggle();
            return;
        }
        InvUtils.swap(windSlot, true);
        this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
        this.mc.field_1724.method_6104(class_1268.field_5808);
        InvUtils.swapBack();
        this.toggle();
    }

    private int findSlot(class_1792 item) {
        for (int i = 0; i < 9; i++) {
            if (!this.mc.field_1724.method_31548().method_5438(i).method_31574(item)) continue;
            return i;
        }
        return -1;
    }
}
