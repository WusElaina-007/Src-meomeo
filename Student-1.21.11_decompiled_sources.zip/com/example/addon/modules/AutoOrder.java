/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_476;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

public class AutoOrder
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<AutoOrder.Mode> mode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("mode")).description("Search = duyệt trang, High Value = refresh và lấy item đắt nhất")).defaultValue(AutoOrder.Mode.SEARCH)).build());
    private final Setting<String> orderName = this.sgGeneral.add(((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("order-name")).defaultValue("")).build());
    private final Setting<Boolean> clickCauldron = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("click-cauldron")).defaultValue(true)).build());
    private final Setting<class_1792> item;
    private final Setting<Boolean> checkPrice;
    private final Setting<Double> minPrice;
    private final Setting<Boolean> loop;
    private final Setting<Integer> loopCount;
    private int stage;
    private int timer;
    private int currentLoop;
    private int stageTimeout;
    private int lastStage;
    private static final int MAX_TIMEOUT = 200;
    private int nextPageClickCount;

    public AutoOrder() {
        super(AddonTemplate.Student, "Auto-Order", "Automatically fulfills item orders.");
        this.item = this.sgGeneral.add(((ItemSetting.Builder)((ItemSetting.Builder)new ItemSetting.Builder().name("item")).defaultValue(class_1802.field_8162)).build());
        this.checkPrice = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("check-price")).defaultValue(true)).build());
        Objects.requireNonNull(this.checkPrice);
        this.minPrice = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("min-price")).defaultValue(500).min(0).sliderMax(100000).visible(this.checkPrice::get)).build());
        this.loop = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("loop")).defaultValue(false)).build());
        Objects.requireNonNull(this.loop);
        this.loopCount = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("loop-count")).defaultValue(0)).min(0).sliderMax(100).visible(this.loop::get)).build());
        this.stage = 0;
        this.timer = 0;
        this.currentLoop = 0;
        this.stageTimeout = 0;
        this.lastStage = -99;
        this.nextPageClickCount = 0;
    }

    public void onActivate() {
        this.stage = -2;
        this.timer = 10;
        this.currentLoop = 0;
        this.stageTimeout = 0;
        this.lastStage = -99;
        this.nextPageClickCount = 0;
    }

    public void onDeactivate() {
        this.stage = 0;
        this.timer = 0;
        this.currentLoop = 0;
        this.stageTimeout = 0;
        this.nextPageClickCount = 0;
    }

    private int smartDelay() {
        if (this.mc.method_1562() == null) {
            return 5;
        }
        int ping = this.mc.method_1562().method_2871(this.mc.field_1724.method_5667()) != null ? this.mc.method_1562().method_2871(this.mc.field_1724.method_5667()).method_2959() : 100;
        if (ping < 50) {
            return 2;
        }
        if (ping < 100) {
            return 3;
        }
        if (ping < 200) {
            return 5;
        }
        if (ping < 300) {
            return 8;
        }
        return 12;
    }

    private void startOrder() {
        if (this.mc.field_1724 == null) {
            return;
        }
        this.mc.field_1724.field_3944.method_45730("order " + (String)this.orderName.get());
    }

    private double parsePrice(String text) {
        try {
            text = text.trim();
            Matcher matcher = Pattern.compile("([0-9]+\\.?[0-9]*)([KkMmBb]?)").matcher(text);
            if (!matcher.find()) {
                return 0;
            }
        }
        catch (Exception e) {
            return 0;
        }
        try {
            double value = Double.parseDouble(matcher.group(1));
            var var5 = matcher.group(2).toUpperCase();
            int var6 = -1;
            switch (var5.hashCode()) {
                case 75::
                    if (!var5.equals("K")) { /* goto @136; */ }
                    var6 = 0;
                    /* goto @136; */
                case 77::
                    if (!var5.equals("M")) { /* goto @136; */ }
                    var6 = 1;
                    /* goto @136; */
                case 66::
                    if (var5.equals("B")) {
                        var6 = 2;
                    }
                default:
                    switch (var6) {
                        case 0::
                            return value * 1000;
                        case 1::
                            return value * 1000000;
                        case 2::
                            return value * 1000000000;
                        default:
                            return value;
                    }
            }
        }
        catch (Exception e) {
            return 0;
        }
    }

    private double getPriceFromSlot(class_476 screen, int slotIndex) {
        class_1707 handler = (class_1707)screen.method_17577();
        if (slotIndex < 0 || slotIndex >= handler.field_7761.size()) {
            return 0;
        }
        class_1799 stack = ((class_1735)handler.field_7761.get(slotIndex)).method_7677();
        if (stack.method_7960()) {
            return 0;
        }
        class_9290 lore = (class_9290)stack.method_58694(class_9334.field_49632);
        if (lore == null) { /* goto L155; */ }
        String name = lore.comp_2400().iterator();
        while (name.hasNext()) {
            class_2561 line = (class_2561)name.next();
            String lineStr = line.getString();
            if (lineStr.contains("$")) {
                double price = this.parsePrice(lineStr.replace("$", "").trim());
                if (!price > 0) continue;
                return price;
            }
        }
        name = stack.method_7964().getString();
        if (name.contains("$")) {
            price = this.parsePrice(name.replace("$", "").trim());
            if (price > 0) {
                return price;
            }
        }
        return 0;
    }

    private boolean isPriceOk(double price) {
        if (!((Boolean)this.checkPrice.get()).booleanValue()) {
            return true;
        }
        double min = ((Double)this.minPrice.get()).doubleValue();
        if (min <= 0) {
            return true;
        }
        return price >= min;
    }

    private int findValidSlot(class_476 screen) {
        class_1707 handler = (class_1707)screen.method_17577();
        int i = 0;
        while (i <= 44) {
            if (i >= handler.field_7761.size()) {
            } else {
                class_1799 stack = ((class_1735)handler.field_7761.get(i)).method_7677();
                if (stack.method_7960()) {
                } else {
                    if (this.item.get() != class_1802.field_8162) {
                    } else {
                        double price = this.getPriceFromSlot(screen, i);
                        if (!this.isPriceOk(price)) continue;
                        return i;
                    }
                }
                i++;
            }
        }
        return -1;
    }

    private int findHighestValueSlot(class_476 screen) {
        class_1707 handler = (class_1707)screen.method_17577();
        int bestSlot = -1;
        double bestPrice = -1;
        int i = 0;
        while (i <= 44) {
            if (i >= handler.field_7761.size()) {
            } else {
                class_1799 stack = ((class_1735)handler.field_7761.get(i)).method_7677();
                if (stack.method_7960()) {
                } else {
                    if (this.item.get() != class_1802.field_8162) {
                    } else {
                        double price = this.getPriceFromSlot(screen, i);
                        if (this.isPriceOk(price)) {
                            if (price > bestPrice) {
                                bestPrice = price;
                                bestSlot = i;
                            }
                        }
                    }
                }
                i++;
            }
        }
        return bestSlot;
    }

    private void finishLoop() {
        this.currentLoop = this.currentLoop + 1;
        if (!((Boolean)this.loop.get()).booleanValue()) {
            this.toggle();
            return;
        }
        this.toggle();
        if (((Integer)this.loopCount.get()).intValue() > 0 && this.currentLoop >= ((Integer)this.loopCount.get()).intValue()) {
            return;
        }
        this.stage = -2;
        this.timer = this.smartDelay() * 3;
    }

    private void handleFindSlot(class_476 screen) {
        class_1707 handler = (class_1707)screen.method_17577();
        if (this.mode.get() != AutoOrder.Mode.HIGH_VALUE) { /* goto L124; */ }
        int slot = this.findHighestValueSlot(screen);
        if (slot != -1) {
            this.mc.field_1761.method_2906(handler.field_7763, slot, 0, class_1713.field_7790, this.mc.field_1724);
            this.stage = 2;
            this.timer = this.smartDelay();
        } else {
            if (49 < handler.field_7761.size()) {
                this.mc.field_1761.method_2906(handler.field_7763, 49, 0, class_1713.field_7790, this.mc.field_1724);
            }
            this.timer = this.smartDelay() * 4;
        }
        return;
        L124: ;
        slot = this.findValidSlot(screen);
        if (slot != -1) {
            this.nextPageClickCount = 0;
            this.mc.field_1761.method_2906(handler.field_7763, slot, 0, class_1713.field_7790, this.mc.field_1724);
            this.stage = 2;
            this.timer = this.smartDelay();
        } else {
            if (handler.field_7761.size() > 53) {
                if (!((class_1735)handler.field_7761.get(53)).method_7677().method_7960()) {
                    this.nextPageClickCount = this.nextPageClickCount + 1;
                    if (this.nextPageClickCount > 10) {
                        this.nextPageClickCount = 0;
                        this.toggle();
                        return;
                    }
                    this.mc.field_1761.method_2906(handler.field_7763, 53, 0, class_1713.field_7790, this.mc.field_1724);
                    this.timer = this.smartDelay() * 3 * 2;
                }
            } else {
                this.toggle();
            }
        }
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (this.stage != this.lastStage) {
            this.lastStage = this.stage;
            this.stageTimeout = 0;
        } else {
            this.stageTimeout = this.stageTimeout + 1;
            if (this.stageTimeout >= 200) {
                this.stageTimeout = 0;
                this.stage = -2;
                this.timer = this.smartDelay() * 3;
                if (this.mc.field_1755 instanceof class_476) {
                    this.mc.field_1724.method_7346();
                }
                return;
            }
        }
        if (this.timer > 0) {
            this.timer = this.timer - 1;
            return;
        }
        if (this.stage == -2) {
            this.startOrder();
            this.stage = -1;
            this.timer = this.smartDelay() * 3;
            return;
        }
        if (this.stage == -1) {
            if (this.mc.field_1755 instanceof class_476) {
                this.stage = 0;
                this.timer = this.smartDelay();
            }
            return;
        }
        if (this.stage == 10) {
            if (this.mc.field_1755 instanceof class_476) {
                this.nextPageClickCount = 0;
                this.stage = 1;
                this.timer = this.smartDelay();
            }
            return;
        }
        if (this.stage == 4) {
            if (this.mc.field_1755 instanceof class_476) {
                this.stage = 5;
                this.timer = this.smartDelay();
            }
            return;
        }
        if (this.stage != 6) { /* goto L318; */ }
        if (this.mc.field_1755 instanceof class_476) {
            this.stage = 3;
            this.timer = this.smartDelay();
        } else {
            this.timer = this.smartDelay();
        }
        return;
        L318: ;
        class_1707 handler = this.mc.field_1755;
        if (handler instanceof class_476) {
            class_476 screen = (class_476)handler;
        } else {
            return;
        }
        handler = (class_1707)screen.method_17577();
        if (this.stage == 0) {
            if (!((Boolean)this.clickCauldron.get()).booleanValue()) {
                this.stage = 1;
                this.timer = this.smartDelay();
                return;
            }
            for (int i = false; i < handler.field_7761.size(); i++) {
                if (((class_1735)handler.field_7761.get(i)).method_7677().method_7909() == class_1802.field_8638) {
                    this.mc.field_1761.method_2906(handler.field_7763, i, 0, class_1713.field_7790, this.mc.field_1724);
                    this.mc.field_1724.method_7346();
                    this.stage = 10;
                    this.timer = this.smartDelay() * 3;
                    return;
                }
            }
        } else {
            if (this.stage == 1) {
                this.handleFindSlot(screen);
            } else {
                if (this.stage == 2) {
                    this.mc.field_1761.method_2906(handler.field_7763, 1, 0, class_1713.field_7790, this.mc.field_1724);
                    this.stage = 3;
                    this.timer = this.smartDelay();
                } else {
                    if (this.stage == 3) {
                        for (int i = false; i < handler.field_7761.size(); i++) {
                            if (((class_1735)handler.field_7761.get(i)).method_7677().method_7909() != this.item.get()) continue;
                            this.mc.field_1761.method_2906(handler.field_7763, i, 0, class_1713.field_7794, this.mc.field_1724);
                        }
                        this.mc.field_1724.method_7346();
                        this.stage = 4;
                        this.timer = this.smartDelay() * 3;
                    } else {
                        if (this.stage != 5) { /* goto @788; */ }
                        boolean found = false;
                        int i = 0;
                        while (i < handler.field_7761.size()) {
                            if (((class_1735)handler.field_7761.get(i)).method_7677().method_7909() == class_1802.field_8581) {
                                this.mc.field_1761.method_2906(handler.field_7763, i, 0, class_1713.field_7790, this.mc.field_1724);
                                found = true;
                            } else {
                                i++;
                            }
                        }
                        if (found) {
                            this.stage = 6;
                            this.timer = this.smartDelay() * 4;
                        } else {
                            this.timer = this.smartDelay();
                        }
                    }
                }
            }
        }
    }
}
