/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_640;

public class FakeNotifier
extends Module {
    private final SettingGroup sg = this.settings.getDefaultGroup();
    private final Setting<String> text = this.sg.add(((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("TEXT")).defaultValue("Student addon on top")).build());
    private final Setting<Boolean> useOnlinePlayers = this.sg.add(((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("use-online-players")).defaultValue(true)).build());
    private final Setting<String> customNames;
    private final Setting<Boolean> loop;
    private final Setting<Integer> repeatTimes;
    private final Setting<Double> delaySeconds;
    private final Random random;
    private int sent;
    private double tickCounter;

    public FakeNotifier() {
        super(AddonTemplate.Student, "Fake Notifier", "Custom colored fake notifier.");
        this.customNames = this.sg.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("custom-names (,)")).defaultValue("Player1,Player2")).visible(this::lambda$new$0)).build());
        this.loop = this.sg.add(((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("loop")).defaultValue(false)).build());
        Objects.requireNonNull(this.loop);
        this.repeatTimes = this.sg.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("repeat-times (-1 = infinite)")).defaultValue(1)).min(-1).sliderMax(50).visible(this.loop::get)).build());
        Objects.requireNonNull(this.loop);
        this.delaySeconds = this.sg.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("delay-seconds")).defaultValue(1).min(0.1).sliderMin(0.1).sliderMax(10).visible(this.loop::get)).build());
        this.random = new Random();
        this.sent = 0;
        this.tickCounter = 0;
    }

    public void onActivate() {
        this.sent = 0;
        this.tickCounter = 0;
        if (!((Boolean)this.loop.get()).booleanValue()) {
            this.send();
            this.toggle();
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (!((Boolean)this.loop.get()).booleanValue()) {
            return;
        }
        if (this.mc.field_1724 == null) {
            return;
        }
        this.tickCounter = this.tickCounter + 1;
        if (this.tickCounter >= ((Double)this.delaySeconds.get()).doubleValue() * 20) {
            this.tickCounter = 0;
            if (((Integer)this.repeatTimes.get()).intValue() != -1) {
                if (this.sent >= ((Integer)this.repeatTimes.get()).intValue()) {
                    this.toggle();
                    return;
                }
                this.sent = this.sent + 1;
            }
            this.send();
        }
    }

    private void send() {
        String player = this.getRandomName();
        String raw = ((String)this.text.get()).replace("{player}", player);
        this.mc.field_1724.method_7353(this.parseColors(raw), false);
    }

    private String getRandomName() {
        if (((Boolean)this.useOnlinePlayers.get()).booleanValue()) {
            if (this.mc.method_1562() != null) {
                List<class_640> list = new ArrayList(this.mc.method_1562().method_2880());
                if (!list.isEmpty()) {
                    return ((class_640)list.get(this.random.nextInt(list.size()))).method_2966().name();
                }
            }
        }
        names = ((String)this.customNames.get()).split(",");
        return names[this.random.nextInt(names.length)].trim();
    }

    private class_5250 parseColors(String input) {
        class_5250 result = class_2561.method_43473();
        int currentColor = 16777215;
        StringBuilder buffer = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c == 38) {
                if (i + 1 < input.length()) {
                    if (buffer.length() > 0) {
                        int color = currentColor;
                        result.method_10852(class_2561.method_43470(buffer.toString()).method_27694(FakeNotifier::lambda$parseColors$1 /* captured: color */));
                        buffer.setLength(0);
                    }
                    currentColor = this.getColor(input.charAt(i + 1));
                    i++;
                }
            } else {
                buffer.append(c);
            }
        }
        if (buffer.length() > 0) {
            color = currentColor;
            result.method_10852(class_2561.method_43470(buffer.toString()).method_27694(FakeNotifier::lambda$parseColors$2 /* captured: color */));
        }
        return result;
    }

    private int getColor(char code) {
        switch (Character.toLowerCase(code)) {
            case 48::
                return 0;
            case 49::
                return 170;
            case 50::
                return 43520;
            case 51::
                return 43690;
            case 52::
                return 11141120;
            case 53::
                return 11141290;
            case 54::
                return 16755200;
            case 55::
                return 11184810;
            case 56::
                return 5592405;
            case 57::
                return 5592575;
            case 97::
                return 5635925;
            case 98::
                return 5636095;
            case 99::
                return 16733525;
            case 100::
                return 16733695;
            case 101::
                return 16777045;
            case 102::
                return 16777215;
            case 58::
            case 59::
            case 60::
            case 61::
            case 62::
            case 63::
            case 64::
            case 65::
            case 66::
            case 67::
            case 68::
            case 69::
            case 70::
            case 71::
            case 72::
            case 73::
            case 74::
            case 75::
            case 76::
            case 77::
            case 78::
            case 79::
            case 80::
            case 81::
            case 82::
            case 83::
            case 84::
            case 85::
            case 86::
            case 87::
            case 88::
            case 89::
            case 90::
            case 91::
            case 92::
            case 93::
            case 94::
            case 95::
            case 96::
            default:
                return 16777215;
        }
    }
}
