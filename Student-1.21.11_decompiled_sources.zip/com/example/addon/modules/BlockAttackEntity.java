/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.util.Set;
import meteordevelopment.meteorclient.events.entity.player.AttackEntityEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1299;

public class BlockAttackEntity
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<Boolean> enabled = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("enabled")).description("Enable block attack")).defaultValue(true)).build());
    private final Setting<Set<class_1299<?>>> blockedEntities = this.sgGeneral.add(((EntityTypeListSetting.Builder)((EntityTypeListSetting.Builder)new EntityTypeListSetting.Builder().name("blocked-entities")).description("Entities that cannot be attacked")).defaultValue(new class_1299[0]).build());

    public BlockAttackEntity() {
        super(AddonTemplate.Student, "block-attack-entity", "Block attacking selected entities.");
    }

    @EventHandler
    private void onAttack(AttackEntityEvent event) {
        if (!((Boolean)this.enabled.get()).booleanValue()) {
            return;
        }
        if (((Set)this.blockedEntities.get()).contains(event.entity.method_5864())) {
            event.cancel();
        }
    }
}
