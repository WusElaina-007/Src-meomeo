/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.modules.CustomCrosshair;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

private static class CustomCrosshair.CrosshairEditorScreen
extends class_437 {
    private final CustomCrosshair module;
    private static final int HALF = 20;
    private static final int CELL = 15;
    private int heldButton = -1;

    public CustomCrosshair.CrosshairEditorScreen(CustomCrosshair module) {
        super(class_2561.method_43470("Crosshair Editor"));
        this.module = module;
    }

    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        super.method_25394(ctx, mouseX, mouseY, delta);
        if (this.heldButton != -1) {
            this.handleInput((double)mouseX, (double)mouseY, this.heldButton);
        }
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;
        ctx.method_25294(0, 0, this.field_22789, this.field_22790, -1879048192);
        for (int x = -20; x <= 20; x++) {
            for (int y = -20; y <= 20; y++) {
                int xPos = cx + x * 15 - 7;
                int yPos = cy + y * 15 - 7;
                int gridCol = x == 0 && y == 0 ? -2130754492 : 1090519039;
                ctx.method_25294(xPos, yPos, xPos + 15 - 1, yPos + 15 - 1, gridCol);
                if (!this.module.pixels.contains(x + "," + y)) continue;
                ctx.method_25294(xPos, yPos, xPos + 15 - 1, yPos + 15 - 1, ((SettingColor)this.module.color.get()).getPacked());
            }
        }
        ctx.method_25300(this.field_22793, "LMB: Draw  |  RMB: Erase  |  C: Clear", this.field_22789 / 2, 10, -1);
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        this.heldButton = button;
        this.handleInput(mouseX, mouseY, button);
        return true;
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        this.heldButton = -1;
        return true;
    }

    private void handleInput(double mouseX, double mouseY, int button) {
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;
        int gridX = (int)Math.floor((mouseX - (double)cx + 7.5) / 15);
        int gridY = (int)Math.floor((mouseY - (double)cy + 7.5) / 15);
        if (Math.abs(gridX) > 20 || Math.abs(gridY) > 20) {
            return;
        }
        String key = gridX + "," + gridY;
        if (button == 0) {
            this.module.pixels.add(key);
        } else {
            if (button == 1) {
                this.module.pixels.remove(key);
            }
        }
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 67) {
            this.module.pixels.clear();
            return true;
        }
        return false;
    }

    public boolean method_25421() {
        return false;
    }
}
