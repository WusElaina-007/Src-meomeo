/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.events.game.OpenScreenEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2663;
import net.minecraft.class_490;

public class AutoInvTotem
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<Integer> delay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("delay")).description("Delay in ticks before moving totem")).defaultValue(3)).min(1).max(20).sliderMin(1).sliderMax(20).build());
    private final Setting<Boolean> moveFromHotbar = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("move-from-hotbar")).description("Also move totems from hotbar slots")).defaultValue(true)).build());
    private final Setting<Boolean> openInv = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("open-inv")).description("Automatically open inventory when totem pops")).defaultValue(false)).build());
    private final Setting<Integer> invOpenDelay;
    private final Setting<Integer> invCloseDelay;
    private boolean needsTotem;
    private int delayTicks;
    private boolean hadTotemInOffhand;
    private boolean shouldOpenInv;
    private int invOpenTicks;
    private int invCloseTicks;
    private boolean invAutoOpened;

    public AutoInvTotem() {
        super(AddonTemplate.Student_pvp, "Auto-Inv-Totem", "Auto fill totem to offhand when open inventory.");
        this.invOpenDelay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("inv-open-delay")).description("Ticks to wait before opening inventory after totem pop")).defaultValue(2)).min(1).max(10).sliderMin(1).sliderMax(10).visible(this::lambda$new$0)).build());
        this.invCloseDelay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("inv-close-delay")).description("Ticks to wait before closing inventory after opening")).defaultValue(8)).min(5).max(20).sliderMin(5).sliderMax(20).visible(this::lambda$new$1)).build());
        this.needsTotem = false;
        this.delayTicks = 0;
        this.hadTotemInOffhand = false;
        this.shouldOpenInv = false;
        this.invOpenTicks = 0;
        this.invCloseTicks = 0;
        this.invAutoOpened = false;
    }

    public void onActivate() {
        this.resetState();
    }

    public void onDeactivate() {
        this.resetInvAutoState();
    }

    private void resetState() {
        if (this.mc.field_1724 != null) {
            this.hadTotemInOffhand = this.hasTotemInOffhand();
            this.needsTotem = false;
            this.delayTicks = 0;
            this.resetInvAutoState();
        }
    }

    private void resetInvAutoState() {
        this.shouldOpenInv = false;
        this.invOpenTicks = 0;
        this.invCloseTicks = 0;
        this.invAutoOpened = false;
    }

    @EventHandler
    private void onGameJoined(GameJoinedEvent event) {
        this.resetState();
    }

    @EventHandler
    private void onPacketReceive(PacketEvent.Receive event) {
        var var3 = event.packet;
        if (var3 instanceof class_2663) {
            class_2663 packet = (class_2663)var3;
            if (packet.method_11470() == 35) {
                if (this.mc.field_1724 != null) {
                    if (packet.method_11469(this.mc.field_1687) == this.mc.field_1724) {
                        if (((Boolean)this.openInv.get()).booleanValue()) {
                            if (this.mc.field_1755 == null) {
                                this.shouldOpenInv = true;
                                this.invOpenTicks = ((Integer)this.invOpenDelay.get()).intValue();
                            }
                        }
                    }
                }
            }
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1724 == null) {
            return;
        }
        this.handleAutoInventory();
        boolean currentlyHasTotem = this.hasTotemInOffhand();
        if (this.hadTotemInOffhand) {
            if (!currentlyHasTotem) {
                this.needsTotem = true;
                if (this.mc.field_1755 instanceof class_490) {
                    this.delayTicks = ((Integer)this.delay.get()).intValue();
                }
            }
        }
        this.hadTotemInOffhand = currentlyHasTotem;
        this.needsTotem = false;
        if (currentlyHasTotem && this.needsTotem) {
            this.delayTicks = 0;
        }
    }

    private void handleAutoInventory() {
        if (this.shouldOpenInv) {
            if (this.invOpenTicks > 0) {
                this.invOpenTicks = this.invOpenTicks - 1;
                if (this.invOpenTicks == 0) {
                    if (this.mc.field_1755 == null) {
                        this.mc.method_1507(new class_490(this.mc.field_1724));
                        this.invAutoOpened = true;
                        this.invCloseTicks = ((Integer)this.invCloseDelay.get()).intValue();
                        this.shouldOpenInv = false;
                    }
                }
            }
        }
        if (this.invAutoOpened) {
            if (this.invCloseTicks > 0) {
                this.invCloseTicks = this.invCloseTicks - 1;
                if (this.invCloseTicks == 0) {
                    if (this.mc.field_1755 instanceof class_490) {
                        this.mc.method_1507(null);
                        this.invAutoOpened = false;
                    }
                }
            }
        }
        this.invAutoOpened = false;
        if (this.invAutoOpened && !(this.mc.field_1755 instanceof class_490)) {
            this.invCloseTicks = 0;
        }
    }

    @EventHandler
    private void onOpenScreen(OpenScreenEvent event) {
        if (!event.screen instanceof class_490 || !this.needsTotem || this.mc.field_1724 == null) {
            return;
        }
        this.delayTicks = ((Integer)this.delay.get()).intValue();
    }

    @EventHandler
    private void onTickDelayed(TickEvent.Post event) {
        if (this.delayTicks <= 0 || this.mc.field_1724 == null) {
            return;
        }
        this.delayTicks = this.delayTicks - 1;
        if (this.delayTicks == 0) {
            this.moveTotemToOffhand();
        }
    }

    private void moveTotemToOffhand() {
        int totemSlot = this.findTotemSlot();
        if (totemSlot == -1) {
            return;
        }
        try {
            int containerSlot = totemSlot < 9 ? totemSlot + 36 : totemSlot;
            class_1799 offhandStack = this.mc.field_1724.method_6079();
            if (offhandStack.method_7960()) {
                this.mc.field_1761.method_2906(0, containerSlot, 40, class_1713.field_7791, this.mc.field_1724);
            } else {
                this.mc.field_1761.method_2906(0, containerSlot, 0, class_1713.field_7790, this.mc.field_1724);
                this.mc.field_1761.method_2906(0, 45, 0, class_1713.field_7790, this.mc.field_1724);
                this.mc.field_1761.method_2906(0, containerSlot, 0, class_1713.field_7790, this.mc.field_1724);
            }
            this.needsTotem = false;
        }
        catch (Exception containerSlot) {
            return;
        }
    }

    private int findTotemSlot() {
        for (int i = 9; i < 36; i++) {
            if (this.mc.field_1724.method_31548().method_5438(i).method_7909() != class_1802.field_8288) continue;
            return i;
        }
        if (!((Boolean)this.moveFromHotbar.get()).booleanValue()) { /* goto L95; */ }
        for (i = 0; i < 9; i++) {
            if (this.mc.field_1724.method_31548().method_5438(i).method_7909() != class_1802.field_8288) continue;
            return i;
        }
        return -1;
    }

    private boolean hasTotemInOffhand() {
        if (this.mc.field_1724 == null) {
            return false;
        }
        class_1799 offhandStack = this.mc.field_1724.method_6079();
        return !offhandStack.method_7960() && offhandStack.method_7909() == class_1802.field_8288;
    }
}
