/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

private static enum TunnelFinderBase.State {
    public static final TunnelFinderBase.State GOTO = new TunnelFinderBase.State("GOTO", 0);
    public static final TunnelFinderBase.State WAIT_Y = new TunnelFinderBase.State("WAIT_Y", 1);
    public static final TunnelFinderBase.State TUNNEL = new TunnelFinderBase.State("TUNNEL", 2);
    public static final TunnelFinderBase.State SCANNING = new TunnelFinderBase.State("SCANNING", 3);
    private static final /* synthetic */ TunnelFinderBase.State[] $VALUES;

    public static TunnelFinderBase.State[] values() {
        return (TunnelFinderBase.State[])$VALUES.clone();
    }

    public static TunnelFinderBase.State valueOf(String name) {
        return (TunnelFinderBase.State)Enum.valueOf(TunnelFinderBase.State.class, name);
    }

    private TunnelFinderBase.State() {
        super(var1, var2);
    }

    static {
        $VALUES = TunnelFinderBase.State.$values();
    }
}
