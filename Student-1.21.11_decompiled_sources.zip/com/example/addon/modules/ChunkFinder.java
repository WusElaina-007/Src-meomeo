/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1533;
import net.minecraft.class_1542;
import net.minecraft.class_1694;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2791;
import net.minecraft.class_2818;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class ChunkFinder
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<Boolean> showCoords = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("show-coordinates")).description("Show coordinates in chat and notifications")).defaultValue(true)).build());
    private final Setting<Integer> renderDistance = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("render-distance")).description("Hide detections further than this distance.")).defaultValue(512)).min(32).sliderMax(2048).build());
    private final Setting<ChunkFinder.HoleMode> holeMode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("hole-detection")).description("Detect chunks with or without holes")).defaultValue(ChunkFinder.HoleMode.Both)).build());
    private final Setting<SettingColor> chunkColor = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)new ColorSetting.Builder().name("chunk-color")).description("Color of detected chunks")).defaultValue(new SettingColor(0, 255, 255, 100)).build());
    private final Setting<Boolean> showTracers = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("show-tracers")).description("Draw tracers to detected chunks")).defaultValue(false)).build());
    private final Setting<Integer> holeCheckRadius;
    private static final int MIN_VINE_LENGTH = 20;
    private static final int MIN_KELP_LENGTH = 20;
    private static final int ROTATED_DEEPSLATE_THRESHOLD = 5;
    private static final int ENTITY_MAX_DISTANCE = 256;
    private final Map<class_1923, ChunkFinder.DetectionInfo> detectedChunks;
    private final Set<class_1923> chunksWithBrokenBlocks;
    private final Set<Integer> detectedEntities;
    private final Set<class_1923> scannedChunks;
    private ExecutorService threadPool;

    public ChunkFinder() {
        super(AddonTemplate.Student_esp, "chunk-finder", "Detects suspicious chunks.");
        this.holeCheckRadius = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("hole-check-radius")).description("Blocks radius to check for holes")).defaultValue(8)).min(0).max(64).visible(this::lambda$new$0)).build());
        this.detectedChunks = new ConcurrentHashMap();
        this.chunksWithBrokenBlocks = ConcurrentHashMap.newKeySet();
        this.detectedEntities = ConcurrentHashMap.newKeySet();
        this.scannedChunks = ConcurrentHashMap.newKeySet();
    }

    public void onActivate() {
        this.clearData();
        this.threadPool = Executors.newFixedThreadPool(2);
        if (this.mc.field_1687 == null) { /* goto L82; */ }
        var var1 = Utils.chunks().iterator();
        while (var1.hasNext()) {
            class_2791 chunk = (class_2791)var1.next();
            if (chunk instanceof class_2818) {
                class_2818 worldChunk = (class_2818)chunk;
                this.threadPool.submit(this::lambda$onActivate$1 /* captured: worldChunk */);
            }
        }
    }

    public void onDeactivate() {
        if (this.threadPool != null) {
            this.threadPool.shutdownNow();
        }
        this.clearData();
    }

    private void clearData() {
        this.detectedChunks.clear();
        this.chunksWithBrokenBlocks.clear();
        this.detectedEntities.clear();
        this.scannedChunks.clear();
    }

    @EventHandler
    private void onChunkLoad(ChunkDataEvent event) {
        if (this.threadPool != null) {
            if (!this.threadPool.isShutdown()) {
                this.threadPool.submit(this::lambda$onChunkLoad$2 /* captured: event */);
            }
        }
    }

    @EventHandler
    private void onBlockUpdate(BlockUpdateEvent event) {
        if (event.pos.method_10264() <= 16) {
            return;
        }
        if (event.newState.method_26215()) {
            class_1923 cp = new class_1923(event.pos);
            if (this.detectedChunks.containsKey(cp)) {
                this.chunksWithBrokenBlocks.add(cp);
            }
        }
        if (this.threadPool != null) {
            if (!this.threadPool.isShutdown()) {
                this.threadPool.submit(this::lambda$onBlockUpdate$3 /* captured: event */);
            }
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        this.checkEntities();
        Color sideColor = (Color)this.chunkColor.get();
        Color lineColor = new Color(sideColor).a(255);
        var var4 = this.detectedChunks.entrySet().iterator();
        while (var4.hasNext()) {
            Map.Entry<class_1923, ChunkFinder.DetectionInfo> entry = (Map.Entry)var4.next();
            class_1923 cp = (class_1923)entry.getKey();
            class_2338 pos = ((ChunkFinder.DetectionInfo)entry.getValue()).position();
            double distSq = PlayerUtils.squaredDistanceTo((double)pos.method_10263() + 0.5, (double)pos.method_10264() + 0.5, (double)pos.method_10260() + 0.5);
            while (distSq > Math.pow((double)((Integer)this.renderDistance.get()).intValue(), 2)) {
            }
            double x1 = (double)cp.method_8326();
            double z1 = (double)cp.method_8328();
            double y = (double)pos.method_10264();
            event.renderer.box(x1, y, z1, x1 + 16, y + 0.3, z1 + 16, sideColor, lineColor, ShapeMode.Both, 0);
            if (((Boolean)this.showTracers.get()).booleanValue()) {
                if (this.chunksWithBrokenBlocks.contains(cp)) continue;
                event.renderer.line(RenderUtils.center.field_1352, RenderUtils.center.field_1351, RenderUtils.center.field_1350, x1 + 8, y + 0.15, z1 + 8, lineColor);
            }
        }
    }

    private void addDetection(class_2338 pos) {
        if (pos.method_10264() <= 16) {
            return;
        }
        class_1923 chunkPos = new class_1923(pos);
        var var3 = this.detectedChunks.keySet().iterator();
        while (var3.hasNext()) {
            class_1923 existing = (class_1923)var3.next();
            if (Math.abs(existing.field_9181 - chunkPos.field_9181) <= 2) {
                if (!Math.abs(existing.field_9180 - chunkPos.field_9180) <= 2) continue;
                return;
            }
        }
        if (this.holeMode.get() == ChunkFinder.HoleMode.Without_Holes && this.chunkHasHoles(chunkPos)) {
            return;
        }
        this.detectedChunks.put(chunkPos, new ChunkFinder.DetectionInfo(pos, System.currentTimeMillis()));
        if (this.mc.field_1687 != null) {
            if (this.mc.field_1724 != null) {
                this.mc.field_1687.method_8396(this.mc.field_1724, pos, class_3417.field_14627, class_3419.field_15250, 1f, 1f);
            }
        }
        if (((Boolean)this.showCoords.get()).booleanValue()) {
            this.info("Detected suspicious chunk at X: %d, Z: %d", pos.method_10263(), pos.method_10260());
            if (this.mc.field_1724 != null) {
                this.mc.field_1724.method_7353(class_2561.method_43470("§e[ChunkFinder] §fSuspicious chunk at X: " + pos.method_10263() + " Z: " + pos.method_10260()), false);
            }
        }
    }

    private void scanChunk(class_2818 chunk) {
        class_1923 cpos = chunk.method_12004();
        if (!this.scannedChunks.add(cpos)) {
            return;
        }
        this.scanChunkForVines(chunk);
        this.scanChunkForKelp(chunk);
        this.scanChunkForRotatedDeepslate(chunk);
    }

    private void scanChunkForRotatedDeepslate(class_2818 chunk) {
        int count = 0;
        class_2338 firstFound = null;
        class_1923 cPos = chunk.method_12004();
        for (int x = cPos.method_8326(); x < cPos.method_8327(); x++) {
            for (int z = cPos.method_8328(); z < cPos.method_8329(); z++) {
                for (int y = 17; y < 319; y++) {
                    class_2338 pos = new class_2338(x, y, z);
                    class_2680 state = chunk.method_8320(pos);
                    if (state.method_27852(class_2246.field_28888)) {
                        if (state.method_28498(class_2741.field_12496)) {
                            class_2351 axis = (class_2350.class_2351)state.method_11654(class_2741.field_12496);
                            if (axis == class_2350.class_2351.field_11048 || axis == class_2350.class_2351.field_11051) {
                                if (firstFound != null) continue;
                                firstFound = pos;
                                count++;
                                if (count >= 5) {
                                    this.addDetection(firstFound);
                                    return;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private void scanChunkForKelp(class_2818 chunk) {
        class_1923 cPos = chunk.method_12004();
        for (int x = cPos.method_8326(); x < cPos.method_8327(); x++) {
            for (int z = cPos.method_8328(); z < cPos.method_8329(); z++) {
                for (int y = 17; y < 64; y++) {
                    class_2338 pos = new class_2338(x, y, z);
                    if (chunk.method_8320(pos).method_27852(class_2246.field_9993)) {
                        if (!this.getKelpLength(pos) >= 20) continue;
                        this.addDetection(pos);
                    }
                }
            }
        }
    }

    private void scanChunkForVines(class_2818 chunk) {
        class_1923 cPos = chunk.method_12004();
        for (int x = cPos.method_8326(); x < cPos.method_8327(); x++) {
            for (int z = cPos.method_8328(); z < cPos.method_8329(); z++) {
                for (int y = 318; y > 16; y--) {
                    class_2338 pos = new class_2338(x, y, z);
                    if (chunk.method_8320(pos).method_27852(class_2246.field_10597)) {
                        if (this.vineExtendsToY16(pos)) {
                            if (!this.getVineLength(pos) >= 20) continue;
                            this.addDetection(pos);
                        }
                    }
                }
            }
        }
    }

    private void checkRotatedDeepslate(class_2338 pos) {
        if (this.mc.field_1687 == null || pos.method_10264() <= 16) {
            return;
        }
        class_2818 chunk = this.mc.field_1687.method_8500(pos);
        if (chunk != null) {
            this.scanChunkForRotatedDeepslate(chunk);
        }
    }

    private void checkVine(class_2338 pos) {
        if (pos.method_10264() > 16) {
            if (this.vineExtendsToY16(pos)) {
                if (this.getVineLength(pos) >= 20) {
                    this.addDetection(pos);
                }
            }
        }
    }

    private void checkKelp(class_2338 pos) {
        if (pos.method_10264() > 16) {
            if (this.getKelpLength(pos) >= 20) {
                this.addDetection(pos);
            }
        }
    }

    private void checkEntities() {
        if (this.mc.field_1687 == null || this.mc.field_1724 == null) {
            return;
        }
        var var1 = this.mc.field_1687.method_18112().iterator();
        while (var1.hasNext()) {
            class_1297 entity = (class_1297)var1.next();
            while (entity.method_24515().method_10264() <= 16) {
            }
            while (!(entity instanceof class_1533)) {
                if (entity instanceof class_1542) break;
                if (entity instanceof class_1694) break;
            }
            if (this.mc.field_1724.method_5739(entity) <= 256f) {
                if (!this.detectedEntities.add(entity.method_5628())) continue;
                this.addDetection(entity.method_24515());
            }
        }
    }

    private boolean chunkHasHoles(class_1923 cp) {
        if (this.mc.field_1687 == null) {
            return false;
        }
        int air = 0;
        int total = 0;
        int radius = ((Integer)this.holeCheckRadius.get()).intValue();
        int cx = cp.method_33940();
        int cz = cp.method_33942();
        for (int x = cx - radius; x <= cx + radius; x++) {
            for (int z = cz - radius; z <= cz + radius; z++) {
                for (int y = 60; y <= 70; y++) {
                    if (!this.mc.field_1687.method_8320(new class_2338(x, y, z)).method_26215()) continue;
                    air++;
                    total++;
                }
            }
        }
        return total > 0 && (double)air / (double)total > 0.1;
    }

    private boolean vineExtendsToY16(class_2338 start) {
        if (this.mc.field_1687 == null) {
            return false;
        }
        class_2338 p = start;
        while (p.method_10264() >= 16) {
            if (this.mc.field_1687.method_8320(p).method_27852(class_2246.field_10597)) continue;
            return false;
            if (p.method_10264() != 16) continue;
            return true;
            p = p.method_10074();
        }
        return false;
    }

    private int getVineLength(class_2338 start) {
        if (this.mc.field_1687 == null) {
            return 0;
        }
        int l = 0;
        class_2338 p = start;
        while (this.mc.field_1687.method_8320(p).method_27852(class_2246.field_10597)) {
            l++;
            p = p.method_10084();
        }
        p = start.method_10074();
        while (p.method_10264() >= 16) {
            if (!this.mc.field_1687.method_8320(p).method_27852(class_2246.field_10597)) break;
            l++;
            p = p.method_10074();
        }
        return l;
    }

    private int getKelpLength(class_2338 start) {
        if (this.mc.field_1687 == null) {
            return 0;
        }
        int l = 0;
        class_2338 p = start;
        L16: ;
        if (this.mc.field_1687.method_8320(p).method_27852(class_2246.field_9993)) { /* goto L56; */ }
        while (this.mc.field_1687.method_8320(p).method_27852(class_2246.field_10463)) {
            l++;
            p = p.method_10084();
        }
        p = start.method_10074();
        while (p.method_10264() >= 16) {
            if (this.mc.field_1687.method_8320(p).method_27852(class_2246.field_9993)) { /* goto L121; */ }
            if (!this.mc.field_1687.method_8320(p).method_27852(class_2246.field_10463)) break;
            L121: ;
            l++;
            p = p.method_10074();
        }
        return l;
    }

    public String getInfoString() {
        return this.detectedChunks.isEmpty() ? null : String.valueOf(this.detectedChunks.size());
    }
}
