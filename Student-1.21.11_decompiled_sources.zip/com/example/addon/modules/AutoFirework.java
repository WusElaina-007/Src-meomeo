/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.lang.reflect.Field;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2868;

public class AutoFirework
extends Module {
    private final SettingGroup sg = this.settings.getDefaultGroup();
    private final Setting<Integer> delay = this.sg.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("delay-ticks")).description("Thời gian giữa mỗi lần dùng firework (ticks).")).defaultValue(20)).min(1).sliderMax(5000).build());
    private final Setting<Integer> hotbarSlot = this.sg.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("hotbar-slot")).description("Slot hotbar để giữ firework (1-9).")).defaultValue(1)).min(1).max(9).build());
    private int tickCounter = 0;

    public AutoFirework() {
        super(AddonTemplate.Student, "Auto Firework", "Auto refill and use firework rockets.");
    }

    public void onActivate() {
        this.tickCounter = 0;
    }

    private int getSelectedSlot() {
        try {
            Field f = this.mc.field_1724.method_31548().getClass().getDeclaredField("selectedSlot");
            f.setAccessible(true);
            return ((Integer)f.get(this.mc.field_1724.method_31548())).intValue();
        }
        catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    private void setSelectedSlot(int slot) {
        try {
            Field f = this.mc.field_1724.method_31548().getClass().getDeclaredField("selectedSlot");
            f.setAccessible(true);
            f.set(this.mc.field_1724.method_31548(), slot);
        }
        catch (Exception e) {
            e.printStackTrace();
            L50: ;
            return;
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (!this.mc.field_1724.method_6128()) {
            return;
        }
        int slot = ((Integer)this.hotbarSlot.get()).intValue() - 1;
        if (!this.mc.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_8639)) {
            class_1792[] tmp0 = new class_1792[1];
            tmp0[0] = class_1802.field_8639;
            FindItemResult result = InvUtils.find(tmp0);
            if (!result.found()) {
                return;
            }
            InvUtils.move().from(result.slot()).toHotbar(slot);
            return;
        }
        this.tickCounter = this.tickCounter + 1;
        if (this.tickCounter < ((Integer)this.delay.get()).intValue()) {
            return;
        }
        this.tickCounter = 0;
        prevSlot = this.getSelectedSlot();
        this.setSelectedSlot(slot);
        this.mc.field_1724.field_3944.method_52787(new class_2868(slot));
        this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
        this.mc.field_1724.method_6104(class_1268.field_5808);
        this.setSelectedSlot(prevSlot);
        this.mc.field_1724.field_3944.method_52787(new class_2868(prevSlot));
    }
}
