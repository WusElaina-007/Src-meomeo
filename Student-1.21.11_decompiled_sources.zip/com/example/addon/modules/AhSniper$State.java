/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

private static enum AhSniper.State {
    public static final AhSniper.State IDLE = new AhSniper.State("IDLE", 0);
    public static final AhSniper.State WAIT_AH_OPEN = new AhSniper.State("WAIT_AH_OPEN", 1);
    public static final AhSniper.State SCANNING = new AhSniper.State("SCANNING", 2);
    public static final AhSniper.State WAIT_CONFIRM = new AhSniper.State("WAIT_CONFIRM", 3);
    public static final AhSniper.State CONFIRMING = new AhSniper.State("CONFIRMING", 4);
    public static final AhSniper.State WAIT_CLOSE = new AhSniper.State("WAIT_CLOSE", 5);
    private static final /* synthetic */ AhSniper.State[] $VALUES;

    public static AhSniper.State[] values() {
        return (AhSniper.State[])$VALUES.clone();
    }

    public static AhSniper.State valueOf(String name) {
        return (AhSniper.State)Enum.valueOf(AhSniper.State.class, name);
    }

    private AhSniper.State() {
        super(var1, var2);
    }

    static {
        $VALUES = AhSniper.State.$values();
    }
}
