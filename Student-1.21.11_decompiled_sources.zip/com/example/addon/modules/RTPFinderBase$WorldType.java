/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

public static enum RTPFinderBase.WorldType {
    public static final RTPFinderBase.WorldType Overworld = new RTPFinderBase.WorldType("Overworld", 0);
    public static final RTPFinderBase.WorldType Nether = new RTPFinderBase.WorldType("Nether", 1);
    public static final RTPFinderBase.WorldType End = new RTPFinderBase.WorldType("End", 2);
    private static final /* synthetic */ RTPFinderBase.WorldType[] $VALUES;

    public static RTPFinderBase.WorldType[] values() {
        return (RTPFinderBase.WorldType[])$VALUES.clone();
    }

    public static RTPFinderBase.WorldType valueOf(String name) {
        return (RTPFinderBase.WorldType)Enum.valueOf(RTPFinderBase.WorldType.class, name);
    }

    private RTPFinderBase.WorldType() {
        super(var1, var2);
    }

    static {
        $VALUES = RTPFinderBase.WorldType.$values();
    }
}
