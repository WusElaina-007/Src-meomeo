/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.io.FileWriter;
import java.nio.file.Path;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_5251;
import net.minecraft.class_8646;

public class ScoreboardDump
extends Module {
    private boolean dumped = false;

    public ScoreboardDump() {
        super(AddonTemplate.Student_esp, "Scoreboard-Dump", "Dump scoreboard to chat.");
    }

    public void onActivate() {
        this.dumped = false;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (this.mc.field_1687 == null || this.mc.field_1724 == null || this.dumped) {
            return;
        }
        class_269 scoreboard = this.mc.field_1687.method_8428();
        class_266 sidebar = scoreboard.method_1189(class_8646.field_45157);
        if (sidebar == null) {
            this.mc.field_1724.method_7353(class_2561.method_43470("§cKhông có scoreboard sidebar!"), false);
            this.dumped = true;
            this.toggle();
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("========== TITLE ==========\n");
        this.dumpTextRecursive(sb, sidebar.method_1114(), 0);
        sb.append("\n");
        scoreboard.method_1178().stream().filter(ScoreboardDump::lambda$onTick$0 /* captured: scoreboard, sidebar */).sorted(ScoreboardDump::lambda$onTick$1 /* captured: scoreboard, sidebar */).forEach(this::lambda$onTick$2 /* captured: scoreboard, sidebar, sb */);
        Path path = this.mc.field_1697.toPath().resolve("scoreboard_dump.txt");
        FileWriter fw = new FileWriter(path.toFile());
        fw.write(sb.toString());
        this.mc.field_1724.method_7353(class_2561.method_43470("§aSaved: " + String.valueOf(path)), false);
        fw.close();
        /* goto L260; */
        var var7 = null;
        fw.close();
        /* goto L257; */
        var var8 = null;
        var7.addSuppressed(var8);
        L257: ;
        throw var7;
        L260: ;
        /* goto L289; */
        e = null;
        this.mc.field_1724.method_7353(class_2561.method_43470("§cLỗi ghi file: " + e.getMessage()), false);
        L289: ;
        this.dumped = true;
        this.toggle();
    }

    private void dumpTextRecursive(StringBuilder sb, class_2561 text, int depth) {
        String indent = "  ".repeat(depth);
        String content = text.getString();
        class_5251 color = text.method_10866().method_10973();
        String hex = color != null ? String.format("#%06X", color.method_27716()) : "none";
        sb.append(indent).append("[\"").append(content).append("\"").append(" color=").append(hex).append(text.method_10866().method_10984() ? " BOLD" : "").append(text.method_10866().method_10966() ? " ITALIC" : "").append(text.method_10866().method_10965() ? " UNDERLINE" : "").append(text.method_10866().method_10986() ? " STRIKETHROUGH" : "").append(text.method_10866().method_10987() ? " OBFUSCATED" : "").append("]\n");
        var var8 = text.method_10855().iterator();
        while (var8.hasNext()) {
            class_2561 sibling = (class_2561)var8.next();
            this.dumpTextRecursive(sb, sibling, depth + 1);
        }
    }
}
