/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.util.Set;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;

public class CriticalKillAura
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<Double> range = this.sgGeneral.add(((DoubleSetting.Builder)new DoubleSetting.Builder().name("range")).defaultValue(4).min(1).max(6).build());
    private final Setting<CriticalKillAura.TargetMode> targetMode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("target-mode")).description("choose target")).defaultValue(CriticalKillAura.TargetMode.Closest)).build());
    private final Setting<Set<class_1299<?>>> targets;
    private final Setting<Boolean> autoJump;
    private boolean wasInAir;
    private int attackCooldown;

    public CriticalKillAura() {
        super(AddonTemplate.Student_pvp, "critical-kill-aura", "");
        class_1299[] tmp0 = new class_1299[1];
        tmp0[0] = class_1299.field_6097;
        this.targets = this.sgGeneral.add(((EntityTypeListSetting.Builder)((EntityTypeListSetting.Builder)new EntityTypeListSetting.Builder().name("targets")).description("Entities to attack.")).defaultValue(tmp0).build());
        this.autoJump = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("auto-jump")).description("auto jump to attack critical")).defaultValue(true)).build());
        this.wasInAir = false;
        this.attackCooldown = 0;
    }

    public void onDeactivate() {
        this.wasInAir = false;
        this.attackCooldown = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (this.attackCooldown > 0) {
            this.attackCooldown = this.attackCooldown - 1;
            return;
        }
        class_1309 target = this.getTarget();
        if (target == null) {
            return;
        }
        if (this.mc.field_1724.method_24828()) {
            if (((Boolean)this.autoJump.get()).booleanValue()) {
                this.mc.field_1724.method_6043();
            }
            this.wasInAir = false;
            return;
        }
        if (!this.mc.field_1724.method_24828()) {
            this.wasInAir = true;
        }
        double velY = this.mc.field_1724.method_18798().field_1351;
        double height = this.mc.field_1724.method_23318() - Math.floor(this.mc.field_1724.method_23318());
        this.mc.field_1761.method_2918(this.mc.field_1724, target);
        if (this.wasInAir && velY < 0 && height >= 0.3 && height <= 0.5) {
            this.mc.field_1724.method_6104(this.mc.field_1724.method_6058());
            this.attackCooldown = 5;
            this.wasInAir = false;
        }
    }

    private class_1309 getTarget() {
        class_1309 best = null;
        double bestValue = 0;
        var var4 = this.mc.field_1687.method_18112().iterator();
        while (var4.hasNext()) {
            class_1297 entity = (class_1297)var4.next();
            if (!entity instanceof class_1309) continue;
            class_1309 living = (class_1309)entity;
            while (entity == this.mc.field_1724) {
            }
            while (!entity.method_5805()) {
            }
            double distance = (double)this.mc.field_1724.method_5739(entity);
            while (distance > ((Double)this.range.get()).doubleValue()) {
            }
            while (!((Set)this.targets.get()).contains(entity.method_5864())) {
            }
            switch (((CriticalKillAura.TargetMode)this.targetMode.get()).ordinal()) {
                default:
                    throw new MatchException(null, null);
                case 0::
                    double value = -distance;
                    break;
                case 1::
                    value = distance;
                    break;
                case 2::
                    value = (double)-living.method_6032();
                    break;
                case 3::
                    value = (double)living.method_6032();
                    break;
            }
            if (best == null || value > bestValue) {
                bestValue = value;
                best = living;
            }
        }
        return best;
    }
}
