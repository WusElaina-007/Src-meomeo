/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.util.HashSet;
import java.util.Set;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_332;

public class CustomCrosshair
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    public final Setting<SettingColor> color = this.sgGeneral.add(((ColorSetting.Builder)new ColorSetting.Builder().name("color")).defaultValue(new SettingColor(255, 255, 255)).build());
    public final Setting<Integer> pixelScale = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("scale")).defaultValue(2)).min(1).sliderMax(10).build());
    public final Set<String> pixels = new HashSet();

    public CustomCrosshair() {
        super(AddonTemplate.Student, "custom-crosshair", "Draw your own crosshair.");
    }

    public WWidget getWidget(GuiTheme theme) {
        WButton button = theme.button("Open Editor");
        button.action = this::lambda$getWidget$0;
        return button;
    }

    public void renderMixin(class_332 context) {
        if (this.pixels.isEmpty() || this.mc.method_53526().method_53536()) {
            return;
        }
        float centerX = (float)this.mc.method_22683().method_4486() / 2f;
        float centerY = (float)this.mc.method_22683().method_4502() / 2f;
        int scale = ((Integer)this.pixelScale.get()).intValue();
        int packed = ((SettingColor)this.color.get()).getPacked();
        var var6 = this.pixels.iterator();
        while (var6.hasNext()) {
            String pixel = (String)var6.next();
            String[] coords = pixel.split(",");
            int x = Integer.parseInt(coords[0]);
            int y = Integer.parseInt(coords[1]);
            int rx = (int)(centerX + (float)(x * scale) - (float)scale / 2f);
            int ry = (int)(centerY + (float)(y * scale) - (float)scale / 2f);
            context.method_25294(rx, ry, rx + scale, ry + scale, packed);
        }
    }

    public class_2487 toTag() {
        class_2487 tag = super.toTag();
        class_2499 list = new class_2499();
        var var3 = this.pixels.iterator();
        while (var3.hasNext()) {
            String pixel = (String)var3.next();
            list.add(class_2519.method_23256(pixel));
        }
        tag.method_10566("pixels", list);
        return tag;
    }

    public Module fromTag(class_2487 tag) {
        super.fromTag(tag);
        this.pixels.clear();
        tag.method_10554("pixels").ifPresent(this::lambda$fromTag$1);
        return this;
    }
}
