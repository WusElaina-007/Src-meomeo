/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_465;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

public class AhSniper
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<Double> maxPrice = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("max-price")).description("Maximum price to buy item. Supports K/M/B suffix (e.g. 1K = 1000).")).defaultValue(1000000).min(1).sliderMax(10000000000).noSlider().build());
    private final Setting<List<class_1792>> targetItems = this.sgGeneral.add(((ItemListSetting.Builder)((ItemListSetting.Builder)new ItemListSetting.Builder().name("target-items")).description("List of items to snipe from /ah.")).defaultValue(new class_1792[0]).build());
    private AhSniper.State state = AhSniper.State.IDLE;
    private int tickTimer = 0;
    private class_465<?> ahScreen = null;
    private static final Pattern PRICE_KMB_PATTERN = Pattern.compile("([0-9]+(?:[.,][0-9]+)*)([KkMmBb]?)");

    public AhSniper() {
        super(AddonTemplate.Student, "ah-sniper", "Auto buy items from /ah.");
    }

    public void onActivate() {
        this.state = AhSniper.State.IDLE;
        this.tickTimer = 0;
        this.ahScreen = null;
        this.sendAh();
        this.state = AhSniper.State.WAIT_AH_OPEN;
        this.tickTimer = 40;
    }

    public void onDeactivate() {
        this.state = AhSniper.State.IDLE;
        this.ahScreen = null;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (!this.isActive() || this.mc.field_1724 == null) {
            return;
        }
        if (this.tickTimer > 0) {
            this.tickTimer = this.tickTimer - 1;
            return;
        }
        switch (this.state.ordinal()) {
            case 1::
                class_1703 handler = this.mc.field_1755;
                if (handler instanceof class_465) {
                    class_465<?> screen = (class_465)handler;
                    this.ahScreen = screen;
                    this.state = AhSniper.State.SCANNING;
                } else {
                    this.sendAh();
                    this.tickTimer = 40;
                    /* goto @592; */
                }
            case 2::
                if (!(this.mc.field_1755 instanceof class_465)) {
                    this.sendAh();
                    this.state = AhSniper.State.WAIT_AH_OPEN;
                    this.tickTimer = 40;
                    return;
                }
                class_465<?> screen = (class_465)this.mc.field_1755;
                handler = screen.method_17577();
                boolean found = false;
                for (int i = 0; i < Math.min(45, handler.field_7761.size()); i++) {
                    class_1799 stack = ((class_1735)handler.field_7761.get(i)).method_7677();
                    if (stack.method_7960()) {
                    } else {
                        if (!((List)this.targetItems.get()).contains(stack.method_7909())) {
                        } else {
                            double price = this.getPriceFromLore(stack);
                            if (price < 0) {
                            } else {
                                if (price > ((Double)this.maxPrice.get()).doubleValue()) {
                                } else {
                                    this.mc.field_1761.method_2906(handler.field_7763, i, 0, class_1713.field_7790, this.mc.field_1724);
                                    found = true;
                                    this.state = AhSniper.State.WAIT_CONFIRM;
                                    this.tickTimer = 10;
                                    /* goto @340; */
                                }
                            }
                        }
                    }
                }
                if (!found) {
                    this.mc.field_1724.method_7346();
                    this.sendAh();
                    this.state = AhSniper.State.WAIT_AH_OPEN;
                    this.tickTimer = 30;
                }
                /* goto @592; */
            case 3::
                if (!(this.mc.field_1755 instanceof class_465)) {
                    this.tickTimer = 5;
                    return;
                }
                confirmScreen = (class_465)this.mc.field_1755;
                if (confirmScreen == this.ahScreen) {
                    this.tickTimer = 5;
                    return;
                }
                this.state = AhSniper.State.CONFIRMING;
                this.tickTimer = 2;
                /* goto @592; */
            case 4::
                confirmHandler = this.mc.field_1755;
                if (confirmHandler instanceof class_465) {
                    confirmScreen = (class_465)confirmHandler;
                } else {
                    this.sendAh();
                    this.state = AhSniper.State.WAIT_AH_OPEN;
                    this.tickTimer = 40;
                    return;
                }
                confirmHandler = confirmScreen.method_17577();
                j = false;
                while (j < confirmHandler.field_7761.size()) {
                    s = ((class_1735)confirmHandler.field_7761.get(j)).method_7677();
                    if (s.method_31574(class_1802.field_8581)) {
                        this.mc.field_1761.method_2906(confirmHandler.field_7763, j, 0, class_1713.field_7790, this.mc.field_1724);
                    } else {
                        j++;
                    }
                }
                this.state = AhSniper.State.WAIT_CLOSE;
                this.tickTimer = 12;
                /* goto @592; */
            case 5::
                this.sendAh();
                this.state = AhSniper.State.WAIT_AH_OPEN;
                this.tickTimer = 40;
            default:
                return;
        }
    }

    private double parsePrice(String text) {
        text = text.trim();
        Matcher matcher = PRICE_KMB_PATTERN.matcher(text);
        if (!matcher.find()) {
            return -1;
        }
        String numPart = matcher.group(1);
        String suffix = matcher.group(2);
        long dotCount = numPart.chars().filter(AhSniper::lambda$parsePrice$0).count();
        long commaCount = numPart.chars().filter(AhSniper::lambda$parsePrice$1).count();
        try {
            if (!suffix.isEmpty()) {
                if (dotCount > 1L) {
                    numPart = numPart.replace(".", "").replace(",", "");
                } else {
                    if (commaCount > 1L) {
                        numPart = numPart.replace(",", "").replace(".", "");
                    } else {
                        if (dotCount == 1L) {
                            if (commaCount != 1L) { /* goto @221; */ }
                            int lastDot = numPart.lastIndexOf(46);
                            int lastComma = numPart.lastIndexOf(44);
                            if (lastDot > lastComma) {
                                numPart = numPart.replace(",", "");
                            } else {
                                numPart = numPart.replace(".", "").replace(",", ".");
                            }
                        } else {
                            numPart = numPart.replace(",", ".");
                        }
                    }
                }
            } else {
                numPart = numPart.replace(",", "").replace(".", "");
            }
            double value = Double.parseDouble(numPart);
            var var11 = suffix.toUpperCase();
            int var12 = -1;
            switch (var11.hashCode()) {
                case 75::
                    if (!var11.equals("K")) { /* goto @360; */ }
                    var12 = 0;
                    /* goto @360; */
                case 77::
                    if (!var11.equals("M")) { /* goto @360; */ }
                    var12 = 1;
                    /* goto @360; */
                case 66::
                    if (var11.equals("B")) {
                        var12 = 2;
                    }
                default:
                    switch (var12) {
                        case 0::
                            return value * 1000;
                        case 1::
                            return value * 1000000;
                        case 2::
                            return value * 1000000000;
                        default:
                            return value;
                    }
            }
        }
        catch (NumberFormatException e) {
            return -1;
        }
    }

    private double getPriceFromLore(class_1799 stack) {
        class_9290 lore = (class_9290)stack.method_58694(class_9334.field_49632);
        if (lore == null) {
            return -1;
        }
        var var3 = lore.comp_2400().iterator();
        while (var3.hasNext()) {
            class_2561 line = (class_2561)var3.next();
            String text = line.getString();
            String lower = text.toLowerCase();
            boolean isPriceLine = lower.contains("giá:") || lower.contains("ɢɪá:") || lower.contains("ɢɪÁ:") || lower.contains("price:") || text.contains("$");
            while (!isPriceLine) {
            }
            Matcher kmb = Pattern.compile("([0-9]+(?:[.,][0-9]+)*)([KkMmBb])").matcher(text);
            if (kmb.find()) {
                double price = this.parsePrice(kmb.group(1) + kmb.group(2));
                if (!price > 0) continue;
                return price;
            }
            num = Pattern.compile("([0-9]+(?:[.,][0-9]+)*)").matcher(text);
            if (num.find()) {
                double price = this.parsePrice(num.group(1));
                if (!price > 0) continue;
                return price;
            }
        }
        return -1;
    }

    private void sendAh() {
        if (this.mc.field_1724 == null) {
            return;
        }
        this.mc.field_1724.field_3944.method_45730("ah");
    }
}
