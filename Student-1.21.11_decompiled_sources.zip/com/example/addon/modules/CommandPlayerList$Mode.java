/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

public static enum CommandPlayerList.Mode {
    public static final CommandPlayerList.Mode Chat = new CommandPlayerList.Mode("Chat", 0);
    public static final CommandPlayerList.Mode Command = new CommandPlayerList.Mode("Command", 1);
    private static final /* synthetic */ CommandPlayerList.Mode[] $VALUES;

    public static CommandPlayerList.Mode[] values() {
        return (CommandPlayerList.Mode[])$VALUES.clone();
    }

    public static CommandPlayerList.Mode valueOf(String name) {
        return (CommandPlayerList.Mode)Enum.valueOf(CommandPlayerList.Mode.class, name);
    }

    private CommandPlayerList.Mode() {
        super(var1, var2);
    }

    static {
        $VALUES = CommandPlayerList.Mode.$values();
    }
}
