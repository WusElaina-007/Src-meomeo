/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_310;
import net.minecraft.class_640;

public class CommandPlayerList
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<CommandPlayerList.Mode> mode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("mode")).defaultValue(CommandPlayerList.Mode.Command)).build());
    private final Setting<Boolean> useFileList = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("file-list")).description("Bật: lấy danh sách từ file txt | Tắt: lấy danh sách người chơi trên server")).defaultValue(false)).build());
    private final Setting<String> baseCommand = this.sgGeneral.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("base-command")).description("Lệnh trước tên, ví dụ: bal")).defaultValue("bal")).build());
    private final Setting<String> suffix = this.sgGeneral.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("suffix")).description("Text thêm sau tên player")).defaultValue("")).build());
    private final Setting<String> fileName;
    private final Setting<Integer> delay;
    private List<String> players;
    private int index;
    private long lastSend;

    public CommandPlayerList() {
        super(AddonTemplate.Student, "command-player-list", "Send command to a list of players loaded from file or server");
        Objects.requireNonNull(this.useFileList);
        this.fileName = this.sgGeneral.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("file-name")).description("Tên file txt trong thư mục .minecraft (ví dụ: names.txt)")).defaultValue("names.txt")).visible(this.useFileList::get)).build());
        this.delay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("delay-ms")).defaultValue(1500)).min(500).sliderMax(5000).build());
    }

    public void onActivate() {
        this.players = new ArrayList();
        this.index = 0;
        this.lastSend = 0L;
        if (((Boolean)this.useFileList.get()).booleanValue()) {
            Path filePath = class_310.method_1551().field_1697.toPath().resolve((String)this.fileName.get());
            if (!Files.exists(filePath, new LinkOption[0])) {
                this.toggle();
                return;
            }
        }
        try {
            List<String> lines = Files.readAllLines(filePath);
            String name = lines.iterator();
            while (name.hasNext()) {
                String line = (String)name.next();
                String name = line.trim();
                if (name.isEmpty()) continue;
                this.players.add(name);
            }
        }
        catch (IOException e) {
            this.toggle();
            return;
        }
        if (this.players.isEmpty()) {
            this.toggle();
            return;
        }
        /* goto L269; */
        L169: ;
        if (this.mc.method_1562() == null) {
            this.toggle();
            return;
        }
        filePath = this.mc.method_1562().method_2880().iterator();
        while (filePath.hasNext()) {
            entry = (class_640)filePath.next();
            name = entry.method_2966().name();
            if (name != null) {
                if (name.isEmpty()) continue;
                this.players.add(name);
            }
        }
        if (this.players.isEmpty()) {
            this.toggle();
            return;
        }
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (this.mc.field_1724 == null || this.players.isEmpty()) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now - this.lastSend < (long)((Integer)this.delay.get()).intValue()) {
            return;
        }
        if (this.index >= this.players.size()) {
            this.toggle();
            return;
        }
        String player = (String)this.players.get(this.index);
        String extra = ((String)this.suffix.get()).isEmpty() ? "" : " " + (String)this.suffix.get();
        String msg = ((String)this.baseCommand.get()).trim() + " " + player + extra;
        switch (((CommandPlayerList.Mode)this.mode.get()).ordinal()) {
            case 0::
                this.mc.field_1724.field_3944.method_45729("/" + msg.trim());
                /* goto @236; */
            case 1::
                this.mc.field_1724.field_3944.method_45730(msg.trim());
            default:
                this.lastSend = now;
                this.index = this.index + 1;
                return;
        }
    }
}
