/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

private static enum SpawnerProtect.State {
    public static final SpawnerProtect.State IDLE = new SpawnerProtect.State("IDLE", 0);
    public static final SpawnerProtect.State SCAN = new SpawnerProtect.State("SCAN", 1);
    public static final SpawnerProtect.State MINING = new SpawnerProtect.State("MINING", 2);
    public static final SpawnerProtect.State LOOT = new SpawnerProtect.State("LOOT", 3);
    public static final SpawnerProtect.State STORE = new SpawnerProtect.State("STORE", 4);
    private static final /* synthetic */ SpawnerProtect.State[] $VALUES;

    public static SpawnerProtect.State[] values() {
        return (SpawnerProtect.State[])$VALUES.clone();
    }

    public static SpawnerProtect.State valueOf(String name) {
        return (SpawnerProtect.State)Enum.valueOf(SpawnerProtect.State.class, name);
    }

    private SpawnerProtect.State() {
        super(var1, var2);
    }

    static {
        $VALUES = SpawnerProtect.State.$values();
    }
}
