/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;

public class SwingHand
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    public final Setting<Double> scale = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("scale")).description("Kích cỡ tay.")).defaultValue(0.75).min(0.1).sliderMax(2).build());
    public final Setting<Double> speed = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("speed")).description("Tốc độ swing.")).defaultValue(100).min(1).sliderMax(2000).build());
    public final Setting<Double> xPos = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("x-pos")).description("Vị trí X.")).defaultValue(0.7).sliderMin(-2).sliderMax(2).build());
    public final Setting<Double> yPos = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("y-pos")).description("Vị trí Y.")).defaultValue(-0.4).sliderMin(-2).sliderMax(2).build());
    public final Setting<Double> zPos = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("z-pos")).description("Vị trí Z.")).defaultValue(-0.85).sliderMin(-2).sliderMax(2).build());
    public final Setting<Double> rotX = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("rot-x")).description("Xoay X.")).defaultValue(0).sliderMin(-180).sliderMax(180).build());
    public final Setting<Double> rotY = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("rot-y")).description("Xoay Y.")).defaultValue(-13).sliderMin(-180).sliderMax(180).build());
    public final Setting<Double> rotZ = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("rot-z")).description("Xoay Z.")).defaultValue(8).sliderMin(-180).sliderMax(180).build());
    public final Setting<Double> xSwingRot = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("x-swing-rot")).description("Xoay swing X.")).defaultValue(-55).sliderMin(-180).sliderMax(180).build());
    public final Setting<Double> ySwingRot = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("y-swing-rot")).description("Xoay swing Y.")).defaultValue(0).sliderMin(-180).sliderMax(180).build());
    public final Setting<Double> zSwingRot = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("z-swing-rot")).description("Xoay swing Z.")).defaultValue(90).sliderMin(-180).sliderMax(180).build());

    public SwingHand() {
        super(AddonTemplate.Student, "swing-hand", "Tuỳ chỉnh swing tay.");
    }
}
