/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

private static enum RTPFinderBase.State {
    public static final RTPFinderBase.State WAIT_COOLDOWN = new RTPFinderBase.State("WAIT_COOLDOWN", 0);
    public static final RTPFinderBase.State WAIT_GUI = new RTPFinderBase.State("WAIT_GUI", 1);
    public static final RTPFinderBase.State STEAL = new RTPFinderBase.State("STEAL", 2);
    public static final RTPFinderBase.State WAIT_AFTER = new RTPFinderBase.State("WAIT_AFTER", 3);
    public static final RTPFinderBase.State GOTO = new RTPFinderBase.State("GOTO", 4);
    private static final /* synthetic */ RTPFinderBase.State[] $VALUES;

    public static RTPFinderBase.State[] values() {
        return (RTPFinderBase.State[])$VALUES.clone();
    }

    public static RTPFinderBase.State valueOf(String name) {
        return (RTPFinderBase.State)Enum.valueOf(RTPFinderBase.State.class, name);
    }

    private RTPFinderBase.State() {
        super(var1, var2);
    }

    static {
        $VALUES = RTPFinderBase.State.$values();
    }
}
