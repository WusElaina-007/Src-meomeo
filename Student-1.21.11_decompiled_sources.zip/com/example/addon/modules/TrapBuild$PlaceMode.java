/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

public static enum TrapBuild.PlaceMode {
    public static final TrapBuild.PlaceMode Around = new TrapBuild.PlaceMode("Around", 0);
    public static final TrapBuild.PlaceMode Under = new TrapBuild.PlaceMode("Under", 1);
    public static final TrapBuild.PlaceMode In = new TrapBuild.PlaceMode("In", 2);
    private static final /* synthetic */ TrapBuild.PlaceMode[] $VALUES;

    public static TrapBuild.PlaceMode[] values() {
        return (TrapBuild.PlaceMode[])$VALUES.clone();
    }

    public static TrapBuild.PlaceMode valueOf(String name) {
        return (TrapBuild.PlaceMode)Enum.valueOf(TrapBuild.PlaceMode.class, name);
    }

    private TrapBuild.PlaceMode() {
        super(var1, var2);
    }

    static {
        $VALUES = TrapBuild.PlaceMode.$values();
    }
}
