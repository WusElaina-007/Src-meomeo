/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1299;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2868;
import net.minecraft.class_2885;
import net.minecraft.class_3965;

public class TrapBuild
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<TrapBuild.PlaceMode> mode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("mode")).description("Chế độ đặt block.")).defaultValue(TrapBuild.PlaceMode.Around)).build());
    private final Setting<List<class_2248>> blocks;
    private final Setting<Set<class_1299<?>>> entities;
    private final Setting<Integer> delay;
    private int timer;

    public TrapBuild() {
        super(AddonTemplate.Student_pvp, "Trap-Build", "Đặt block bẫy entity.");
        class_2248[] tmp0 = new class_2248[1];
        tmp0[0] = class_2246.field_10540;
        this.blocks = this.sgGeneral.add(((BlockListSetting.Builder)((BlockListSetting.Builder)new BlockListSetting.Builder().name("blocks")).description("Danh sách block để đặt.")).defaultValue(tmp0).build());
        class_1299[] tmp1 = new class_1299[1];
        tmp1[0] = class_1299.field_6097;
        this.entities = this.sgGeneral.add(((EntityTypeListSetting.Builder)((EntityTypeListSetting.Builder)new EntityTypeListSetting.Builder().name("entities")).description("Danh sách entity để bẫy.")).defaultValue(tmp1).build());
        this.delay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("delay")).description("Delay giữa mỗi lần đặt (tick).")).defaultValue(0)).min(0).sliderMax(10).build());
        this.timer = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (this.mc.field_1761 == null) {
            return;
        }
        if (this.mc.field_1761.method_2920() == class_1934.field_9219) {
            return;
        }
        if (this.timer > 0) {
            this.timer = this.timer - 1;
            return;
        }
        this.timer = ((Integer)this.delay.get()).intValue();
        int selectedSlot = -1;
        int i = 0;
        while (i < 9) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
            var var6 = stack.method_7909();
            if (var6 instanceof class_1747) {
                class_1747 bi = (class_1747)var6;
                if (!((List)this.blocks.get()).contains(bi.method_7711())) continue;
                selectedSlot = i;
            } else {
                i++;
            }
        }
        if (selectedSlot == -1) {
            return;
        }
        currentSlot = this.mc.field_1724.method_31548().method_67532();
        this.mc.method_1562().method_52787(new class_2868(selectedSlot));
        this.mc.field_1687.method_18112().forEach(this::lambda$onTick$0);
        this.mc.method_1562().method_52787(new class_2868(currentSlot));
    }

    private List<class_2338> getPositions(class_2338 origin) {
        List<class_2338> list = new ArrayList();
        switch (((TrapBuild.PlaceMode)this.mode.get()).ordinal()) {
            case 0::
                list.add(origin.method_10095());
                list.add(origin.method_10072());
                list.add(origin.method_10078());
                list.add(origin.method_10067());
                list.add(origin.method_10095().method_10084());
                list.add(origin.method_10072().method_10084());
                list.add(origin.method_10078().method_10084());
                list.add(origin.method_10067().method_10084());
                list.add(origin.method_10086(2));
                /* goto @202; */
            case 1::
                list.add(origin);
                /* goto @202; */
            case 2::
                list.add(origin.method_10069(0, 0, 0));
                list.add(origin.method_10069(0, 1, 0));
            default:
                return list;
        }
    }

    private void placeBlock(class_2338 pos) {
        var var2 = class_2350.values();
        var var3 = var2.length;
        for (int var4 = 0; var4 < var3; var4++) {
            class_2350 dir = var2[var4];
            class_2338 neighbor = pos.method_10093(dir);
            if (this.mc.field_1687.method_8320(neighbor).method_26215()) {
            } else {
                class_243 hitVec = class_243.method_24953(pos).method_1031((double)dir.method_10148() * 0.5, (double)dir.method_10164() * 0.5, (double)dir.method_10165() * 0.5);
                this.mc.method_1562().method_52787(new class_2885(class_1268.field_5808, new class_3965(hitVec, dir.method_10153(), neighbor, false), 0));
                return;
            }
        }
    }
}
