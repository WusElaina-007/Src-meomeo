/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.pressable.WCheckbox;
import meteordevelopment.meteorclient.systems.modules.Module;

public class CrafterSetup
extends Module {
    public final boolean[] slots = new boolean[9];

    public CrafterSetup() {
        super(AddonTemplate.Student, "crafter-setup", "Crafter slot pattern auto-apply.");
    }

    public WWidget getWidget(GuiTheme theme) {
        WTable table = theme.table();
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                int slot = row * 3 + col;
                WCheckbox checkbox = (WCheckbox)table.add(theme.checkbox(this.slots[slot])).widget();
                checkbox.action = this::lambda$getWidget$0 /* captured: slot, checkbox */;
            }
            table.row();
        }
        return table;
    }

    public boolean isSlotEnabled(int slot) {
        return slot >= 0 && slot < 9 && this.slots[slot] != 0;
    }

    public boolean shouldAutoApply() {
        return this.isActive();
    }
}
