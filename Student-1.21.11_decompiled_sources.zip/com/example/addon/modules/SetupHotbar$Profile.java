/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

public static enum SetupHotbar.Profile {
    public static final SetupHotbar.Profile Profile_1 = new SetupHotbar.Profile("Profile_1", 0);
    public static final SetupHotbar.Profile Profile_2 = new SetupHotbar.Profile("Profile_2", 1);
    public static final SetupHotbar.Profile Profile_3 = new SetupHotbar.Profile("Profile_3", 2);
    public static final SetupHotbar.Profile Profile_4 = new SetupHotbar.Profile("Profile_4", 3);
    public static final SetupHotbar.Profile Profile_5 = new SetupHotbar.Profile("Profile_5", 4);
    private static final /* synthetic */ SetupHotbar.Profile[] $VALUES;

    public static SetupHotbar.Profile[] values() {
        return (SetupHotbar.Profile[])$VALUES.clone();
    }

    public static SetupHotbar.Profile valueOf(String name) {
        return (SetupHotbar.Profile)Enum.valueOf(SetupHotbar.Profile.class, name);
    }

    private SetupHotbar.Profile() {
        super(var1, var2);
    }

    static {
        $VALUES = SetupHotbar.Profile.$values();
    }
}
