/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import com.example.addon.utils.glazed.BlockUtil;
import com.example.addon.utils.glazed.KeyUtils;
import java.util.HashSet;
import java.util.Set;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1621;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_2868;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public class CrystalLegit
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<Integer> activateKey = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("activate-key")).defaultValue(1)).min(-1).max(400).build());
    private final Setting<Double> placeDelay = this.sgGeneral.add(((DoubleSetting.Builder)new DoubleSetting.Builder().name("place-delay")).defaultValue(0).min(0).max(20).sliderMax(20).build());
    private final Setting<Double> breakDelay = this.sgGeneral.add(((DoubleSetting.Builder)new DoubleSetting.Builder().name("break-delay")).defaultValue(0).min(0).max(20).sliderMax(20).build());
    private final Setting<Boolean> stopOnKill = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("stop-on-kill")).description("Pauses the module when a nearby player dies, then resumes after 5 seconds.")).defaultValue(true)).build());
    private final Setting<Boolean> placeObsidianIfMissing = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("place-obsidian-if-missing")).description("Tự động đặt obsidian nếu block nhìn vào không phải obsidian hoặc bedrock.")).defaultValue(true)).build());
    private int placeDelayCounter;
    private int breakDelayCounter;
    private final Set<class_1657> deadPlayers = new HashSet();
    private boolean paused = false;
    private long resumeTime = 0L;

    public CrystalLegit() {
        super(AddonTemplate.Student_pvp, "CrystalLegit", "Legit crystal place & break.");
    }

    public void onActivate() {
        this.placeDelayCounter = 0;
        this.breakDelayCounter = 0;
        this.deadPlayers.clear();
        this.paused = false;
        this.resumeTime = 0L;
    }

    public void onDeactivate() {
        this.placeDelayCounter = 0;
        this.breakDelayCounter = 0;
        this.deadPlayers.clear();
        this.paused = false;
        this.resumeTime = 0L;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1755 != null) {
            return;
        }
        this.updateCounters();
        this.paused = false;
        if (this.paused && System.currentTimeMillis() >= this.resumeTime) {
            this.mc.field_1724.method_7353(class_2561.method_43470("§7[§bCrystalLegit§7] §aResumed after stop-on-kill"), false);
        }
        if (this.paused) {
            return;
        }
        if (!this.isKeyActive()) {
            return;
        }
        if (this.mc.field_1724.method_6115()) {
            return;
        }
        if (!this.mc.field_1724.method_6047().method_31574(class_1802.field_8301)) {
            return;
        }
        this.paused = true;
        if (((Boolean)this.stopOnKill.get()).booleanValue() && this.checkForDeadPlayers()) {
            this.resumeTime = System.currentTimeMillis() + 5000L;
            this.mc.field_1724.method_7353(class_2561.method_43470("§7[§bCrystalLegit§7] §cPaused due to player death (resuming in 5s)"), false);
            return;
        }
        this.handleInteraction();
    }

    private void updateCounters() {
        if (this.placeDelayCounter > 0) {
            this.placeDelayCounter = this.placeDelayCounter - 1;
        }
        if (this.breakDelayCounter > 0) {
            this.breakDelayCounter = this.breakDelayCounter - 1;
        }
    }

    private boolean isKeyActive() {
        int key = ((Integer)this.activateKey.get()).intValue();
        return key == -1 || KeyUtils.isKeyPressed(key);
    }

    private void handleInteraction() {
        class_239 target = this.mc.field_1765;
        if (target instanceof class_3965) {
            class_3965 blockHit = (class_3965)target;
            this.handleBlockInteraction(blockHit);
            this.tryBreakCrystalAbove(blockHit.method_17777());
        }
        if (target instanceof class_3966) {
            entityHit = (class_3966)target;
            this.handleEntityInteraction(entityHit);
        }
    }

    private void handleBlockInteraction(class_3965 hit) {
        if (this.placeDelayCounter > 0) {
            return;
        }
        class_2338 pos = hit.method_17777();
        boolean isObsidianOrBedrock = BlockUtil.isBlockAtPosition(pos, class_2246.field_10540) || BlockUtil.isBlockAtPosition(pos, class_2246.field_9987);
        if (!isObsidianOrBedrock) {
            if (!((Boolean)this.placeObsidianIfMissing.get()).booleanValue()) {
                return;
            }
            int obsidianSlot = this.findObsidianSlot();
            int crystalSlot = this.findCrystalSlot();
            if (obsidianSlot == -1 || crystalSlot == -1) {
                return;
            }
            this.mc.field_1724.field_3944.method_52787(new class_2868(obsidianSlot));
            BlockUtil.interactWithBlock(hit, true);
            this.mc.field_1724.method_6104(class_1268.field_5808);
            this.placeDelayCounter = ((Double)this.placeDelay.get()).intValue();
            this.mc.field_1724.field_3944.method_52787(new class_2868(crystalSlot));
            return;
        }
        if (!this.isValidCrystalPlacement(pos)) {
            return;
        }
        BlockUtil.interactWithBlock(hit, true);
        this.mc.field_1724.method_6104(class_1268.field_5808);
        this.placeDelayCounter = ((Double)this.placeDelay.get()).intValue();
    }

    private void tryBreakCrystalAbove(class_2338 blockPos) {
        if (this.breakDelayCounter > 0) {
            return;
        }
        class_2338 up = blockPos.method_10084();
        class_238 box = new class_238(up);
        var var4 = this.mc.field_1687.method_8335(null, box).iterator();
        while (var4.hasNext()) {
            class_1297 entity = (class_1297)var4.next();
            if (entity instanceof class_1511) {
                this.mc.field_1761.method_2918(this.mc.field_1724, entity);
                this.mc.field_1724.method_6104(class_1268.field_5808);
                this.breakDelayCounter = ((Double)this.breakDelay.get()).intValue();
                return;
            }
        }
    }

    private void handleEntityInteraction(class_3966 hit) {
        if (this.breakDelayCounter > 0) {
            return;
        }
        class_1297 entity = hit.method_17782();
        if (!(entity instanceof class_1511) && !(entity instanceof class_1621)) {
            return;
        }
        this.mc.field_1761.method_2918(this.mc.field_1724, entity);
        this.mc.field_1724.method_6104(class_1268.field_5808);
        this.breakDelayCounter = ((Double)this.breakDelay.get()).intValue();
    }

    private boolean isValidCrystalPlacement(class_2338 pos) {
        class_2338 up = pos.method_10084();
        if (!this.mc.field_1687.method_22347(up)) {
            return false;
        }
        return this.mc.field_1687.method_8335(null, new class_238((double)up.method_10263(), (double)up.method_10264(), (double)up.method_10260(), (double)(up.method_10263() + 1), (double)(up.method_10264() + 2), (double)(up.method_10260() + 1))).isEmpty();
    }

    private boolean checkForDeadPlayers() {
        if (this.mc.field_1687 == null) {
            return false;
        }
        var var1 = this.mc.field_1687.method_18456().iterator();
        while (var1.hasNext()) {
            class_1657 player = (class_1657)var1.next();
            while (player == this.mc.field_1724) {
            }
            if (player.method_29504() || player.method_6032() <= 0f) {
                if (!this.deadPlayers.contains(player)) {
                    this.deadPlayers.add(player);
                    return true;
                }
            }
        }
        this.deadPlayers.removeIf(CrystalLegit::lambda$checkForDeadPlayers$0);
        return false;
    }

    private int findObsidianSlot() {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_31574(class_1802.field_8281)) continue;
            return i;
        }
        return -1;
    }

    private int findCrystalSlot() {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_31574(class_1802.field_8301)) continue;
            return i;
        }
        return -1;
    }
}
