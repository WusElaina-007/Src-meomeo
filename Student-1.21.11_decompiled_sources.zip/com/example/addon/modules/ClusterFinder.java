/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2818;

public class ClusterFinder
extends Module {
    private final SettingGroup sgGeneral = this.settings.createGroup("General");
    private final SettingGroup sgNotifications = this.settings.createGroup("Notifications");
    private final Setting<SettingColor> chunkColor = this.sgGeneral.add(((ColorSetting.Builder)new ColorSetting.Builder().name("chunk-color")).defaultValue(new SettingColor(180, 50, 230, 60)).build());
    private final Setting<Boolean> showToast = this.sgNotifications.add(((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("show-toast")).defaultValue(true)).build());
    private final Setting<Boolean> playSound = this.sgNotifications.add(((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("play-sound")).defaultValue(true)).build());
    private static final int CLUSTER_THRESHOLD = 5;
    private final Set<class_1923> flaggedChunks = ConcurrentHashMap.newKeySet();
    private final Map<class_1923, Long> lastNotificationTimes = new ConcurrentHashMap();
    private final Queue<Long> recentNotifications = new ConcurrentLinkedQueue();
    private ExecutorService threadPool;
    private boolean active = false;

    public ClusterFinder() {
        super(AddonTemplate.Student_esp, "ClusterFinder", "Finds Amethyst Clusters.");
    }

    public void onActivate() {
        this.active = true;
        this.threadPool = Executors.newFixedThreadPool(2);
        this.flaggedChunks.clear();
        var var1 = Utils.chunks().iterator();
        while (var1.hasNext()) {
            class_2791 chunk = (class_2791)var1.next();
            if (chunk instanceof class_2818) {
                class_2818 wc = (class_2818)chunk;
                this.threadPool.submit(this::lambda$onActivate$0 /* captured: wc */);
            }
        }
    }

    public void onDeactivate() {
        this.active = false;
        if (this.threadPool != null) {
            this.threadPool.shutdownNow();
        }
    }

    @EventHandler
    private void onChunkLoad(ChunkDataEvent event) {
        if (this.threadPool != null) {
            this.threadPool.submit(this::lambda$onChunkLoad$1 /* captured: event */);
        }
    }

    private void scanChunk(class_2818 chunk) {
        if (!this.active || chunk == null) {
            return;
        }
        class_1923 cpos = chunk.method_12004();
        int count = 0;
        int minY = chunk.method_31607();
        int topY = minY + chunk.method_31605();
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                for (int y = minY; y < topY; y++) {
                    class_2680 state = chunk.method_8320(new class_2338(cpos.method_8326() + x, y, cpos.method_8328() + z));
                    if (!state.method_27852(class_2246.field_27161)) continue;
                    count++;
                }
            }
        }
        finalCount = count;
        if (count >= 5) {
            if (this.flaggedChunks.add(cpos)) {
                this.mc.execute(this::lambda$scanChunk$2 /* captured: finalCount */);
            }
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        Color color = new Color((Color)this.chunkColor.get());
        var var3 = this.flaggedChunks.iterator();
        while (var3.hasNext()) {
            class_1923 cp = (class_1923)var3.next();
            class_238 box = new class_238((double)cp.method_8326(), 64, (double)cp.method_8328(), (double)(cp.method_8327() + 1), 64.5, (double)(cp.method_8329() + 1));
            event.renderer.box(box, color, color, ShapeMode.Both, 0);
        }
    }
}
