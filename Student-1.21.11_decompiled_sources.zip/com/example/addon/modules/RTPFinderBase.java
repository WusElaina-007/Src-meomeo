/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.util.List;
import meteordevelopment.meteorclient.events.game.ReceiveMessageEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2818;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class RTPFinderBase
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final SettingGroup sgWebhook = this.settings.createGroup("Webhook");
    private final SettingGroup sgSound = this.settings.createGroup("Sound");
    private final Setting<RTPFinderBase.WorldType> world = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("world")).defaultValue(RTPFinderBase.WorldType.Overworld)).build());
    private final Setting<Boolean> baseFinder;
    private final Setting<Integer> depth;
    private final Setting<Integer> spamDelay;
    private final Setting<Integer> containerLimit;
    private final Setting<List<class_2248>> targetBlocks;
    private final Setting<String> webhookUrl;
    private final Setting<Boolean> webhookEnabled;
    private final Setting<Boolean> disconnectOnFound;
    private final Setting<Double> volume;
    private RTPFinderBase.State state;
    private boolean baseFound;
    private int serverCooldown;
    private int rtpWaitTimer;
    private int waitTimer;
    private int loopTimer;

    public RTPFinderBase() {
        super(AddonTemplate.Student_esp, "RTP Finder Base", "RTP and mine down to find base.");
        this.baseFinder = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("base-finder")).defaultValue(false)).visible(this::lambda$new$0)).build());
        this.depth = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("depth")).description("Y level đào xuống khi dùng #goto")).defaultValue(30)).min(-64).sliderMin(-64).sliderMax(320).visible(this::lambda$new$1)).build());
        this.spamDelay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("spam-delay")).defaultValue(40)).min(10).build());
        this.containerLimit = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("container-limit")).defaultValue(10)).min(1).sliderMax(100).build());
        class_2248[] tmp0 = new class_2248[3];
        tmp0[0] = class_2246.field_10034;
        tmp0[1] = class_2246.field_16328;
        tmp0[2] = class_2246.field_10603;
        this.targetBlocks = this.sgGeneral.add(((BlockListSetting.Builder)new BlockListSetting.Builder().name("target-blocks")).defaultValue(tmp0).build());
        this.webhookUrl = this.sgWebhook.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("webhook-url")).description("Discord Webhook URL")).defaultValue("")).build());
        this.webhookEnabled = this.sgWebhook.add(((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("enable-webhook")).defaultValue(true)).build());
        this.disconnectOnFound = this.sgWebhook.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("disconnect-on-found")).description("Tự out game khi phát hiện base")).defaultValue(true)).build());
        this.volume = this.sgSound.add(((DoubleSetting.Builder)new DoubleSetting.Builder().name("volume")).defaultValue(1).min(0).max(5).build());
        this.state = RTPFinderBase.State.WAIT_GUI;
        this.baseFound = false;
        this.serverCooldown = 0;
        this.rtpWaitTimer = 0;
        this.waitTimer = 0;
        this.loopTimer = 0;
    }

    public void onActivate() {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        this.baseFound = false;
        this.serverCooldown = 0;
        this.rtpWaitTimer = 0;
        this.waitTimer = 0;
        this.loopTimer = 0;
        this.scanForBase();
        if (this.baseFound) {
            return;
        }
        this.sendRtp();
    }

    public void onDeactivate() {
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (this.baseFound) {
            return;
        }
        switch (this.state.ordinal()) {
            case 0::
                if (this.serverCooldown > 0) {
                    this.serverCooldown = this.serverCooldown - 1;
                } else {
                    this.sendRtp();
                    /* goto @303; */
                }
            case 1::
                this.rtpWaitTimer = this.rtpWaitTimer + 1;
                if (this.mc.field_1724.field_7512 instanceof class_1707) {
                    this.state = RTPFinderBase.State.STEAL;
                    this.rtpWaitTimer = 0;
                    return;
                }
                if (this.rtpWaitTimer < 100) { /* goto @303; */ }
                this.rtpWaitTimer = 0;
                this.sendRtp();
                /* goto @303; */
            case 2::
                var var3 = this.mc.field_1724.field_7512;
                if (var3 instanceof class_1707) {
                    class_1707 handler = (class_1707)var3;
                    this.stealBlock(handler);
                } else {
                    this.sendRtp();
                    /* goto @303; */
                }
            case 3::
                this.waitTimer = this.waitTimer + 1;
                this.loopTimer = this.loopTimer + 1;
                this.scanForBase();
                if (this.baseFound) {
                    return;
                }
                if (this.waitTimer >= 200) {
                    this.afterWait();
                    this.state = RTPFinderBase.State.GOTO;
                }
                if (this.loopTimer < 1300) { /* goto @303; */ }
                this.resetAndRtp();
                /* goto @303; */
            case 4::
                this.loopTimer = this.loopTimer + 1;
                this.scanForBase();
                if (this.baseFound) {
                    return;
                }
                if (this.loopTimer >= 1300) {
                    this.resetAndRtp();
                }
            default:
                return;
        }
    }

    @EventHandler
    private void onMessage(ReceiveMessageEvent event) {
        String msg = event.getMessage().getString();
        try {
            String[] parts = msg.split(" ");
            int i = 0;
            while (i < parts.length) {
                if (parts[i].equals("chờ")) {
                    if (i + 1 < parts.length) {
                        int seconds = Integer.parseInt(parts[i + 1]);
                        this.serverCooldown = seconds * 20 + 20;
                        this.state = RTPFinderBase.State.WAIT_COOLDOWN;
                    }
                } else {
                    i++;
                }
            }
        }
        catch (Exception parts) {
            return;
        }
    }

    private void sendRtp() {
        this.state = RTPFinderBase.State.WAIT_GUI;
        this.rtpWaitTimer = 0;
        this.mc.field_1724.field_3944.method_45730("rtp");
    }

    private void resetAndRtp() {
        if (this.baseFound) {
            return;
        }
        this.waitTimer = 0;
        this.loopTimer = 0;
        this.mc.method_1562().method_45729("#stop");
        this.sendRtp();
    }

    private void stealBlock(class_1707 handler) {
        for (int i = 0; i < handler.method_7629().method_5439(); i++) {
            class_1799 stack = handler.method_7629().method_5438(i);
            if (stack.method_7960()) {
            } else {
                if (this.world.get() != RTPFinderBase.WorldType.Overworld || !stack.method_31574(class_1802.field_8270)) {
                    if (this.world.get() != RTPFinderBase.WorldType.Nether || !stack.method_31574(class_1802.field_8328)) {
                        if (this.world.get() != RTPFinderBase.WorldType.End) { /* goto @109; */ }
                    }
                }
                /* note: clearing non-empty stack before goto */
                /* goto L110; */
                L109: ;
                L110: ;
                boolean match = false;
                if (!match) { /* goto @163; */ }
                this.mc.field_1761.method_2906(handler.field_7763, i, 0, class_1713.field_7794, this.mc.field_1724);
                this.waitTimer = 0;
                this.loopTimer = 0;
                this.state = RTPFinderBase.State.WAIT_AFTER;
                /* goto @169; */
            }
        }
    }

    private void afterWait() {
        if (this.world.get() == RTPFinderBase.WorldType.Overworld) {
            if (((Boolean)this.baseFinder.get()).booleanValue()) {
                this.mc.method_1562().method_45729("#goto " + String.valueOf(this.depth.get()));
            }
        }
    }

    private void scanForBase() {
        int px = this.mc.field_1724.method_24515().method_10263() >> 4;
        int pz = this.mc.field_1724.method_24515().method_10260() >> 4;
        int radius = 6;
        for (int x = px - radius; x <= px + radius; x++) {
            for (int z = pz - radius; z <= pz + radius; z++) {
                if (!this.mc.field_1687.method_8393(x, z)) {
                } else {
                    class_2818 chunk = this.mc.field_1687.method_8497(x, z);
                    int containerCount = 0;
                    var var8 = chunk.method_12214().values().iterator();
                    while (var8.hasNext()) {
                        class_2586 be = (class_2586)var8.next();
                        class_2338 pos = be.method_11016();
                        class_2248 block = this.mc.field_1687.method_8320(pos).method_26204();
                        if (!((List)this.targetBlocks.get()).contains(block)) continue;
                        containerCount++;
                    }
                    if (containerCount >= ((Integer)this.containerLimit.get()).intValue()) {
                        this.foundBase();
                        return;
                    }
                }
            }
        }
    }

    private void foundBase() {
        if (this.baseFound) {
            return;
        }
        this.baseFound = true;
        int x = this.mc.field_1724.method_24515().method_10263();
        int y = this.mc.field_1724.method_24515().method_10264();
        int z = this.mc.field_1724.method_24515().method_10260();
        String server = this.mc.method_1558() != null ? this.mc.method_1558().field_3761 : "Unknown";
        String playerName = this.mc.field_1724.method_5477().getString();
        this.info("§a§lBase Found! X: %d Y: %d Z: %d", x, y, z);
        this.mc.field_1687.method_8396(this.mc.field_1724, this.mc.field_1724.method_24515(), class_3417.field_14627, class_3419.field_15250, ((Double)this.volume.get()).floatValue(), 1f);
        if (((Boolean)this.webhookEnabled.get()).booleanValue()) {
            if (!((String)this.webhookUrl.get()).isEmpty()) {
                this.sendWebhook(playerName, server, x, y, z);
            }
        }
        if (((Boolean)this.disconnectOnFound.get()).booleanValue()) {
            this.mc.execute(this::lambda$foundBase$2);
        }
        this.toggle();
    }

    private void sendWebhook(String player, String server, int x, int y, int z) {
        String json = String.format("{\n  \"embeds\": [{\n    \"title\": \"🏠 Base Found!\",\n    \"color\": 65280,\n    \"fields\": [\n      {\"name\": \"Player\", \"value\": \"%s\", \"inline\": true},\n      {\"name\": \"Server\", \"value\": \"%s\", \"inline\": true},\n      {\"name\": \"Coordinates\", \"value\": \"X: %d Y: %d Z: %d\", \"inline\": false}\n    ]\n  }]\n}\n", player, server, x, y, z);
        Thread.ofVirtual().start(this::lambda$sendWebhook$3 /* captured: json */);
    }
}
