/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2868;
import net.minecraft.class_476;

public class AutoJoin
extends Module {
    private final SettingGroup sg = this.settings.getDefaultGroup();
    private final Setting<Integer> targetSlot = this.sg.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("target-slot")).description("Slot")).defaultValue(22)).min(0).sliderMax(53).build());
    private int timer = 0;
    private int stage = 0;
    private int limeClickCount = 0;

    public AutoJoin() {
        super(AddonTemplate.Student, "Auto-Join", "Only for Student");
    }

    public void onActivate() {
        this.timer = 20;
        this.stage = 0;
        this.limeClickCount = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (this.timer > 0) {
            this.timer = this.timer - 1;
            return;
        }
        if (this.stage != 0) { /* goto L269; */ }
        int clockSlot = -1;
        int i = 0;
        while (i < 9) {
            if (this.mc.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_8557)) {
                clockSlot = i;
            } else {
                i++;
            }
        }
        if (clockSlot == -1) {
            class_1792[] tmp0 = new class_1792[1];
            tmp0[0] = class_1802.field_8557;
            result = InvUtils.find(tmp0);
            if (!result.found()) {
                return;
            }
            InvUtils.move().from(result.slot()).toHotbar(0);
            clockSlot = 0;
            this.timer = 2;
            return;
        }
        prev = this.mc.field_1724.method_31548().method_67532();
        this.mc.field_1724.method_31548().method_61496(clockSlot);
        this.mc.field_1724.field_3944.method_52787(new class_2868(clockSlot));
        this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
        this.mc.field_1724.method_6104(class_1268.field_5808);
        this.mc.field_1724.method_31548().method_61496(prev);
        this.mc.field_1724.field_3944.method_52787(new class_2868(prev));
        this.stage = 1;
        this.timer = 20;
        return;
        L269: ;
        if (this.stage != 1) { /* goto L472; */ }
        handler = this.mc.field_1755;
        if (handler instanceof class_476) {
            screen = (class_476)handler;
        } else {
            this.timer = 5;
            return;
        }
        handler = (class_1707)screen.method_17577();
        for (int i = 0; i < handler.field_7761.size(); i++) {
            if (!((class_1735)handler.field_7761.get(i)).method_7677().method_31574(class_1802.field_8581)) { /* goto L423; */ }
            this.mc.field_1761.method_2906(handler.field_7763, i, 0, class_1713.field_7790, this.mc.field_1724);
            this.limeClickCount = this.limeClickCount + 1;
            if (this.limeClickCount < 3) {
                this.timer = 20;
            } else {
                this.stage = 2;
                this.timer = 2;
                this.limeClickCount = 0;
            }
            return;
            L423: ;
        }
        this.limeClickCount = this.limeClickCount + 1;
        if (this.limeClickCount < 3) {
            this.timer = 20;
        } else {
            this.stage = 2;
            this.timer = 2;
            this.limeClickCount = 0;
        }
        return;
        L472: ;
        if (this.stage != 2) { /* goto L566; */ }
        handler = this.mc.field_1755;
        if (handler instanceof class_476) {
            screen = (class_476)handler;
        } else {
            return;
        }
        handler = (class_1707)screen.method_17577();
        this.mc.field_1761.method_2906(handler.field_7763, ((Integer)this.targetSlot.get()).intValue(), 0, class_1713.field_7790, this.mc.field_1724);
        this.stage = 0;
        this.timer = 100;
        this.limeClickCount = 0;
        L566: ;
    }
}
