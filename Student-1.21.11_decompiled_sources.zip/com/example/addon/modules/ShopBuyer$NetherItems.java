/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

public static enum ShopBuyer.NetherItems {
    public static final ShopBuyer.NetherItems BLAZE_ROD = new ShopBuyer.NetherItems("BLAZE_ROD", 0);
    public static final ShopBuyer.NetherItems NETHER_WART = new ShopBuyer.NetherItems("NETHER_WART", 1);
    public static final ShopBuyer.NetherItems GLOWSTONE_DUST = new ShopBuyer.NetherItems("GLOWSTONE_DUST", 2);
    public static final ShopBuyer.NetherItems MAGMA_CREAM = new ShopBuyer.NetherItems("MAGMA_CREAM", 3);
    public static final ShopBuyer.NetherItems GHAST_TEAR = new ShopBuyer.NetherItems("GHAST_TEAR", 4);
    public static final ShopBuyer.NetherItems QUARTZ = new ShopBuyer.NetherItems("QUARTZ", 5);
    public static final ShopBuyer.NetherItems SOUL_SAND = new ShopBuyer.NetherItems("SOUL_SAND", 6);
    public static final ShopBuyer.NetherItems MAGMA_BLOCK = new ShopBuyer.NetherItems("MAGMA_BLOCK", 7);
    public static final ShopBuyer.NetherItems CRYING_OBSIDIAN = new ShopBuyer.NetherItems("CRYING_OBSIDIAN", 8);
    private static final /* synthetic */ ShopBuyer.NetherItems[] $VALUES;

    public static ShopBuyer.NetherItems[] values() {
        return (ShopBuyer.NetherItems[])$VALUES.clone();
    }

    public static ShopBuyer.NetherItems valueOf(String name) {
        return (ShopBuyer.NetherItems)Enum.valueOf(ShopBuyer.NetherItems.class, name);
    }

    private ShopBuyer.NetherItems() {
        super(var1, var2);
    }

    static {
        $VALUES = ShopBuyer.NetherItems.$values();
    }
}
