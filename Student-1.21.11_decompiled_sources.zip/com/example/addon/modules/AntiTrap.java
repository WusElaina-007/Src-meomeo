/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.events.entity.EntityAddedEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1299;

public class AntiTrap
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<Boolean> removeExisting = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("remove-existing")).description("Remove existing trap entities when enabled.")).defaultValue(true)).build());
    private final Setting<Boolean> preventSpawn = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("prevent-spawn")).description("Prevent new trap entities from spawning.")).defaultValue(true)).build());
    private final Setting<Boolean> armorStands = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("armor-stands")).description("Target armor stands.")).defaultValue(true)).build());
    private final Setting<Boolean> chestMinecarts = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("chest-minecarts")).description("Target chest minecarts.")).defaultValue(true)).build());

    public AntiTrap() {
        super(AddonTemplate.Student_esp, "Antitrap", "");
    }

    public void onActivate() {
        if (((Boolean)this.removeExisting.get()).booleanValue()) {
            this.removeTrapEntities();
        }
    }

    @EventHandler
    private void onEntityAdded(EntityAddedEvent event) {
        if (!((Boolean)this.preventSpawn.get()).booleanValue()) {
            return;
        }
        class_1297 entity = event.entity;
        if (this.isTrapEntity(entity)) {
            entity.method_31472();
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1687 == null) {
            return;
        }
        if (this.mc.field_1724.field_6012 % 20 != 0) { /* goto L127; */ }
        List<class_1297> toRemove = new ArrayList();
        var var3 = this.mc.field_1687.method_18112().iterator();
        while (var3.hasNext()) {
            class_1297 entity = (class_1297)var3.next();
            if (!this.isTrapEntity(entity)) continue;
            toRemove.add(entity);
        }
        var3 = toRemove.iterator();
        while (var3.hasNext()) {
            entity = (class_1297)var3.next();
            entity.method_31472();
        }
    }

    private void removeTrapEntities() {
        if (this.mc.field_1687 == null) {
            return;
        }
        List<class_1297> trapEntities = new ArrayList();
        var var2 = this.mc.field_1687.method_18112().iterator();
        while (var2.hasNext()) {
            class_1297 entity = (class_1297)var2.next();
            if (!this.isTrapEntity(entity)) continue;
            trapEntities.add(entity);
        }
        var2 = trapEntities.iterator();
        while (var2.hasNext()) {
            entity = (class_1297)var2.next();
            entity.method_31472();
        }
        if (!trapEntities.isEmpty()) {
            this.info("Removed %d trap entities", trapEntities.size());
        }
    }

    private boolean isTrapEntity(class_1297 entity) {
        if (entity == null) {
            return false;
        }
        class_1299<?> type = entity.method_5864();
        if (((Boolean)this.armorStands.get()).booleanValue() && type == class_1299.field_6131) {
            return true;
        }
        if (((Boolean)this.chestMinecarts.get()).booleanValue() && type == class_1299.field_6126) {
            return true;
        }
        return false;
    }
}
