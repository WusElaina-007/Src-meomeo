/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_2868;
import net.minecraft.class_2885;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class TNTMinecartMacro
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<Double> range = this.sgGeneral.add(((DoubleSetting.Builder)new DoubleSetting.Builder().name("range")).defaultValue(10).min(1).sliderMax(30).build());
    private boolean wasBowCharging = false;
    private int chargeTime = 0;
    private class_2338 shootTargetPos = null;
    private boolean isPlacing = false;
    private int placeDelay = 0;
    private class_2338 targetPos = null;
    private int savedSlot;

    public TNTMinecartMacro() {
        super(AddonTemplate.Student_pvp, "tnt-minecart-macro", "Auto places rail and TNT minecart where arrow will land");
    }

    public void onActivate() {
        this.isPlacing = false;
        this.placeDelay = 0;
        this.targetPos = null;
        this.wasBowCharging = false;
        this.chargeTime = 0;
        this.shootTargetPos = null;
    }

    public void onDeactivate() {
        this.isPlacing = false;
        this.placeDelay = 0;
        this.wasBowCharging = false;
        this.chargeTime = 0;
        this.shootTargetPos = null;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        this.tickShootDetect();
        if (!this.isPlacing) { /* goto L62; */ }
        if (this.placeDelay < 2) {
            this.placeDelay = this.placeDelay + 1;
        } else {
            this.tickAutoPlace();
            this.placeDelay = 0;
        }
    }

    private void tickShootDetect() {
        if (!this.isHoldingBow()) {
            this.wasBowCharging = false;
            this.chargeTime = 0;
            return;
        }
        boolean isCharging = this.mc.field_1690.field_1904.method_1434();
        if (isCharging) {
            this.wasBowCharging = true;
            this.chargeTime = this.chargeTime + 1;
        }
        if (this.wasBowCharging) {
            if (!isCharging) {
                if (!this.isPlacing) {
                    if (this.mc.field_1724.method_6014() == 0) {
                        this.shootTargetPos = this.simulateArrowLanding(this.chargeTime);
                        if (this.shootTargetPos != null) {
                            if (this.find(class_1802.field_8069) != -1) {
                                if (this.find(class_1802.field_8129) != -1 || this.find(class_1802.field_8848) != -1) {
                                    this.targetPos = this.shootTargetPos;
                                    this.savedSlot = this.mc.field_1724.method_31548().method_67532();
                                    this.isPlacing = true;
                                }
                            }
                        }
                        this.wasBowCharging = false;
                        this.chargeTime = 0;
                        this.shootTargetPos = null;
                    }
                }
            }
        }
    }

    private void tickAutoPlace() {
        if (this.targetPos == null) {
            this.restoreAndIdle();
            return;
        }
        int railSlot = this.find(class_1802.field_8848) != -1 ? this.find(class_1802.field_8848) : this.find(class_1802.field_8129);
        int tntSlot = this.find(class_1802.field_8069);
        if (railSlot == -1 || tntSlot == -1) {
            this.restoreAndIdle();
            return;
        }
        class_2338 below = this.targetPos.method_10074();
        if (this.mc.field_1687.method_8320(below).method_26215()) {
            this.restoreAndIdle();
            return;
        }
        float[] angles = this.calcAngles(class_243.method_24953(below).method_1031(0, 0.5, 0));
        float yaw = angles[0];
        float pitch = angles[1];
        this.mc.field_1724.field_3944.method_52787(new class_2828.class_2831(yaw, pitch, this.mc.field_1724.method_24828(), this.mc.field_1724.field_5976));
        this.mc.field_1724.method_31548().method_61496(railSlot);
        this.mc.field_1724.field_3944.method_52787(new class_2868(railSlot));
        class_3965 railHit = new class_3965(class_243.method_24953(below).method_1031(0, 0.5, 0), class_2350.field_11036, below, false);
        this.mc.field_1724.field_3944.method_52787(new class_2885(class_1268.field_5808, railHit, 0));
        this.mc.field_1724.method_6104(class_1268.field_5808);
        this.mc.field_1724.method_31548().method_61496(tntSlot);
        this.mc.field_1724.field_3944.method_52787(new class_2868(tntSlot));
        class_3965 tntHit = new class_3965(class_243.method_24953(this.targetPos).method_1031(0, 0.5, 0), class_2350.field_11036, this.targetPos, false);
        this.mc.field_1724.field_3944.method_52787(new class_2885(class_1268.field_5808, tntHit, 0));
        this.mc.field_1724.method_6104(class_1268.field_5808);
        this.mc.field_1724.field_3944.method_52787(new class_2828.class_2831(this.mc.field_1724.method_36454(), this.mc.field_1724.method_36455(), this.mc.field_1724.method_24828(), this.mc.field_1724.field_5976));
        this.restoreAndIdle();
    }

    private float[] calcAngles(class_243 target) {
        double dx = target.field_1352 - this.mc.field_1724.method_23317();
        double dy = target.field_1351 - this.mc.field_1724.method_23320();
        double dz = target.field_1350 - this.mc.field_1724.method_23321();
        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float)Math.toDegrees(class_3532.method_15349(dz, dx)) - 90f;
        float pitch = (float)-Math.toDegrees(class_3532.method_15349(dy, dist));
        float[] tmp0 = new float[2];
        tmp0[0] = yaw;
        tmp0[1] = pitch;
        return tmp0;
    }

    private class_2338 simulateArrowLanding(int chargeTime) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return null;
        }
        float power = (float)chargeTime / 20f;
        if (power > 1f) {
            power = 1f;
        }
        double speed = (double)((power * power + power * 2f) / 3f * 3f);
        float yaw = this.mc.field_1724.method_36454();
        float pitch = this.mc.field_1724.method_36455();
        double radYaw = Math.toRadians((double)yaw);
        double radPitch = Math.toRadians((double)pitch);
        double vx = -Math.sin(radYaw) * Math.cos(radPitch) * speed;
        double vy = -Math.sin(radPitch) * speed;
        double vz = Math.cos(radYaw) * Math.cos(radPitch) * speed;
        double x = this.mc.field_1724.method_23317();
        double y = this.mc.field_1724.method_23320() - 0.1;
        double z = this.mc.field_1724.method_23321();
        for (int tick = 0; tick < 500; tick++) {
            for (int sub = 0; sub < 4; sub++) {
                double nx = x + vx / 4;
                double ny = y + vy / 4;
                double nz = z + vz / 4;
                class_243 from = new class_243(x, y, z);
                class_243 to = new class_243(nx, ny, nz);
                class_3965 hit = this.mc.field_1687.method_17742(new class_3959(from, to, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, this.mc.field_1724));
                if (hit.method_17783() == class_239.class_240.field_1332) {
                    class_2338 landed = hit.method_17777();
                    if (!landed.method_10264() <= this.mc.field_1687.method_31607()) continue;
                    return null;
                    return landed.method_10084();
                }
                x = nx;
                y = ny;
                z = nz;
                if (!y < (double)this.mc.field_1687.method_31607()) continue;
                return null;
            }
            vy = vy - 0.05;
            vx = vx * 0.99;
            vy = vy * 0.99;
            vz = vz * 0.99;
        }
        return null;
    }

    private void restoreAndIdle() {
        if (this.mc.field_1724 != null) {
            this.mc.field_1724.method_31548().method_61496(this.savedSlot);
            this.mc.field_1724.field_3944.method_52787(new class_2868(this.savedSlot));
        }
        this.isPlacing = false;
        this.targetPos = null;
    }

    private boolean isHoldingBow() {
        return this.mc.field_1724.method_6047().method_7909() == class_1802.field_8102;
    }

    private int find(class_1792 item) {
        for (int i = 0; i < 9; i++) {
            if (this.mc.field_1724.method_31548().method_5438(i).method_7909() != item) continue;
            return i;
        }
        return -1;
    }
}
