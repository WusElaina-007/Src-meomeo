/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

public static enum ChunkFinder.HoleMode {
    public static final ChunkFinder.HoleMode Without_Holes = new ChunkFinder.HoleMode("Without_Holes", 0);
    public static final ChunkFinder.HoleMode Both = new ChunkFinder.HoleMode("Both", 1);
    private static final /* synthetic */ ChunkFinder.HoleMode[] $VALUES;

    public static ChunkFinder.HoleMode[] values() {
        return (ChunkFinder.HoleMode[])$VALUES.clone();
    }

    public static ChunkFinder.HoleMode valueOf(String name) {
        return (ChunkFinder.HoleMode)Enum.valueOf(ChunkFinder.HoleMode.class, name);
    }

    private ChunkFinder.HoleMode() {
        super(var1, var2);
    }

    static {
        $VALUES = ChunkFinder.HoleMode.$values();
    }
}
