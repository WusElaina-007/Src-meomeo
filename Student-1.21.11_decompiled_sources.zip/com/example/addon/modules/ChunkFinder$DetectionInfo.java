/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import net.minecraft.class_2338;

private static final record ChunkFinder.DetectionInfo {
    private final class_2338 position;
    private final long timestamp;

    private ChunkFinder.DetectionInfo(class_2338 position, long timestamp) {
        this.position = position;
        this.timestamp = timestamp;
    }

    public final String toString() {
        return /* lambda: toString */ this;
    }

    public final int hashCode() {
        return /* lambda: hashCode */ this;
    }

    public final boolean equals(Object o) {
        return /* lambda: equals */ this, o;
    }

    public class_2338 position() {
        return this.position;
    }

    public long timestamp() {
        return this.timestamp;
    }
}
