/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.util.List;
import java.util.Set;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class MaceElytraMacro
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<Double> range = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("range")).description("Range to detect entities.")).defaultValue(4).min(1).sliderMax(10).build());
    private final Setting<Integer> reEquipDelay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("re-equip-delay")).description("Ticks to wait before re-equipping elytra after attack.")).defaultValue(5)).min(0).sliderMax(40).build());
    private final Setting<List<class_1792>> attackItems;
    private final Setting<Set<class_1299<?>>> entities;
    private int state;
    private int timer;
    private class_1297 attackTarget;

    public MaceElytraMacro() {
        super(AddonTemplate.Student_pvp, "Mace-Elytra-Macro", "Support pvp mace with elytra");
        class_1792[] tmp0 = new class_1792[1];
        tmp0[0] = class_1802.field_49814;
        this.attackItems = this.sgGeneral.add(((ItemListSetting.Builder)((ItemListSetting.Builder)new ItemListSetting.Builder().name("attack-items")).description("Items to use for attacking (uses first match found in hotbar).")).defaultValue(tmp0).build());
        class_1299[] tmp1 = new class_1299[1];
        tmp1[0] = class_1299.field_6097;
        this.entities = this.sgGeneral.add(((EntityTypeListSetting.Builder)((EntityTypeListSetting.Builder)new EntityTypeListSetting.Builder().name("entities")).description("Entities to target.")).defaultValue(tmp1).build());
        this.state = 0;
        this.timer = 0;
        this.attackTarget = null;
    }

    public void onActivate() {
        this.state = 0;
        this.timer = 0;
        this.attackTarget = null;
    }

    public void onDeactivate() {
        this.state = 0;
        this.timer = 0;
        this.attackTarget = null;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null || this.mc.field_1761 == null) {
            return;
        }
        if (this.timer > 0) {
            this.timer = this.timer - 1;
            return;
        }
        switch (this.state) {
            case 0::
                if (!this.mc.field_1724.method_6128()) {
                    return;
                }
                class_1297 target = this.findTarget();
                if (target == null) {
                    return;
                }
                this.attackTarget = target;
                int chestplateSlot = this.findChestplateInInventory();
                if (chestplateSlot == -1) {
                    return;
                }
                class_1723 handler = this.mc.field_1724.field_7498;
                this.mc.field_1761.method_2906(handler.field_7763, chestplateSlot, 0, class_1713.field_7790, this.mc.field_1724);
                this.mc.field_1761.method_2906(handler.field_7763, 6, 0, class_1713.field_7790, this.mc.field_1724);
                this.mc.field_1761.method_2906(handler.field_7763, chestplateSlot, 0, class_1713.field_7790, this.mc.field_1724);
                this.state = 1;
                this.timer = 2;
                /* goto @437; */
            case 1::
                attackSlot = this.findAttackItemInHotbar();
                if (attackSlot != -1) {
                    this.mc.field_1724.method_31548().method_61496(attackSlot);
                }
                this.mc.field_1761.method_2918(this.mc.field_1724, this.attackTarget);
                if (this.attackTarget != null && !this.attackTarget.method_31481()) {
                    this.mc.field_1724.method_6104(class_1268.field_5808);
                }
                this.state = 2;
                this.timer = ((Integer)this.reEquipDelay.get()).intValue();
                /* goto @437; */
            case 2::
                elytraSlot = this.findElytraInInventory();
                if (elytraSlot != -1) {
                    handler = this.mc.field_1724.field_7498;
                    this.mc.field_1761.method_2906(handler.field_7763, elytraSlot, 0, class_1713.field_7790, this.mc.field_1724);
                    this.mc.field_1761.method_2906(handler.field_7763, 6, 0, class_1713.field_7790, this.mc.field_1724);
                    this.mc.field_1761.method_2906(handler.field_7763, elytraSlot, 0, class_1713.field_7790, this.mc.field_1724);
                }
                this.attackTarget = null;
                this.state = 0;
            default:
                return;
        }
    }

    private class_1297 findTarget() {
        double r = ((Double)this.range.get()).doubleValue();
        class_1297 closest = null;
        double closestDist = 179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
        var var6 = this.mc.field_1687.method_18112().iterator();
        while (var6.hasNext()) {
            class_1297 e = (class_1297)var6.next();
            while (e == this.mc.field_1724) {
            }
            if (!e instanceof class_1309) continue;
            class_1309 living = (class_1309)e;
            while (living.method_29504()) {
            }
            while (!((Set)this.entities.get()).contains(e.method_5864())) {
            }
            double dist = (double)this.mc.field_1724.method_5739(e);
            if (dist <= r) {
                if (dist < closestDist) {
                    closestDist = dist;
                    closest = e;
                }
            }
        }
        return closest;
    }

    private int findAttackItemInHotbar() {
        var var1 = ((List)this.attackItems.get()).iterator();
        while (var1.hasNext()) {
            class_1792 item = (class_1792)var1.next();
            for (int i = 0; i < 9; i++) {
                if (this.mc.field_1724.method_31548().method_5438(i).method_7909() != item) continue;
                return i;
            }
        }
        return -1;
    }

    private int findChestplateInInventory() {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
            if (!this.isChestplate(stack.method_7909())) continue;
            return i + 36;
        }
        for (i = 9; i < 36; i++) {
            stack = this.mc.field_1724.method_31548().method_5438(i);
            if (!this.isChestplate(stack.method_7909())) continue;
            return i;
        }
        return -1;
    }

    private int findElytraInInventory() {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7909() != class_1802.field_8833) continue;
            return i + 36;
        }
        for (i = 9; i < 36; i++) {
            stack = this.mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7909() != class_1802.field_8833) continue;
            return i;
        }
        return -1;
    }

    private boolean isChestplate(class_1792 item) {
        return item == class_1802.field_22028 || item == class_1802.field_8058 || item == class_1802.field_8523 || item == class_1802.field_8678 || item == class_1802.field_8873 || item == class_1802.field_8577;
    }
}
