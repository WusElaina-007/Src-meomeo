/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.events.entity.player.AttackEntityEvent;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;

public class ItemSwap
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<Integer> swapSlot = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("swap-slot")).description("Slot to swap to when attacking.")).defaultValue(1)).min(0).max(8).build());

    public ItemSwap() {
        super(AddonTemplate.Student_pvp, "item-swap", "Swaps to a slot when attacking, works with Kill Aura.");
    }

    @EventHandler
    private void onAttackEntity(AttackEntityEvent event) {
        if (this.mc.field_1724 == null) {
            return;
        }
        int oldSlot = this.mc.field_1724.method_31548().method_67532();
        int targetSlot = ((Integer)this.swapSlot.get()).intValue();
        if (oldSlot == targetSlot) {
            return;
        }
        this.mc.field_1724.method_31548().method_61496(targetSlot);
        this.mc.field_1761.method_2918(this.mc.field_1724, event.entity);
        this.mc.field_1724.method_6104(class_1268.field_5808);
        this.mc.field_1724.method_31548().method_61496(oldSlot);
    }
}
