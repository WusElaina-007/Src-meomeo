/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

public static enum AutoOrder.Mode {
    public static final AutoOrder.Mode SEARCH = new AutoOrder.Mode("SEARCH", 0);
    public static final AutoOrder.Mode HIGH_VALUE = new AutoOrder.Mode("HIGH_VALUE", 1);
    private static final /* synthetic */ AutoOrder.Mode[] $VALUES;

    public static AutoOrder.Mode[] values() {
        return (AutoOrder.Mode[])$VALUES.clone();
    }

    public static AutoOrder.Mode valueOf(String name) {
        return (AutoOrder.Mode)Enum.valueOf(AutoOrder.Mode.class, name);
    }

    private AutoOrder.Mode() {
        super(var1, var2);
    }

    static {
        $VALUES = AutoOrder.Mode.$values();
    }
}
