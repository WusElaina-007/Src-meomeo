/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import com.example.addon.VersionUtil;
import com.example.addon.utils.glazed.BlockUtil;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1713;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1819;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2868;
import net.minecraft.class_3965;
import net.minecraft.class_9334;
import org.lwjgl.glfw.GLFW;

public class AnchorMacro
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final SettingGroup sgShield = this.settings.createGroup("Shield Block");
    private final Setting<Double> radius = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("radius")).description("Radius tìm anchor xung quanh player.")).defaultValue(4).min(1).max(10).sliderMax(10).build());
    private final Setting<Double> switchDelay = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("switch-delay")).description("Delay (ticks) trước khi switch item.")).defaultValue(0).min(0).max(20).sliderMax(20).build());
    private final Setting<Double> glowstoneDelay = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("glowstone-delay")).description("Delay (ticks) trước khi đặt glowstone.")).defaultValue(0).min(0).max(20).sliderMax(20).build());
    private final Setting<Boolean> autoExplode = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("auto-explode")).description("Tự động kích nổ anchor sau khi charge xong.")).defaultValue(false)).build());
    private final Setting<Double> explodeDelay;
    private final Setting<Boolean> placeAnchor;
    private final Setting<Double> placeAnchorDelay;
    private final Setting<Integer> totemSlot;
    private final Setting<Boolean> autoFillTotem;
    private final Setting<Boolean> autoSwingHand;
    private final Setting<Boolean> placeShield;
    private final Setting<Double> shieldDelay;
    private final Setting<List<class_1792>> shieldBlocks;
    private AnchorMacro.Phase phase;
    private int delay;
    private int chargedWait;
    private class_2338 savedAnchorPos;

    public AnchorMacro() {
        super(AddonTemplate.Student_pvp, "AnchorMacro", "Tự động scan, charge, nổ và đặt lại respawn anchor. Giữ RMB để kích hoạt.");
        Objects.requireNonNull(this.autoExplode);
        this.explodeDelay = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("explode-delay")).description("Delay (ticks) trước khi kích nổ anchor.")).defaultValue(0).min(0).max(20).sliderMax(20).visible(this.autoExplode::get)).build());
        Objects.requireNonNull(this.autoExplode);
        this.placeAnchor = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("place-anchor")).description("Tự động đặt lại anchor sau khi nổ và loop tiếp.")).defaultValue(false)).visible(this.autoExplode::get)).build());
        this.placeAnchorDelay = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("place-anchor-delay")).description("Delay (ticks) chờ sau khi nổ trước khi đặt lại anchor.")).defaultValue(2).min(0).max(20).sliderMax(20).visible(this::lambda$new$0)).build());
        this.totemSlot = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("totem-slot")).description("Hotbar slot chứa totem (1-9).")).defaultValue(1)).min(1).max(9).build());
        this.autoFillTotem = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("auto-fill-totem")).description("Tự động chuyển totem vào slot chỉ định nếu trống.")).defaultValue(true)).build());
        this.autoSwingHand = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("auto-swing-hand")).defaultValue(true)).build());
        this.placeShield = this.sgShield.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("place-shield")).description("Đặt block chắn giữa player và anchor trước khi charge.")).defaultValue(false)).build());
        Objects.requireNonNull(this.placeShield);
        this.shieldDelay = this.sgShield.add(((DoubleSetting.Builder)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("shield-delay")).description("Delay (ticks) trước khi đặt shield block.")).defaultValue(0).min(0).max(20).sliderMax(20).visible(this.placeShield::get)).build());
        class_1792[] tmp0 = new class_1792[1];
        tmp0[0] = class_1802.field_8281;
        Objects.requireNonNull(this.placeShield);
        this.shieldBlocks = this.sgShield.add(((ItemListSetting.Builder)((ItemListSetting.Builder)((ItemListSetting.Builder)new ItemListSetting.Builder().name("shield-blocks")).description("Danh sách block dùng làm shield. Tự tìm cái nào có trong hotbar.")).defaultValue(tmp0).visible(this.placeShield::get)).build());
        this.phase = AnchorMacro.Phase.IDLE;
        this.delay = 0;
        this.chargedWait = 0;
        this.savedAnchorPos = null;
    }

    public void onActivate() {
        this.reset();
    }

    public void onDeactivate() {
        this.reset();
    }

    private void reset() {
        this.phase = AnchorMacro.Phase.IDLE;
        this.delay = 0;
        this.chargedWait = 0;
        this.savedAnchorPos = null;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1755 != null) {
            return;
        }
        if (this.isShieldOrFoodActive()) {
            return;
        }
        boolean isRMB = GLFW.glfwGetMouseButton(this.mc.method_22683().method_4490(), 1) == 1;
        if (!isRMB) {
            this.reset();
            return;
        }
        this.mc.field_1690.field_1904.method_23481(false);
        if (this.phase == AnchorMacro.Phase.PLACE_ANCHOR && this.savedAnchorPos != null) {
            this.tick(this.makeHitResult(this.savedAnchorPos));
            return;
        }
        if (this.phase == AnchorMacro.Phase.IDLE || this.savedAnchorPos == null) {
            class_2338 found = this.findNearestAnchor();
            if (found == null) {
                return;
            }
            this.savedAnchorPos = found;
        }
        this.mc.field_1690.field_1904.method_23481(false);
        this.tick(this.makeHitResult(this.savedAnchorPos));
    }

    private class_2338 findNearestAnchor() {
        class_243 playerPos = this.mc.field_1724.method_73189();
        int r = (int)Math.ceil(((Double)this.radius.get()).doubleValue());
        class_2338 origin = this.mc.field_1724.method_24515();
        List<class_2338> candidates = new ArrayList();
        for (int x = -r; x <= r; x++) {
            for (int y = -r; y <= r; y++) {
                for (int z = -r; z <= r; z++) {
                    class_2338 pos = origin.method_10069(x, y, z);
                    if (this.mc.field_1687.method_8320(pos).method_26204() == class_2246.field_23152) {
                        if (!BlockUtil.isRespawnAnchorUncharged(pos) || BlockUtil.isRespawnAnchorCharged(pos)) continue;
                        candidates.add(pos);
                    }
                }
            }
        }
        if (candidates.isEmpty()) {
            return null;
        }
        return (class_2338)candidates.stream().sorted(Comparator.comparingInt(AnchorMacro::lambda$findNearestAnchor$1).thenComparingDouble(AnchorMacro::lambda$findNearestAnchor$2 /* captured: playerPos */)).findFirst().orElse(null);
    }

    private int findAnchorItemSlot() {
        for (int slot = 0; slot < 9; slot++) {
            if (!this.mc.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_23141)) continue;
            return slot;
        }
        return -1;
    }

    private int findShieldBlockSlot() {
        List<class_1792> allowed = (List)this.shieldBlocks.get();
        for (int slot = 0; slot < 9; slot++) {
            class_1792 item = this.mc.field_1724.method_31548().method_5438(slot).method_7909();
            if (!allowed.contains(item) && item instanceof class_1747) continue;
            return slot;
        }
        return -1;
    }

    private void tick(class_3965 hit) {
        switch (this.phase.ordinal()) {
            case 0::
                boolean uncharged = BlockUtil.isRespawnAnchorUncharged(hit.method_17777());
                boolean charged = BlockUtil.isRespawnAnchorCharged(hit.method_17777());
                if (!uncharged && !charged) {
                    return;
                }
                this.phase = this.needsFill() ? AnchorMacro.Phase.FILL_TOTEM : charged ? AnchorMacro.Phase.SWITCH_TOTEM : AnchorMacro.Phase.PLACE_SHIELD;
                this.tick(hit);
                /* goto @1191; */
            case 1::
                if (this.needsFill()) { /* goto L156; */ }
                this.delay = 0;
                this.phase = BlockUtil.isRespawnAnchorCharged(hit.method_17777()) ? AnchorMacro.Phase.SWITCH_TOTEM : AnchorMacro.Phase.PLACE_SHIELD;
                this.tick(hit);
                return;
                class_1792[] tmp0 = new class_1792[1];
                tmp0[0] = class_1802.field_8288;
                totem = InvUtils.find(tmp0);
                if (totem.found()) { /* goto L206; */ }
                this.delay = 0;
                this.phase = BlockUtil.isRespawnAnchorCharged(hit.method_17777()) ? AnchorMacro.Phase.SWITCH_TOTEM : AnchorMacro.Phase.PLACE_SHIELD;
                return;
                invSlot = totem.slot() < 9 ? totem.slot() + 36 : totem.slot();
                this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, invSlot, ((Integer)this.totemSlot.get()).intValue() - 1, class_1713.field_7791, this.mc.field_1724);
                /* goto @1191; */
            case 2::
                if (!((Boolean)this.placeShield.get()).booleanValue()) {
                    this.delay = 0;
                    this.phase = AnchorMacro.Phase.SWITCH_GLOW;
                    this.tick(hit);
                    return;
                }
                this.delay = this.delay + 1;
                if ((long)this.delay < Math.round(((Double)this.shieldDelay.get()).doubleValue())) {
                    return;
                }
                this.delay = 0;
                this.doPlaceShield(hit);
                this.phase = AnchorMacro.Phase.SWITCH_GLOW;
                if (Math.round(((Double)this.shieldDelay.get()).doubleValue()) > 0L) {
                    return;
                }
                this.tick(hit);
                /* goto @1191; */
            case 3::
                if (!this.mc.field_1724.method_6047().method_31574(class_1802.field_8801)) {
                    this.delay = this.delay + 1;
                    if ((long)this.delay < Math.round(((Double)this.switchDelay.get()).doubleValue())) {
                        return;
                    }
                    this.delay = 0;
                    class_1792[] tmp1 = new class_1792[1];
                    tmp1[0] = class_1802.field_8801;
                    glow = InvUtils.findInHotbar(tmp1);
                    if (!glow.found()) {
                        this.reset();
                        return;
                    }
                    this.sendSlot(glow.slot());
                    if (Math.round(((Double)this.switchDelay.get()).doubleValue()) > 0L) {
                        this.phase = AnchorMacro.Phase.PLACE_GLOW;
                        return;
                    }
                }
                this.delay = 0;
                this.phase = AnchorMacro.Phase.PLACE_GLOW;
                this.tick(hit);
                /* goto @1191; */
            case 4::
                this.delay = this.delay + 1;
                if ((long)this.delay < Math.round(((Double)this.glowstoneDelay.get()).doubleValue())) {
                    return;
                }
                this.delay = 0;
                BlockUtil.interactWithBlock(hit, true);
                if (((Boolean)this.autoSwingHand.get()).booleanValue()) {
                    this.mc.field_1724.method_6104(class_1268.field_5808);
                }
                this.chargedWait = 0;
                this.phase = AnchorMacro.Phase.SWITCH_TOTEM;
                /* goto @1191; */
            case 5::
                if (!BlockUtil.isRespawnAnchorCharged(hit.method_17777())) {
                    this.chargedWait = this.chargedWait + 1;
                    if (this.chargedWait + 1 > 10) {
                        this.chargedWait = 0;
                        this.reset();
                    }
                    return;
                }
                this.chargedWait = 0;
                if (this.needsFill()) {
                    class_1792[] tmp2 = new class_1792[1];
                    tmp2[0] = class_1802.field_8288;
                    if (InvUtils.find(tmp2).found()) {
                        this.phase = AnchorMacro.Phase.FILL_TOTEM;
                        this.tick(hit);
                        return;
                    }
                }
                target = ((Integer)this.totemSlot.get()).intValue() - 1;
                if (VersionUtil.getSelectedSlot(this.mc.field_1724) != target) {
                    this.delay = this.delay + 1;
                    if ((long)this.delay < Math.round(((Double)this.switchDelay.get()).doubleValue())) {
                        return;
                    }
                    this.delay = 0;
                    this.sendSlot(target);
                    if (Math.round(((Double)this.switchDelay.get()).doubleValue()) > 0L) {
                        this.phase = AnchorMacro.Phase.EXPLODE;
                        return;
                    }
                }
                this.delay = 0;
                if (((Boolean)this.autoExplode.get()).booleanValue()) {
                    this.phase = AnchorMacro.Phase.EXPLODE;
                    this.tick(hit);
                } else {
                    this.reset();
                }
                /* goto @1191; */
            case 6::
                if (!BlockUtil.isRespawnAnchorCharged(hit.method_17777())) {
                    this.reset();
                    return;
                }
                this.delay = this.delay + 1;
                if ((long)this.delay < Math.round(((Double)this.explodeDelay.get()).doubleValue())) {
                    return;
                }
                this.delay = 0;
                BlockUtil.interactWithBlock(hit, true);
                if (((Boolean)this.autoSwingHand.get()).booleanValue()) {
                    this.mc.field_1724.method_6104(class_1268.field_5808);
                }
                this.delay = 0;
                this.chargedWait = 0;
                if (((Boolean)this.placeAnchor.get()).booleanValue()) {
                    this.phase = AnchorMacro.Phase.PLACE_ANCHOR;
                } else {
                    this.savedAnchorPos = null;
                    this.phase = AnchorMacro.Phase.IDLE;
                    /* goto @1191; */
                }
            case 7::
                if (this.mc.field_1687.method_8320(hit.method_17777()).method_26204() == class_2246.field_23152) {
                    this.chargedWait = this.chargedWait + 1;
                    if (this.chargedWait + 1 > 20) {
                        this.chargedWait = 0;
                        this.reset();
                    }
                    return;
                }
                this.chargedWait = 0;
                this.delay = this.delay + 1;
                if ((long)this.delay < Math.round(((Double)this.placeAnchorDelay.get()).doubleValue())) {
                    return;
                }
                this.delay = 0;
                anchorSlot = this.findAnchorItemSlot();
                if (anchorSlot == -1) {
                    this.reset();
                    return;
                }
                prevSlot = VersionUtil.getSelectedSlot(this.mc.field_1724);
                this.sendSlot(anchorSlot);
                BlockUtil.interactWithBlock(hit, true);
                if (((Boolean)this.autoSwingHand.get()).booleanValue()) {
                    this.mc.field_1724.method_6104(class_1268.field_5808);
                }
                this.sendSlot(prevSlot);
                this.delay = 0;
                this.chargedWait = 0;
                this.phase = AnchorMacro.Phase.IDLE;
                if (Math.round(((Double)this.placeAnchorDelay.get()).doubleValue()) == 0L) {
                    this.tick(hit);
                }
            default:
                return;
        }
    }

    private void doPlaceShield(class_3965 anchorHit) {
        List<class_2338> shieldPositions = this.getShieldPositions(anchorHit.method_17777());
        int shieldSlot = this.findShieldBlockSlot();
        if (shieldSlot == -1) {
            return;
        }
        int prevSlot = VersionUtil.getSelectedSlot(this.mc.field_1724);
        this.sendSlot(shieldSlot);
        class_2350[] tmp0 = new class_2350[6];
        tmp0[0] = class_2350.field_11033;
        tmp0[1] = class_2350.field_11043;
        tmp0[2] = class_2350.field_11035;
        tmp0[3] = class_2350.field_11034;
        tmp0[4] = class_2350.field_11039;
        tmp0[5] = class_2350.field_11036;
        class_2350[] priority = tmp0;
        var var6 = shieldPositions.iterator();
        while (var6.hasNext()) {
            class_2338 shieldPos = (class_2338)var6.next();
            while (!this.mc.field_1687.method_8320(shieldPos).method_45474()) {
            }
            class_2350 placeDir = null;
            class_2338 neighborPos = null;
            class_2350 hitFace = priority;
            class_243 hitVec = hitFace.length;
            class_3965 shieldHit = 0;
            while (shieldHit < hitVec) {
                class_2350 dir = hitFace[shieldHit];
                class_2338 candidate = shieldPos.method_10093(dir);
                if (!this.mc.field_1687.method_8320(candidate).method_45474()) {
                    placeDir = dir;
                    neighborPos = candidate;
                } else {
                    shieldHit++;
                }
            }
            while (placeDir == null) {
            }
            hitFace = placeDir.method_10153();
            hitVec = class_243.method_24953(neighborPos).method_1019(class_243.method_24954(hitFace.method_62675()).method_1021(0.5));
            shieldHit = new class_3965(hitVec, hitFace, neighborPos, false);
            BlockUtil.interactWithBlock(shieldHit, ((Boolean)this.autoSwingHand.get()).booleanValue());
        }
        this.sendSlot(prevSlot);
    }

    private List<class_2338> getShieldPositions(class_2338 anchorPos) {
        class_2338 playerPos = this.mc.field_1724.method_24515();
        int dx = anchorPos.method_10263() - playerPos.method_10263();
        int dz = anchorPos.method_10260() - playerPos.method_10260();
        int sx = Integer.compare(dx, 0);
        int sz = Integer.compare(dz, 0);
        List<class_2338> positions = new ArrayList();
        boolean hasX = sx != 0;
        boolean hasZ = sz != 0;
        if (hasX) {
            if (hasZ) {
                positions.add(anchorPos.method_10069(-sx, 0, 0));
                positions.add(anchorPos.method_10069(0, 0, -sz));
            }
        } else {
            if (hasX) {
                positions.add(anchorPos.method_10069(-sx, 0, 0));
            } else {
                if (hasZ) {
                    positions.add(anchorPos.method_10069(0, 0, -sz));
                } else {
                    positions.add(anchorPos.method_10069(0, 0, -1));
                }
            }
        }
        return positions;
    }

    private boolean needsFill() {
        return ((Boolean)this.autoFillTotem.get()).booleanValue() && !this.mc.field_1724.method_31548().method_5438(((Integer)this.totemSlot.get()).intValue() - 1).method_31574(class_1802.field_8288);
    }

    private void sendSlot(int slot) {
        this.mc.field_1724.field_3944.method_52787(new class_2868(slot));
        VersionUtil.setSelectedSlot(this.mc.field_1724, slot);
    }

    private boolean isShieldOrFoodActive() {
        boolean isFood = this.mc.field_1724.method_6047().method_7909().method_57347().method_57832(class_9334.field_50075) || this.mc.field_1724.method_6079().method_7909().method_57347().method_57832(class_9334.field_50075);
        boolean isShield = this.mc.field_1724.method_6047().method_7909() instanceof class_1819 || this.mc.field_1724.method_6079().method_7909() instanceof class_1819;
        boolean isRMB = GLFW.glfwGetMouseButton(this.mc.method_22683().method_4490(), 1) == 1;
        if (!isRMB) { /* goto @144; */ }
        return isFood || isShield;
    }

    private class_3965 makeHitResult(class_2338 pos) {
        class_243 center = class_243.method_24953(pos);
        return new class_3965(center, class_2350.field_11036, pos, false);
    }
}
