/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

private static enum AnchorMacro.Phase {
    public static final AnchorMacro.Phase IDLE = new AnchorMacro.Phase("IDLE", 0);
    public static final AnchorMacro.Phase FILL_TOTEM = new AnchorMacro.Phase("FILL_TOTEM", 1);
    public static final AnchorMacro.Phase PLACE_SHIELD = new AnchorMacro.Phase("PLACE_SHIELD", 2);
    public static final AnchorMacro.Phase SWITCH_GLOW = new AnchorMacro.Phase("SWITCH_GLOW", 3);
    public static final AnchorMacro.Phase PLACE_GLOW = new AnchorMacro.Phase("PLACE_GLOW", 4);
    public static final AnchorMacro.Phase SWITCH_TOTEM = new AnchorMacro.Phase("SWITCH_TOTEM", 5);
    public static final AnchorMacro.Phase EXPLODE = new AnchorMacro.Phase("EXPLODE", 6);
    public static final AnchorMacro.Phase PLACE_ANCHOR = new AnchorMacro.Phase("PLACE_ANCHOR", 7);
    private static final /* synthetic */ AnchorMacro.Phase[] $VALUES;

    public static AnchorMacro.Phase[] values() {
        return (AnchorMacro.Phase[])$VALUES.clone();
    }

    public static AnchorMacro.Phase valueOf(String name) {
        return (AnchorMacro.Phase)Enum.valueOf(AnchorMacro.Phase.class, name);
    }

    private AnchorMacro.Phase() {
        super(var1, var2);
    }

    static {
        $VALUES = AnchorMacro.Phase.$values();
    }
}
