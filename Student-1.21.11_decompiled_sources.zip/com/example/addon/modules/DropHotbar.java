/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ItemSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

public class DropHotbar
extends Module {
    private final SettingGroup sg = this.settings.getDefaultGroup();
    private final Setting<class_1792> item;
    private final Setting<Boolean> autoRefill;

    public DropHotbar() {
        super(AddonTemplate.Student, "Drop Hotbar", "Auto switch & drop selected item.");
        this.item = this.sg.add(((ItemSetting.Builder)((ItemSetting.Builder)((ItemSetting.Builder)new ItemSetting.Builder().name("item")).description("Item to drop.")).defaultValue(class_1802.field_8831)).build());
        this.autoRefill = this.sg.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("auto-refill")).description("Automatically refill from inventory.")).defaultValue(true)).build());
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1724 == null) {
            return;
        }
        class_1792 target = (class_1792)this.item.get();
        if (target == null || target == class_1802.field_8162) {
            return;
        }
        int hotbarSlot = this.findItemInHotbar(target);
        if (hotbarSlot == -1) {
            if (((Boolean)this.autoRefill.get()).booleanValue()) {
                int invSlot = this.findItemInInventory(target);
                if (invSlot != -1) {
                    this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, invSlot, 0, class_1713.field_7794, this.mc.field_1724);
                    return;
                }
            }
        }
        if (hotbarSlot != -1) {
            this.mc.field_1724.method_31548().method_61496(hotbarSlot);
            if (!this.mc.field_1724.method_6047().method_7960()) {
                this.mc.field_1724.method_7290(true);
            }
        }
    }

    private int findItemInHotbar(class_1792 item) {
        for (int i = 0; i < 9; i++) {
            if (!this.mc.field_1724.method_31548().method_5438(i).method_31574(item)) continue;
            return i;
        }
        return -1;
    }

    private int findItemInInventory(class_1792 item) {
        for (int i = 9; i < this.mc.field_1724.method_31548().method_5439(); i++) {
            if (!this.mc.field_1724.method_31548().method_5438(i).method_31574(item)) continue;
            return i;
        }
        return -1;
    }
}
