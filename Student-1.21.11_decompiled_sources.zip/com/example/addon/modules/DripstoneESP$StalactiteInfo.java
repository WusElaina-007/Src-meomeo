/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import net.minecraft.class_2338;

private static class DripstoneESP.StalactiteInfo {
    final int length;
    final class_2338 bottomPos;

    DripstoneESP.StalactiteInfo(int length, class_2338 bottomPos) {
        this.length = length;
        this.bottomPos = bottomPos;
    }
}
