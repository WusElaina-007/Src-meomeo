/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringListSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3489;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class SpawnerProtect
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<Integer> spawnerRange = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("spawner-range")).description("Phạm vi quét spawner xung quanh player.")).defaultValue(16)).range(1, 50).sliderRange(1, 50).build());
    private final Setting<Integer> playerRange = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("player-range")).description("Khoảng cách tối đa từ spawner để detect người lạ.")).defaultValue(32)).range(1, 100).sliderRange(1, 100).build());
    private final Setting<Boolean> autoDisconnect = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("auto-disconnect")).defaultValue(true)).build());
    private final Setting<List<String>> whitelist = this.sgGeneral.add(((StringListSetting.Builder)((StringListSetting.Builder)new StringListSetting.Builder().name("whitelist")).description("Players allowed nearby.")).build());
    private final Setting<Double> lootRange = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("loot-range")).description("Phạm vi nhặt item (blocks).")).defaultValue(6).range(1, 20).sliderRange(1, 20).build());
    private final Setting<List<class_1792>> storeItems = this.sgGeneral.add(((ItemListSetting.Builder)((ItemListSetting.Builder)new ItemListSetting.Builder().name("store-items")).description("Only these items will be moved into Ender Chest.")).build());
    private SpawnerProtect.State state = SpawnerProtect.State.IDLE;
    private final List<class_2338> spawners = new ArrayList();
    private int index = 0;
    private int emptyConfirmTicks = 0;
    private static final int CONFIRM_TICKS_REQUIRED = 5;
    private long lootTimer = 0L;
    private class_2338 enderChestPos = null;

    public SpawnerProtect() {
        super(AddonTemplate.Student_esp, "spawner-protect", "");
    }

    public void onActivate() {
        this.state = SpawnerProtect.State.IDLE;
        this.spawners.clear();
        this.index = 0;
        this.emptyConfirmTicks = 0;
        this.enderChestPos = null;
    }

    public void onDeactivate() {
        this.stopAll();
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (this.state != SpawnerProtect.State.IDLE) { /* goto L69; */ }
        if (this.hasUnknownPlayerNearSpawner()) {
            if (this.mc.field_1755 != null) {
                this.mc.field_1724.method_3137();
            }
            this.state = SpawnerProtect.State.SCAN;
        } else {
            return;
        }
        switch (this.state.ordinal()) {
            case 1::
                this.scan();
                /* goto @133; */
            case 2::
                this.mine();
                /* goto @133; */
            case 3::
                this.loot();
                /* goto @133; */
            case 4::
                this.store();
            default:
                return;
        }
    }

    private boolean hasUnknownPlayerNearSpawner() {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return false;
        }
        int r = ((Integer)this.spawnerRange.get()).intValue();
        class_2338 center = this.mc.field_1724.method_24515();
        class_2338 nearestSpawner = null;
        double minDist = 179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
        double pr = class_2338.method_10097(center.method_10069(-r, -r, -r), center.method_10069(r, r, r)).iterator();
        while (pr.hasNext()) {
            class_2338 pos = (class_2338)pr.next();
            while (!this.mc.field_1687.method_2935().method_12123(pos.method_10263() >> 4, pos.method_10260() >> 4)) {
            }
            if (this.mc.field_1687.method_8320(pos).method_26204() == class_2246.field_10260) {
                double d = pos.method_10262(center);
                if (d < minDist) {
                    minDist = d;
                    nearestSpawner = pos.method_10062();
                }
            }
        }
        if (nearestSpawner == null) {
            return false;
        }
        pr = (double)((Integer)this.playerRange.get()).intValue();
        rangeSquared = pr * pr;
        class_2338 checkCenter = nearestSpawner;
        var var11 = this.mc.field_1687.method_18456().iterator();
        while (var11.hasNext()) {
            class_1657 player = (class_1657)var11.next();
            while (player == this.mc.field_1724) {
            }
            String name = player.method_7334().name();
            if (!((List)this.whitelist.get()).contains(name)) {
                if (!player.method_24515().method_10262(checkCenter) <= rangeSquared) continue;
                return true;
            }
        }
        return false;
    }

    private void scan() {
        this.spawners.clear();
        this.index = 0;
        this.enderChestPos = null;
        class_2338 center = this.mc.field_1724.method_24515();
        int r = ((Integer)this.spawnerRange.get()).intValue();
        var var3 = class_2338.method_10097(center.method_10069(-r, -r, -r), center.method_10069(r, r, r)).iterator();
        while (var3.hasNext()) {
            class_2338 pos = (class_2338)var3.next();
            while (!this.mc.field_1687.method_2935().method_12123(pos.method_10263() >> 4, pos.method_10260() >> 4)) {
            }
            if (this.mc.field_1687.method_8320(pos).method_26204() != class_2246.field_10260) continue;
            this.spawners.add(pos.method_10062());
            if (this.mc.field_1687.method_8320(pos).method_26204() != class_2246.field_10443) continue;
            this.enderChestPos = pos.method_10062();
        }
        this.spawners.sort(Comparator.comparingDouble(this::lambda$scan$0));
        if (!this.spawners.isEmpty()) {
            this.emptyConfirmTicks = 0;
            this.state = SpawnerProtect.State.MINING;
        }
    }

    private void mine() {
        if (this.index >= this.spawners.size()) {
            this.scan();
            if (this.spawners.isEmpty()) {
                this.emptyConfirmTicks = this.emptyConfirmTicks + 1;
                if (this.emptyConfirmTicks < 5) {
                    return;
                }
                this.stopMove();
                this.mc.field_1690.field_1832.method_23481(false);
                this.lootTimer = System.currentTimeMillis();
                this.state = SpawnerProtect.State.LOOT;
                return;
            }
            this.emptyConfirmTicks = 0;
            this.index = 0;
            return;
        }
        class_2338 target = (class_2338)this.spawners.get(this.index);
        if (!this.mc.field_1687.method_22340(target)) {
            this.index = this.index + 1;
            return;
        }
        if (this.mc.field_1724.method_5707(class_243.method_24953(target)) > 20) {
            this.moveTo(target);
            return;
        }
        this.mc.field_1690.field_1832.method_23481(true);
        this.switchPickaxe();
        this.lookAt(target);
        class_3965 hit = this.mc.field_1687.method_17742(new class_3959(this.mc.field_1724.method_33571(), class_243.method_24953(target), class_3959.class_3960.field_17559, class_3959.class_242.field_1348, this.mc.field_1724));
        this.mc.field_1761.method_2902(target, hit.method_17780());
        if (hit != null && hit.method_17783() == class_239.class_240.field_1332 && hit.method_17777().equals(target)) {
            this.mc.field_1724.method_6104(class_1268.field_5808);
        }
        if (this.mc.field_1687.method_8320(target).method_26215()) {
            this.index = this.index + 1;
            this.stopMove();
        }
    }

    private void loot() {
        double range = ((Double)this.lootRange.get()).doubleValue();
        class_1542 nearest = null;
        double closest = 999;
        var var6 = this.mc.field_1687.method_18112().iterator();
        while (var6.hasNext()) {
            class_1297 e = (class_1297)var6.next();
            if (e instanceof class_1542) {
                class_1542 item = (class_1542)e;
                double d = new class_243(item.method_23317(), item.method_23318(), item.method_23321()).method_1022(this.mc.field_1724.method_73189());
                if (d < range) {
                    if (d < closest) {
                        closest = d;
                        nearest = item;
                    }
                }
            }
        }
        if (nearest != null) {
            this.lookAt(nearest.method_24515());
            this.mc.field_1690.field_1894.method_23481(true);
            this.lootTimer = System.currentTimeMillis();
            return;
        }
        this.stopMove();
        if (System.currentTimeMillis() - this.lootTimer > 500L) {
            this.state = SpawnerProtect.State.STORE;
        }
    }

    private void store() {
        if (this.enderChestPos == null) {
            this.finish();
            return;
        }
        if (this.mc.field_1724.method_5707(class_243.method_24953(this.enderChestPos)) > 16) {
            this.moveTo(this.enderChestPos);
            return;
        }
        this.lookAt(this.enderChestPos);
        this.stopMove();
        if (!(this.mc.field_1724.field_7512 instanceof class_1707)) {
            this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, new class_3965(class_243.method_24953(this.enderChestPos), class_2350.field_11036, this.enderChestPos, false));
            return;
        }
        class_1707 handler = (class_1707)this.mc.field_1724.field_7512;
        int containerSlots = handler.method_17388() * 9;
        for (int i = containerSlots; i < handler.field_7761.size(); i++) {
            if (handler.method_7611(i).method_7681()) {
                class_1799 stack = handler.method_7611(i).method_7677();
                if (((List)this.storeItems.get()).contains(stack.method_7909())) {
                    this.mc.field_1761.method_2906(handler.field_7763, i, 0, class_1713.field_7794, this.mc.field_1724);
                    return;
                }
            }
        }
        this.mc.field_1724.method_3137();
        this.finish();
    }

    private void finish() {
        if (((Boolean)this.autoDisconnect.get()).booleanValue()) {
            this.mc.field_1724.field_3944.method_48296().method_10747(class_2561.method_43470("SpawnerProtect"));
        }
        this.toggle();
    }

    private void switchPickaxe() {
        int i = 0;
        while (i < 9) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
            if (stack.method_31573(class_3489.field_42614)) {
                this.mc.field_1724.method_31548().method_61496(i);
            } else {
                i++;
            }
        }
    }

    private void moveTo(class_2338 pos) {
        this.lookAt(pos);
        this.mc.field_1690.field_1894.method_23481(true);
    }

    private void stopMove() {
        this.mc.field_1690.field_1894.method_23481(false);
    }

    private void stopAll() {
        this.stopMove();
        this.mc.field_1690.field_1832.method_23481(false);
        if (this.mc.field_1761 != null) {
            this.mc.field_1761.method_2925();
        }
    }

    private void lookAt(class_2338 pos) {
        class_243 eyes = this.mc.field_1724.method_33571();
        class_243 target = class_243.method_24953(pos);
        class_243 diff = target.method_1020(eyes);
        double yaw = Math.toDegrees(Math.atan2(-diff.field_1352, diff.field_1350));
        double pitch = Math.toDegrees(-Math.asin(diff.field_1351 / diff.method_1033()));
        this.mc.field_1724.method_36456((float)yaw);
        this.mc.field_1724.method_36457((float)pitch);
    }
}
