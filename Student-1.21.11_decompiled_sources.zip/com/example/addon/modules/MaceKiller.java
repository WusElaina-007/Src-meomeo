/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.events.entity.player.AttackEntityEvent;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2828;

public class MaceKiller
extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<Integer> fakeFallBlocks = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("fake-fall-blocks")).description("Số block rơi giả gửi lên server.")).defaultValue(50)).min(1).sliderMax(20000).build());

    public MaceKiller() {
        super(AddonTemplate.Student_pvp, "Mace Killer", "Spoof fall distance for mace one-shot.");
    }

    @EventHandler
    private void onAttack(AttackEntityEvent event) {
        if (this.mc.field_1724 == null) {
            return;
        }
        double x = this.mc.field_1724.method_23317();
        double y = this.mc.field_1724.method_23318();
        double z = this.mc.field_1724.method_23321();
        float yaw = this.mc.field_1724.method_36454();
        float pitch = this.mc.field_1724.method_36455();
        this.mc.field_1724.field_3944.method_52787(new class_2828.class_2830(x, y + (double)((Integer)this.fakeFallBlocks.get()).intValue(), z, yaw, pitch, false, false));
        this.mc.field_1724.field_3944.method_52787(new class_2828.class_2830(x, y, z, yaw, pitch, false, false));
    }
}
