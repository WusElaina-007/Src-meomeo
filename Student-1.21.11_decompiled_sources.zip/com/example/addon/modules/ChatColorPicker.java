/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import net.minecraft.class_2583;
import net.minecraft.class_5251;

public class ChatColorPicker
extends Module {
    private final SettingGroup sg = this.settings.getDefaultGroup();
    private final Setting<Boolean> copyToClipboard = this.sg.add(((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("copy-to-clipboard")).defaultValue(true)).build());
    private final Setting<Boolean> autoDisable = this.sg.add(((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("auto-disable")).defaultValue(true)).build());
    private volatile class_2583 lastHoveredStyle = null;
    private boolean waitingForClick = false;
    private boolean wasPressed = false;

    public ChatColorPicker() {
        super(AddonTemplate.Student, "Chat-Color-Picker", "Click vào text trong chat để lấy màu HEX.");
    }

    public void onActivate() {
        this.lastHoveredStyle = null;
        this.waitingForClick = false;
        this.wasPressed = false;
    }

    public void captureStyle(class_2583 style) {
        this.lastHoveredStyle = style;
    }

    public boolean isWaitingForClick() {
        return true;
    }

    public void onMouseClick() {
        if (this.lastHoveredStyle == null) {
            return;
        }
        class_5251 textColor = this.lastHoveredStyle.method_10973();
        if (textColor == null) {
            return;
        }
        int rgb = textColor.method_27716() & 16777215;
        String mcCode = "&#" + String.format("%06X", rgb);
        if (((Boolean)this.copyToClipboard.get()).booleanValue()) {
            this.mc.field_1774.method_1455(mcCode);
        }
        if (((Boolean)this.autoDisable.get()).booleanValue()) {
            this.toggle();
        }
        this.lastHoveredStyle = null;
    }
}
