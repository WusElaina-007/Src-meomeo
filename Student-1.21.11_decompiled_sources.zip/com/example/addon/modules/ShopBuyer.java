/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;

public class ShopBuyer
extends Module {
    private final SettingGroup sg = this.settings.getDefaultGroup();
    private final Setting<Integer> delay = this.sg.add(((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("delay")).defaultValue(10)).min(1).max(100).build());
    private final Setting<Boolean> infinite = this.sg.add(((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("infinite")).defaultValue(false)).build());
    private final Setting<Integer> buyAmount;
    private final Setting<ShopBuyer.CategoryType> category;
    private final Setting<ShopBuyer.EndItems> endItems;
    private final Setting<ShopBuyer.NetherItems> netherItems;
    private final Setting<ShopBuyer.GearItems> gearItems;
    private final Setting<ShopBuyer.FoodItems> foodItems;
    private int delayTick;
    private int stage;
    private int bought;
    private boolean checkedOnce;
    private boolean clicked17;

    public ShopBuyer() {
        super(AddonTemplate.Student, "Shop Buyer", "Auto buy shop.");
        this.buyAmount = this.sg.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("buy-amount")).defaultValue(5)).min(1).sliderMax(100).visible(this::lambda$new$0)).build());
        this.category = this.sg.add(((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("category")).defaultValue(ShopBuyer.CategoryType.END)).build());
        this.endItems = this.sg.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("end-items")).visible(this::lambda$new$1)).defaultValue(ShopBuyer.EndItems.ENDER_CHEST)).build());
        this.netherItems = this.sg.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("nether-items")).visible(this::lambda$new$2)).defaultValue(ShopBuyer.NetherItems.BLAZE_ROD)).build());
        this.gearItems = this.sg.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("gear-items")).visible(this::lambda$new$3)).defaultValue(ShopBuyer.GearItems.OBSIDIAN)).build());
        this.foodItems = this.sg.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("food-items")).visible(this::lambda$new$4)).defaultValue(ShopBuyer.FoodItems.POTATO)).build());
        this.delayTick = 0;
        this.stage = 0;
        this.bought = 0;
        this.checkedOnce = false;
        this.clicked17 = false;
    }

    public void onActivate() {
        this.delayTick = 0;
        this.stage = 0;
        this.bought = 0;
        this.checkedOnce = false;
        this.clicked17 = false;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1724 == null) {
            return;
        }
        this.ensureSafeHotbar();
        if (this.isInventoryFull()) {
            ChatUtils.info("Inventory full! Module stopped.", new Object[0]);
            this.toggle();
            return;
        }
        this.toggle();
        if (!((Boolean)this.infinite.get()).booleanValue() && this.bought >= ((Integer)this.buyAmount.get()).intValue()) {
            return;
        }
        if (this.delayTick > 0) {
            this.delayTick = this.delayTick - 1;
            return;
        }
        class_1703 handler = this.mc.field_1724.field_7512;
        ChatUtils.info("Shop GUI closed. Module stopped.", new Object[0]);
        if (this.stage != 0 && !(handler instanceof class_1707)) {
            this.toggle();
            return;
        }
        if (!(handler instanceof class_1707)) {
            ChatUtils.sendPlayerMsg("/shop");
            this.delayTick = ((Integer)this.delay.get()).intValue();
            return;
        }
        class_1707 container = (class_1707)handler;
        if (this.stage == 0) {
            this.clickCategory(container);
            this.stage = 1;
            this.delayTick = ((Integer)this.delay.get()).intValue();
            return;
        }
        if (this.stage == 1) {
            this.clickItem(container);
            this.stage = 2;
            this.delayTick = ((Integer)this.delay.get()).intValue();
            return;
        }
        if (this.stage == 2) {
            class_1792 expected = this.getSelectedItem();
            if (!this.checkedOnce) {
                this.checkedOnce = true;
                if (!container.method_7611(13).method_7677().method_31574(expected)) {
                    ChatUtils.info("Wrong item detected.", new Object[0]);
                    this.toggle();
                    return;
                }
                this.delayTick = ((Integer)this.delay.get()).intValue();
                return;
            }
            if (!this.clicked17) {
                this.mc.field_1761.method_2906(container.field_7763, 17, 0, class_1713.field_7790, this.mc.field_1724);
                this.clicked17 = true;
                this.delayTick = ((Integer)this.delay.get()).intValue();
                return;
            }
            this.stage = 3;
        }
        if (this.stage == 3) {
            this.mc.field_1761.method_2906(container.field_7763, 23, 0, class_1713.field_7790, this.mc.field_1724);
            this.mc.field_1724.field_3944.method_52787(new class_2846(class_2846.class_2847.field_12970, class_2338.field_10980, class_2350.field_11033));
            this.bought = this.bought + 1;
            this.stage = 0;
            this.checkedOnce = false;
            this.clicked17 = false;
            this.delayTick = ((Integer)this.delay.get()).intValue();
        }
    }

    private class_1792 getSelectedItem() {
        switch (((ShopBuyer.CategoryType)this.category.get()).ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                return this.mapEnd();
            case 1::
                return this.mapNether();
            case 2::
                return this.mapGear();
            case 3::
                return this.mapFood();
        }
    }

    private void clickCategory(class_1707 handler) {
        switch (((ShopBuyer.CategoryType)this.category.get()).ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                class_1792 icon = class_1802.field_20399;
                break;
            case 1::
                icon = class_1802.field_8328;
                break;
            case 2::
                icon = class_1802.field_8288;
                break;
            case 3::
                icon = class_1802.field_8176;
                break;
        }
        for (int i = 0; i < handler.method_17388() * 9; i++) {
            if (handler.method_7611(i).method_7677().method_31574(icon)) {
                this.mc.field_1761.method_2906(handler.field_7763, i, 0, class_1713.field_7790, this.mc.field_1724);
                return;
            }
        }
    }

    private void clickItem(class_1707 handler) {
        class_1792 target = this.getSelectedItem();
        for (int i = 0; i < handler.method_17388() * 9; i++) {
            if (handler.method_7611(i).method_7677().method_31574(target)) {
                this.mc.field_1761.method_2906(handler.field_7763, i, 0, class_1713.field_7790, this.mc.field_1724);
                return;
            }
        }
    }

    private class_1792 mapEnd() {
        switch (((ShopBuyer.EndItems)this.endItems.get()).ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                return class_1802.field_8466;
            case 1::
                return class_1802.field_8634;
            case 2::
                return class_1802.field_20399;
            case 3::
                return class_1802.field_8613;
            case 4::
                return class_1802.field_8056;
            case 5::
                return class_1802.field_8233;
            case 6::
                return class_1802.field_8882;
            case 7::
                return class_1802.field_8815;
            case 8::
                return class_1802.field_8545;
        }
    }

    private class_1792 mapNether() {
        switch (((ShopBuyer.NetherItems)this.netherItems.get()).ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                return class_1802.field_8894;
            case 1::
                return class_1802.field_8790;
            case 2::
                return class_1802.field_8601;
            case 3::
                return class_1802.field_8135;
            case 4::
                return class_1802.field_8070;
            case 5::
                return class_1802.field_8155;
            case 6::
                return class_1802.field_8067;
            case 7::
                return class_1802.field_8354;
            case 8::
                return class_1802.field_22421;
        }
    }

    private class_1792 mapGear() {
        switch (((ShopBuyer.GearItems)this.gearItems.get()).ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                return class_1802.field_8281;
            case 1::
                return class_1802.field_8301;
            case 2::
                return class_1802.field_23141;
            case 3::
                return class_1802.field_8801;
            case 4::
                return class_1802.field_8288;
            case 5::
                return class_1802.field_8634;
            case 6::
                return class_1802.field_8463;
            case 7::
                return class_1802.field_8287;
            case 8::
                return class_1802.field_8087;
        }
    }

    private class_1792 mapFood() {
        switch (((ShopBuyer.FoodItems)this.foodItems.get()).ordinal()) {
            default:
                throw new MatchException(null, null);
            case 0::
                return class_1802.field_8567;
            case 1::
                return class_1802.field_16998;
            case 2::
                return class_1802.field_8497;
            case 3::
                return class_1802.field_8179;
            case 4::
                return class_1802.field_8279;
            case 5::
                return class_1802.field_8544;
            case 6::
                return class_1802.field_8176;
            case 7::
                return class_1802.field_8071;
            case 8::
                return class_1802.field_8463;
        }
    }

    private void ensureSafeHotbar() {
        int current = this.mc.field_1724.method_31548().method_67532();
        if (this.mc.field_1724.method_31548().method_5438(current).method_7960()) {
            return;
        }
        for (int i = 0; i < 9; i++) {
            if (this.mc.field_1724.method_31548().method_5438(i).method_7960()) {
                this.mc.field_1724.method_31548().method_61496(i);
                return;
            }
        }
    }

    private boolean isInventoryFull() {
        for (int i = 0; i < this.mc.field_1724.method_31548().method_5439(); i++) {
            if (!this.mc.field_1724.method_31548().method_5438(i).method_7960()) continue;
            return false;
        }
        return true;
    }
}
