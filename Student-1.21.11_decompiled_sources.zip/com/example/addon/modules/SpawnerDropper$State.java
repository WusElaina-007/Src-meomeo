/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

private static enum SpawnerDropper.State {
    public static final SpawnerDropper.State SCANNING = new SpawnerDropper.State("SCANNING", 0);
    public static final SpawnerDropper.State MOVING = new SpawnerDropper.State("MOVING", 1);
    public static final SpawnerDropper.State SILENT_ROTATE = new SpawnerDropper.State("SILENT_ROTATE", 2);
    public static final SpawnerDropper.State OPENING = new SpawnerDropper.State("OPENING", 3);
    public static final SpawnerDropper.State DROPPING = new SpawnerDropper.State("DROPPING", 4);
    public static final SpawnerDropper.State CHEST_GUI = new SpawnerDropper.State("CHEST_GUI", 5);
    public static final SpawnerDropper.State WAITING_CLOSE = new SpawnerDropper.State("WAITING_CLOSE", 6);
    public static final SpawnerDropper.State CLOSING_GUI = new SpawnerDropper.State("CLOSING_GUI", 7);
    public static final SpawnerDropper.State WAITING_CYCLE = new SpawnerDropper.State("WAITING_CYCLE", 8);
    private static final /* synthetic */ SpawnerDropper.State[] $VALUES;

    public static SpawnerDropper.State[] values() {
        return (SpawnerDropper.State[])$VALUES.clone();
    }

    public static SpawnerDropper.State valueOf(String name) {
        return (SpawnerDropper.State)Enum.valueOf(SpawnerDropper.State.class, name);
    }

    private SpawnerDropper.State() {
        super(var1, var2);
    }

    static {
        $VALUES = SpawnerDropper.State.$values();
    }
}
