/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

public static enum ShopBuyer.GearItems {
    public static final ShopBuyer.GearItems OBSIDIAN = new ShopBuyer.GearItems("OBSIDIAN", 0);
    public static final ShopBuyer.GearItems END_CRYSTAL = new ShopBuyer.GearItems("END_CRYSTAL", 1);
    public static final ShopBuyer.GearItems RESPAWN_ANCHOR = new ShopBuyer.GearItems("RESPAWN_ANCHOR", 2);
    public static final ShopBuyer.GearItems GLOWSTONE = new ShopBuyer.GearItems("GLOWSTONE", 3);
    public static final ShopBuyer.GearItems TOTEM_OF_UNDYING = new ShopBuyer.GearItems("TOTEM_OF_UNDYING", 4);
    public static final ShopBuyer.GearItems ENDER_PEARL = new ShopBuyer.GearItems("ENDER_PEARL", 5);
    public static final ShopBuyer.GearItems GOLDEN_APPLE = new ShopBuyer.GearItems("GOLDEN_APPLE", 6);
    public static final ShopBuyer.GearItems EXPERIENCE_BOTTLE = new ShopBuyer.GearItems("EXPERIENCE_BOTTLE", 7);
    public static final ShopBuyer.GearItems TIPPED_ARROW = new ShopBuyer.GearItems("TIPPED_ARROW", 8);
    private static final /* synthetic */ ShopBuyer.GearItems[] $VALUES;

    public static ShopBuyer.GearItems[] values() {
        return (ShopBuyer.GearItems[])$VALUES.clone();
    }

    public static ShopBuyer.GearItems valueOf(String name) {
        return (ShopBuyer.GearItems)Enum.valueOf(ShopBuyer.GearItems.class, name);
    }

    private ShopBuyer.GearItems() {
        super(var1, var2);
    }

    static {
        $VALUES = ShopBuyer.GearItems.$values();
    }
}
