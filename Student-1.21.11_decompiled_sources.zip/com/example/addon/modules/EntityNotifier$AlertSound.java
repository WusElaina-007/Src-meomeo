/*
 * Decompiled with https://jar.tools
 */
package com.example.addon.modules;

import net.minecraft.class_3414;
import net.minecraft.class_3417;

public static enum EntityNotifier.AlertSound {
    public static final EntityNotifier.AlertSound ANVIL = new EntityNotifier.AlertSound("ANVIL", 0, class_3417.field_14833);
    public static final EntityNotifier.AlertSound XP = new EntityNotifier.AlertSound("XP", 1, class_3417.field_14627);
    public static final EntityNotifier.AlertSound WITHER = new EntityNotifier.AlertSound("WITHER", 2, class_3417.field_14792);
    public static final EntityNotifier.AlertSound DRAGON = new EntityNotifier.AlertSound("DRAGON", 3, class_3417.field_14671);
    public static final EntityNotifier.AlertSound BELL = new EntityNotifier.AlertSound("BELL", 4, class_3417.field_17265);
    public static final EntityNotifier.AlertSound EXPLODE = new EntityNotifier.AlertSound("EXPLODE", 5, class_3417.field_15057);
    public final class_3414 sound;
    private static final /* synthetic */ EntityNotifier.AlertSound[] $VALUES;

    public static EntityNotifier.AlertSound[] values() {
        return (EntityNotifier.AlertSound[])$VALUES.clone();
    }

    public static EntityNotifier.AlertSound valueOf(String name) {
        return (EntityNotifier.AlertSound)Enum.valueOf(EntityNotifier.AlertSound.class, name);
    }

    private EntityNotifier.AlertSound(class_3414 var1) {
        super(var1, var2);
        this.sound = sound;
    }

    static {
        $VALUES = EntityNotifier.AlertSound.$values();
    }
}
