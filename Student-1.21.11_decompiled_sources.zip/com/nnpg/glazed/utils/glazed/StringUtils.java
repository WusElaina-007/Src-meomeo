/*
 * Decompiled with https://jar.tools
 */
package com.nnpg.glazed.utils.glazed;

public class StringUtils {
    public static String convertUnicodeToAscii(String text) {
        StringBuilder result = new StringBuilder();
        var var2 = text.toCharArray();
        var var3 = var2.length;
        for (int var4 = 0; var4 < var3; var4++) {
            char c = var2[var4];
            switch (c) {
                case 913::
                case 945::
                case 1040::
                case 1072::
                case 7424::
                case 65313::
                case 65345::
                    result.append(97);
                    break;
                case 665::
                case 914::
                case 946::
                case 1042::
                case 1074::
                case 65314::
                case 65346::
                    result.append(98);
                    break;
                case 1057::
                case 1089::
                case 7428::
                case 65315::
                case 65347::
                    result.append(99);
                    break;
                case 7429::
                case 65316::
                case 65348::
                    result.append(100);
                    break;
                case 917::
                case 949::
                case 1045::
                case 1077::
                case 7431::
                case 65317::
                case 65349::
                    result.append(101);
                    break;
                case 42800::
                case 65318::
                case 65350::
                    result.append(102);
                    break;
                case 610::
                case 65319::
                case 65351::
                    result.append(103);
                    break;
                case 668::
                case 919::
                case 1053::
                case 1085::
                case 65320::
                case 65352::
                    result.append(104);
                    break;
                case 618::
                case 921::
                case 1030::
                case 1110::
                case 65321::
                case 65353::
                    result.append(105);
                    break;
                case 1032::
                case 1112::
                case 7434::
                case 65322::
                case 65354::
                    result.append(106);
                    break;
                case 922::
                case 954::
                case 1050::
                case 1082::
                case 7435::
                case 65323::
                case 65355::
                    result.append(107);
                    break;
                case 671::
                case 65324::
                case 65356::
                    result.append(108);
                    break;
                case 924::
                case 1052::
                case 1084::
                case 7437::
                case 65325::
                case 65357::
                    result.append(109);
                    break;
                case 628::
                case 925::
                case 951::
                case 1055::
                case 1087::
                case 65326::
                case 65358::
                    result.append(110);
                    break;
                case 927::
                case 959::
                case 1054::
                case 1086::
                case 7439::
                case 65327::
                case 65359::
                    result.append(111);
                    break;
                case 929::
                case 961::
                case 1056::
                case 1088::
                case 7448::
                case 65328::
                case 65360::
                    result.append(112);
                    break;
                case 491::
                case 42927::
                case 65329::
                case 65361::
                    result.append(113);
                    break;
                case 640::
                case 65330::
                case 65362::
                    result.append(114);
                    break;
                case 1029::
                case 1109::
                case 42801::
                case 65331::
                case 65363::
                    result.append(115);
                    break;
                case 932::
                case 964::
                case 1058::
                case 1090::
                case 7451::
                case 65332::
                case 65364::
                    result.append(116);
                    break;
                case 965::
                case 7452::
                case 65333::
                case 65365::
                    result.append(117);
                    break;
                case 957::
                case 7456::
                case 65334::
                case 65366::
                    result.append(118);
                    break;
                case 969::
                case 7457::
                case 65335::
                case 65367::
                    result.append(119);
                    break;
                case 120::
                case 935::
                case 967::
                case 1061::
                case 1093::
                case 65336::
                case 65368::
                    result.append(120);
                    break;
                case 655::
                case 933::
                case 1059::
                case 1091::
                case 65337::
                case 65369::
                    result.append(121);
                    break;
                case 918::
                case 7458::
                case 65338::
                case 65370::
                    result.append(122);
                    break;
                case 65296::
                    result.append(48);
                    break;
                case 65297::
                    result.append(49);
                    break;
                case 65298::
                    result.append(50);
                    break;
                case 65299::
                    result.append(51);
                    break;
                case 65300::
                    result.append(52);
                    break;
                case 65301::
                    result.append(53);
                    break;
                case 65302::
                    result.append(54);
                    break;
                case 65303::
                    result.append(55);
                    break;
                case 65304::
                    result.append(56);
                    break;
                case 65305::
                    result.append(57);
                    break;
                case 12288::
                    result.append(32);
                    break;
                case 65293::
                    result.append(45);
                    break;
                case 65343::
                    result.append(95);
                    break;
                case 65294::
                    result.append(46);
                    break;
                case 65292::
                    result.append(44);
                    break;
                case 65281::
                    result.append(33);
                    break;
                case 65311::
                    result.append(63);
                    break;
                case 65306::
                    result.append(58);
                    break;
                case 65307::
                    result.append(59);
                    break;
                case 65288::
                    result.append(40);
                    break;
                case 65289::
                    result.append(41);
                    break;
                case 65339::
                    result.append(91);
                    break;
                case 65341::
                    result.append(93);
                    break;
                case 65371::
                    result.append(123);
                    break;
                case 65373::
                    result.append(125);
                    break;
                case 65291::
                    result.append(43);
                    break;
                case 65309::
                    result.append(61);
                    break;
                case 65308::
                    result.append(60);
                    break;
                case 65310::
                    result.append(62);
                    break;
                case 65286::
                    result.append(38);
                    break;
                case 65285::
                    result.append(37);
                    break;
                case 65284::
                    result.append(36);
                    break;
                case 65283::
                    result.append(35);
                    break;
                case 65312::
                    result.append(64);
                    break;
                case 65290::
                    result.append(42);
                    break;
                case 65295::
                    result.append(47);
                    break;
                case 65340::
                    result.append(92);
                    break;
                case 65372::
                    result.append(124);
                    break;
                case 65374::
                    result.append(126);
                    break;
                case 65344::
                    result.append(96);
                    break;
                case 65342::
                    result.append(94);
                    break;
                case 8243::
                    result.append(34);
                    break;
                case 65287::
                    result.append(39);
                    break;
                default:
                    result.append(Character.toLowerCase(c));
            }
        }
        return result.toString().toLowerCase();
    }
}
